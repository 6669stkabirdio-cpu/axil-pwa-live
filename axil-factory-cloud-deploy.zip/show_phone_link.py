import os
import sys

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass

RENDER_URL = "https://axil-factory-shirts.onrender.com"
OWNER_URL = f"{RENDER_URL}/index.html"
WORKER_URL = f"{RENDER_URL}/worker.html"

print("=" * 65)
print("   AXIL GARMENT FACTORY — 24/7 WORLDWIDE CLOUD ACCESS")
print("=" * 65)
print()
print("  Status: 🟢 LIVE 24/7 (Hosted on Cloud — No Laptop Needed!)")
print()
print("  👑 FACTORY OWNER PORTAL:")
print(f"     {OWNER_URL}")
print("     Username: admin  |  Password: axil@2026")
print()
print("  🧵 KARIGAR & CUTTING MASTER FLOOR PORTAL:")
print(f"     {WORKER_URL}")
print("     (Direct self-registration with Full Name & Mobile Number)")
print()
print("=" * 65)
print("  Scan or open these links directly from any phone, anywhere in the world.")
print("  Your laptop can now be completely switched off or closed!")
print("=" * 65)
