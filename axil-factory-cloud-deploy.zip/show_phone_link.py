import os
import sys
import re
import subprocess
import urllib.request
import socket

if sys.platform == "win32":
    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except Exception:
        pass


def get_cloudflare_url():
    url_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), "cloudflare_url.txt")
    if os.path.exists(url_file):
        try:
            with open(url_file, "r", encoding="utf-8") as f:
                url = f.read().strip()
                if url.startswith("https://"):
                    return url
        except Exception:
            pass
    return None

def get_local_ip():
    try:
        out = subprocess.check_output('ipconfig', text=True, errors='ignore')
        matches = re.findall(r'IPv4 Address[.\s]*:\s*([0-9\.]+)', out)
        for ip in matches:
            if not ip.startswith('127.') and not ip.startswith('169.254.'):
                return ip
    except Exception:
        pass

    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    except Exception:
        ip = '127.0.0.1'
    finally:
        s.close()
    return ip

def check_server(port=8000):
    try:
        urllib.request.urlopen(f'http://127.0.0.1:{port}/api/health', timeout=1.5)
        return True
    except Exception:
        return False

if __name__ == '__main__':
    ip = get_local_ip()
    cf_url = get_cloudflare_url()
    is_running = check_server(8000)

    print("=" * 72)
    print("      AXIL FACTORY MANAGEMENT - PWA WORLDWIDE & LOCAL ACCESS")
    print("=" * 72)
    print(f"Backend Server Status : {'RUNNING [ONLINE]' if is_running else 'STOPPED (Run start_cloudflare_pwa.bat)'}")
    print(f"Local Network IP      : {ip}")
    print("-" * 72)
    
    if cf_url:
        print("[PRIMARY] WORLDWIDE HTTPS LINKS (Works on ANY Phone, 4G/5G, or Wi-Fi):")
        print(f"\n  1. OWNER PORTAL (Dashboard, Live Graphs, Attendance, Posters):")
        print(f"     {cf_url}/index.html")
        print(f"\n  2. KARIGAR TOUCHSCREEN PORTAL (Job Logging, Attendance):")
        print(f"     {cf_url}/worker.html")
        print(f"\n  3. QR CODE FOR PHONE SCANNING:")
        print(f"     {cf_url}/assets/qr_owner.png")
    else:
        print("[NOTICE] Cloudflare tunnel not active. Run start_cloudflare_pwa.bat to enable worldwide access.")

    print("-" * 72)
    print("[FALLBACK] LOCAL WI-FI ONLY (Requires Laptop & Phone on exact same Wi-Fi):")
    print(f"  Owner Portal   : http://{ip}:8000/index.html")
    print(f"  Karigar Portal : http://{ip}:8000/worker.html")
    print("-" * 72)
    print("HOW TO INSTALL AS A NATIVE APP (WITH ICON ON UNCLE'S PHONE):")
    print("  ON ANDROID (Chrome):")
    print("    1. Open the Worldwide HTTPS link above in Google Chrome.")
    print("    2. Tap 'Add AXIL Factory to Home screen' or tap the 3 dots menu -> 'Install app'.")
    print("    3. Done! It now installs like a native Android Play Store app with offline cache!")
    print("\n  ON IPHONE (Safari):")
    print("    1. Open the Worldwide HTTPS link above in Safari.")
    print("    2. Tap the Share button (square with arrow pointing up).")
    print("    3. Scroll down and tap 'Add to Home Screen' (+).")
    print("=" * 72)
