"""
AXIL PWA - End-to-End Complete Verification Suite
Validates:
1. Static files serving (HTML, PWA Manifest, Service Worker, CSS, JS, Brand Assets)
2. All 11 Navigation Modules API responses
3. Prompt 5 Analytics & Reporting generation
4. Worker Portal touch APIs and role privacy
"""

import sys
import os
from fastapi.testclient import TestClient

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "backend"))
from main import app

client = TestClient(app)


def run_e2e_tests():
    print("=" * 60)
    print("AXIL PWA - END-TO-END COMPREHENSIVE VERIFICATION")
    print("=" * 60)

    # 1. Verify Static Files & PWA assets
    print("\n[E2E 1] Verifying PWA Static Assets...")
    r_index = client.get("/")
    assert r_index.status_code == 200 and "AXIL" in r_index.text
    print("[OK] Owner Portal (index.html) successfully served.")

    r_worker = client.get("/worker.html")
    assert r_worker.status_code == 200 and "Karigar" in r_worker.text
    print("[OK] Worker Portal (worker.html) successfully served.")

    r_manifest = client.get("/manifest.json")
    assert r_manifest.status_code == 200 and "standalone" in r_manifest.text
    print("[OK] PWA Manifest (manifest.json) verified.")

    r_sw = client.get("/sw.js")
    assert r_sw.status_code == 200 and "CACHE_NAME" in r_sw.text
    print("[OK] PWA Service Worker (sw.js) verified.")

    # 2. Authenticate Owner
    print("\n[E2E 2] Authenticating Owner...")
    r_auth = client.post("/api/auth/login", json={"username": "admin", "password": "axil@2026"})
    assert r_auth.status_code == 200
    token = r_auth.json()["token"]
    headers = {"Authorization": f"Bearer {token}"}
    print("[OK] Owner authenticated successfully.")

    # 3. Test Modules Data Endpoints
    print("\n[E2E 3] Testing Module Endpoints...")

    # Lots & Details
    r_lots = client.get("/api/lots", headers=headers)
    assert r_lots.status_code == 200
    lots = r_lots.json()
    assert len(lots) > 0
    lot_id = lots[0]["id"]
    r_lot_det = client.get(f"/api/lots/{lot_id}", headers=headers)
    assert r_lot_det.status_code == 200 and "routes" in r_lot_det.json()
    print(f"[OK] Manufacturing Lots & Routes verified ({len(lots)} lots loaded).")

    # Fabric Inward
    r_fab = client.get("/api/fabric-inward", headers=headers)
    assert r_fab.status_code == 200
    print(f"[OK] Fabric Inward log verified ({len(r_fab.json())} entries).")

    # Finished Stock
    r_stock = client.get("/api/stock/finished", headers=headers)
    assert r_stock.status_code == 200
    print("[OK] Finished Stock in Godown verified.")

    # Payments Khata
    r_pay = client.get("/api/payments", headers=headers)
    assert r_pay.status_code == 200
    print("[OK] Payments & Khata ledger verified.")

    # Prompt 5 Analytics & Reporting Engine
    print("\n[E2E 4] Testing Prompt 5 Analytics Engine...")
    r_rep = client.get("/api/analytics/report", headers=headers)
    assert r_rep.status_code == 200
    report = r_rep.json()
    assert "orders_by_status" in report
    assert "karigar_performance" in report
    assert "alterations_by_defect" in report
    assert "lots_by_dept" in report
    print(f"[OK] Analytics Engine loaded:")
    print(f"     - Orders in pipeline: {len(report['orders_by_status'])} statuses")
    print(f"     - Karigar performance records: {len(report['karigar_performance'])} tracked")
    print(f"     - Defect categories: {len(report['alterations_by_defect'])} logged")
    print(f"     - Department stages tracked: {len(report['lots_by_dept'])} stages")

    # Prompt 8 Bundle-Progress, Breaks & Employee Deep Inspector
    print("\n[E2E 5] Testing Bundle Progress, Pause/Break & Employee Inspector...")
    r_insp = client.get("/api/workers/2/deep-analytics", headers=headers)
    assert r_insp.status_code == 200
    insp = r_insp.json()
    assert insp["worker"]["full_name"] == "Dinesh Kumar"
    assert "lifetime_averages" in insp
    assert "date_summary" in insp
    assert "date_breaks" in insp
    print(f"[OK] Employee Deep Inspector verified for Dinesh Kumar:")
    print(f"     - Lifetime Stitched: {insp['lifetime_averages']['total_pieces']} pcs")
    print(f"     - Net Speed: {insp['lifetime_averages']['avg_speed_pcs_hr']} pcs/hr")
    print(f"     - Today's Break Records: {len(insp['date_breaks'])} breaks tracked")

    # Prompt 10 Worker Portal Full Process Routes, Attendance Calendar & Orders
    print("\n[E2E 6] Testing Worker Portal Routes, Calendar & Orders Endpoints...")
    r_cal = client.get("/api/workers/2/attendance-calendar", headers=headers)
    assert r_cal.status_code == 200
    assert "present_days" in r_cal.json()
    print("[OK] Worker Attendance Calendar endpoint verified.")

    r_pord = client.get("/api/orders/pending-for-production", headers=headers)
    assert r_pord.status_code == 200
    assert len(r_pord.json()) > 0
    print(f"[OK] Pending production orders endpoint verified ({len(r_pord.json())} pending orders).")

    print("\n" + "=" * 60)
    print("ALL END-TO-END SUITE TESTS PASSED WITH 100% SUCCESS!")
    print("=" * 60)


if __name__ == "__main__":
    run_e2e_tests()
