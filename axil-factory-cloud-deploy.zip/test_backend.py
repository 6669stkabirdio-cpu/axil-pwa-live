"""
AXIL Factory Management PWA - Automated Backend & Security Verification Suite
Tests:
1. Authentication (Owner password login & Worker PIN login).
2. Role-based Security Enforcement (Workers blocked from owner reports and other workers' records).
3. Orders lifecycle and dispatch tracking with immutable audit history.
4. Cutting & Lot Creation with automated route building.
5. Inward/Outward Department Handover & Shortage Spotting (Rule: cannot send more than cut).
6. Karigar Production Time Logging & Speed Calculation (pcs/hour).
7. Alteration logging against specific karigar.
8. Dynamic Lot Cost Sheet generation.
9. Daily Attendance recording and monthly retrieval.
10. Database Re-open Persistence Verification.
"""

import sys
import os
import datetime
from fastapi.testclient import TestClient

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "backend"))
from main import app
from database import get_db

client = TestClient(app)


def run_all_tests():
    print("=" * 60)
    print("AXIL PWA - BACKEND & SECURITY VERIFICATION SUITE")
    print("=" * 60)

    # 1. Test Owner Login
    print("\n[TEST 1] Owner Authentication...")
    resp = client.post("/api/auth/login", json={"username": "admin", "password": "axil@2026"})
    assert resp.status_code == 200, f"Owner login failed: {resp.text}"
    owner_data = resp.json()
    owner_token = owner_data["token"]
    assert owner_data["role"] == "OWNER"
    print("[OK] Owner login successful. Role verified as OWNER.")

    # 2. Test Worker 1-Tap PIN Login
    print("\n[TEST 2] Worker PIN Login...")
    resp = client.post("/api/auth/worker-pin-login", json={"worker_code": "KAR-101", "pin": "1234"})
    assert resp.status_code == 200, f"Worker PIN login failed: {resp.text}"
    worker_data = resp.json()
    worker_token = worker_data["token"]
    assert worker_data["role"] == "WORKER"
    assert worker_data["worker_id"] == 2
    print("[OK] Worker PIN login successful. Role verified as WORKER.")

    # 3. Test Security Permissions (Worker forbidden from Owner Dashboard)
    print("\n[TEST 3] Security Enforcement (Worker blocked from Owner Dashboard)...")
    resp = client.get("/api/dashboard/summary", headers={"Authorization": f"Bearer {worker_token}"})
    assert resp.status_code == 403, f"Expected 403 Forbidden, got {resp.status_code}"
    print("[OK] Security verified: Worker correctly blocked from accessing Owner Dashboard (403 Forbidden).")

    # 4. Test Owner Dashboard Access
    print("\n[TEST 4] Owner Dashboard Summary...")
    resp = client.get("/api/dashboard/summary", headers={"Authorization": f"Bearer {owner_token}"})
    assert resp.status_code == 200, f"Dashboard failed: {resp.text}"
    dash = resp.json()
    assert "total_workers" in dash
    assert "active_lots" in dash
    assert "active_orders" in dash
    print(f"[OK] Dashboard loaded: {dash['total_workers']} workers, {len(dash['active_lots'])} active lots, {dash['active_orders']} active orders.")

    # 5. Test Order Creation & Status Lifecycle
    print("\n[TEST 5] Order Creation & Status Update...")
    order_num = f"TEST-ORD-{datetime.datetime.now().strftime('%H%M%S')}"
    resp = client.post("/api/orders", json={
        "order_number": order_num,
        "customer_id": 1,
        "design_id": 1,
        "total_quantity": 300,
        "order_date": str(datetime.date.today()),
        "delivery_due_date": str(datetime.date.today() + datetime.timedelta(days=7)),
        "priority": "URGENT",
        "notes": "Automated verification test order"
    }, headers={"Authorization": f"Bearer {owner_token}"})
    assert resp.status_code == 200, f"Order creation failed: {resp.text}"
    order_id = resp.json()["order_id"]
    print(f"[OK] Order {order_num} created with ID: {order_id}")

    # Update Order status
    resp = client.put(f"/api/orders/{order_id}/status", json={
        "status": "IN_PROCESS",
        "notes": "Fabric sent to cutting"
    }, headers={"Authorization": f"Bearer {owner_token}"})
    assert resp.status_code == 200
    print("[OK] Order status successfully transitioned to IN_PROCESS.")

    # 6. Test Lot Creation (Cutting Master) & Auto-routing
    print("\n[TEST 6] Lot Creation by Cutting Master...")
    lot_num = f"TEST-LOT-{datetime.datetime.now().strftime('%H%M%S')}"
    resp = client.post("/api/lots", json={
        "lot_number": lot_num,
        "design_id": 1,
        "fabric_inward_id": 1,
        "meters_consumed": 500.0,
        "cutting_master_worker_id": 1,
        "cutting_date": str(datetime.date.today()),
        "total_cut_pieces": 500,
        "cutting_rate_per_piece": 6.0
    }, headers={"Authorization": f"Bearer {owner_token}"})
    assert resp.status_code == 200, f"Lot creation failed: {resp.text}"
    new_lot_id = resp.json()["lot_id"]
    print(f"[OK] Lot {lot_num} created with ID: {new_lot_id}")

    # 7. Test Movement Validation (Cannot send more than cut)
    print("\n[TEST 7] Movement Validation (Exceeding cut pieces must fail)...")
    resp = client.post("/api/movements/send", json={
        "lot_id": new_lot_id,
        "from_department_id": 2, # Cutting
        "to_department_id": 3,   # Stitching
        "sent_quantity": 9999    # Exceeds 500 cut pieces!
    }, headers={"Authorization": f"Bearer {owner_token}"})
    assert resp.status_code == 400, f"Expected 400 Bad Request, got {resp.status_code}"
    print(f"[OK] Validation passed: System prevented sending 9999 pieces (Error: {resp.json()['detail']}).")

    # Send valid quantity
    resp = client.post("/api/movements/send", json={
        "lot_id": new_lot_id,
        "from_department_id": 2,
        "to_department_id": 3,
        "sent_quantity": 500
    }, headers={"Authorization": f"Bearer {owner_token}"})
    assert resp.status_code == 200
    mov_id = resp.json()["movement_id"]
    print(f"[OK] Valid dispatch of 500 pieces sent. Movement ID: {mov_id}")

    # Confirm handover with shortage detection
    print("\n[TEST 8] Handover Confirmation & Shortage Detection...")
    resp = client.post("/api/movements/confirm", json={
        "movement_id": mov_id,
        "received_by_worker_id": 2,
        "received_quantity": 497, # 3 pieces short!
        "shortage_reason": "3 cut panels damaged/missing during bundling"
    }, headers={"Authorization": f"Bearer {owner_token}"})
    assert resp.status_code == 200
    print("[OK] Handover confirmed: 497 pieces received. 3 pieces shortage spotted and logged!")

    # 8. Test Karigar Production Time & Speed Tracking
    print("\n[TEST 9] Karigar Production Time & Speed Tracking...")
    resp = client.post("/api/production/start", json={
        "lot_id": new_lot_id,
        "department_id": 3,
        "worker_id": 2, # Dinesh Kumar
        "jobber_id": 1,
        "machine_id": 1,
        "pieces_assigned": 100,
        "rate_per_piece": 45.0
    }, headers={"Authorization": f"Bearer {owner_token}"})
    assert resp.status_code == 200
    prod_id = resp.json()["production_id"]
    print(f"[OK] Production timer started for Dinesh Kumar. Record ID: {prod_id}")

    # Complete production
    resp = client.post("/api/production/complete", json={
        "production_id": prod_id,
        "pieces_completed": 100,
        "pieces_altered": 1
    }, headers={"Authorization": f"Bearer {owner_token}"})
    assert resp.status_code == 200
    print("[OK] Production completed: 100 pieces stitched. Speed and worker earnings calculated!")

    # 9. Test Dynamic Lot Cost Sheet
    print("\n[TEST 10] Dynamic Lot Cost Sheet...")
    resp = client.get(f"/api/lots/{new_lot_id}/cost-sheet", headers={"Authorization": f"Bearer {owner_token}"})
    assert resp.status_code == 200
    sheet = resp.json()
    print(f"[OK] Cost sheet generated: Total Cost: Rs.{sheet['total_lot_cost']:.2f}, Cost/Piece: Rs.{sheet['cost_per_piece']:.2f}")

    # 10. Test Alteration Logging & Worker Notification
    print("\n[TEST 11] Alteration Logging & Worker Notification...")
    resp = client.post("/api/alterations", json={
        "lot_id": new_lot_id,
        "department_id": 3,
        "worker_id": 2,
        "alteration_pieces": 2,
        "defect_type": "Collar defect",
        "defect_description": "Puckering on point"
    }, headers={"Authorization": f"Bearer {owner_token}"})
    assert resp.status_code == 200
    print("[OK] Alteration logged against Karigar and real-time notification dispatched.")

    # Worker can view their own alterations
    resp = client.get("/api/alterations/worker/2", headers={"Authorization": f"Bearer {worker_token}"})
    assert resp.status_code == 200
    alts = resp.json()
    assert len(alts) > 0
    print(f"[OK] Worker correctly received their alteration notifications ({len(alts)} active).")

    # Worker forbidden from viewing another worker's alterations
    resp = client.get("/api/alterations/worker/3", headers={"Authorization": f"Bearer {worker_token}"})
    assert resp.status_code == 403
    print("[OK] Privacy enforced: Worker blocked from viewing other workers' alterations (403 Forbidden).")

    # 11. Test Attendance Marking
    print("\n[TEST 12] Attendance Marking...")
    resp = client.post("/api/attendance/mark", json={
        "worker_id": 2,
        "date": str(datetime.date.today()),
        "status": "PRESENT",
        "overtime_hours": 2.5,
        "notes": "Evening shift overtime completed"
    }, headers={"Authorization": f"Bearer {owner_token}"})
    assert resp.status_code == 200
    print("[OK] Attendance and overtime logged successfully.")

    # 12. Test Database Persistence after reconnect
    print("\n[TEST 13] Database ACID Disk Persistence...")
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, order_number FROM orders WHERE order_number = ?;", (order_num,))
        saved_order = cursor.fetchone()
        assert saved_order is not None
        assert saved_order["order_number"] == order_num

        cursor.execute("SELECT id, lot_number FROM lots WHERE lot_number = ?;", (lot_num,))
        saved_lot = cursor.fetchone()
        assert saved_lot is not None
        assert saved_lot["lot_number"] == lot_num

    # 13. Test Karigar Break & Pause System (Prompt 8)
    print("\n[TEST 14] Karigar Break & Pause Tracking...")
    # Start a new production job
    resp = client.post("/api/production/start", json={
        "lot_id": new_lot_id,
        "department_id": 3,
        "worker_id": 2, # Dinesh Kumar
        "jobber_id": 1,
        "machine_id": 1,
        "pieces_assigned": 100,
        "rate_per_piece": 45.0,
        "bundle_size": 20
    }, headers={"Authorization": f"Bearer {owner_token}"})
    assert resp.status_code == 200
    bundle_prod_id = resp.json()["production_id"]

    # Pause production with "Machine Breakdown / Thread Issue"
    resp = client.post("/api/production/pause", json={
        "production_id": bundle_prod_id,
        "break_reason": "Machine Breakdown / Thread Issue"
    }, headers={"Authorization": f"Bearer {worker_token}"})
    assert resp.status_code == 200
    break_id = resp.json()["break_id"]
    assert break_id > 0
    print(f"[OK] Production successfully paused. Break ID: {break_id}")

    # Resume production
    resp = client.post("/api/production/resume", json={
        "production_id": bundle_prod_id
    }, headers={"Authorization": f"Bearer {worker_token}"})
    assert resp.status_code == 200
    print("[OK] Production resumed. Active duration timer reinstated.")

    # 14. Test Bundle Progress Saving (3 bundles of 20 + 14 loose = 74 pcs)
    print("\n[TEST 15] Bundle Progress Tracking...")
    resp = client.post("/api/production/save-progress", json={
        "production_id": bundle_prod_id,
        "bundles_count": 3,
        "bundle_size": 20,
        "loose_pieces": 14,
        "is_completed": False
    }, headers={"Authorization": f"Bearer {worker_token}"})
    assert resp.status_code == 200
    prog_res = resp.json()["data"]
    assert prog_res["completed_pieces"] == 74
    assert prog_res["bundles_count"] == 3
    assert prog_res["loose_pieces"] == 14
    assert prog_res["total_earned"] == 74 * 45.0
    print(f"[OK] Bundle progress saved: 3 bundles x 20 + 14 loose = {prog_res['completed_pieces']} pieces! Total earned: Rs.{prog_res['total_earned']:.2f}")

    # 15. Test Employee Deep Inspector & Date-wise Analytics
    print("\n[TEST 16] Employee Deep Inspector & Date-wise Break Breakdown...")
    today_str = str(datetime.date.today())
    resp = client.get(f"/api/workers/2/deep-analytics?date={today_str}", headers={"Authorization": f"Bearer {owner_token}"})
    assert resp.status_code == 200
    insp = resp.json()
    assert insp["worker"]["full_name"] == "Dinesh Kumar"
    assert "lifetime_averages" in insp
    assert "date_summary" in insp
    assert "date_breaks" in insp
    assert len(insp["date_breaks"]) > 0
    assert insp["lifetime_averages"]["total_pieces"] >= 74
    print(f"[OK] Inspector verified for Dinesh Kumar:")
    print(f"     - Overall Avg Speed: {insp['lifetime_averages']['avg_speed_pcs_hr']} pcs/hr")
    print(f"     - Total Pieces Stitched: {insp['lifetime_averages']['total_pieces']} pcs")
    print(f"     - Today's Net Work: {insp['date_summary']['net_work_hours_display']}")
    print(f"     - Today's Breaks: {len(insp['date_breaks'])} breaks ({insp['date_summary']['total_pause_minutes']} mins total)")
    clean_reason = insp['date_breaks'][0]['break_reason'].encode('ascii', errors='replace').decode()
    print(f"     - Sample Break Reason: {clean_reason}")

    # Worker can access own analytics
    resp = client.get(f"/api/workers/2/deep-analytics?date={today_str}", headers={"Authorization": f"Bearer {worker_token}"})
    assert resp.status_code == 200
    print("[OK] Worker can access own deep analytics.")

    # Worker forbidden from viewing another worker's inspector
    resp = client.get(f"/api/workers/3/deep-analytics?date={today_str}", headers={"Authorization": f"Bearer {worker_token}"})
    assert resp.status_code == 403
    print("[OK] Security verified: Worker blocked from viewing other workers' inspector data (403 Forbidden).")

    # 16. Test Glitch Fix: Save and Stop Production for Tomorrow (Prompt 10)
    print("\n[TEST 17] Save & Stop Production for Tomorrow (Timer Stoppage)...")
    resp = client.post("/api/production/save-and-stop", json={
        "production_id": bundle_prod_id,
        "bundles_count": 4,
        "bundle_size": 20,
        "loose_pieces": 5,
        "pieces_altered": 0
    }, headers={"Authorization": f"Bearer {worker_token}"})
    assert resp.status_code == 200, f"Save and stop failed: {resp.text}"
    stop_data = resp.json()["data"]
    assert stop_data["completed_pieces"] == 85
    assert stop_data["is_paused"] == 1
    assert "Shift End" in stop_data["current_pause_reason"]
    print(f"[OK] Save & Stop verified: 4 bundles + 5 loose (85 pcs) saved. Job paused cleanly for tomorrow.")

    # 17. Test Worker Attendance Calendar
    print("\n[TEST 18] Worker Attendance Calendar Retrieval...")
    curr_month = datetime.date.today().strftime('%Y-%m')
    resp = client.get(f"/api/workers/2/attendance-calendar?month={curr_month}", headers={"Authorization": f"Bearer {worker_token}"})
    assert resp.status_code == 200, f"Attendance calendar failed: {resp.text}"
    att_cal = resp.json()
    assert "records" in att_cal
    assert "present_days" in att_cal
    assert "total_overtime_hours" in att_cal
    assert att_cal["present_days"] >= 1
    print(f"[OK] Attendance calendar verified: {att_cal['present_days']} present days, {att_cal['total_overtime_hours']} hrs overtime.")

    # 18. Test Pending Orders for Production
    print("\n[TEST 19] Pending Production Orders for Worker Visibility...")
    resp = client.get("/api/orders/pending-for-production", headers={"Authorization": f"Bearer {worker_token}"})
    assert resp.status_code == 200, f"Pending orders failed: {resp.text}"
    p_orders = resp.json()
    assert isinstance(p_orders, list)
    assert len(p_orders) > 0
    sample_ord = p_orders[0]
    assert "order_number" in sample_ord
    assert "customer_name" in sample_ord
    assert "design_name" in sample_ord
    print(f"[OK] Pending production orders loaded: {len(p_orders)} active orders visible to workers.")

    # 19. Test Lot Stage Advancement & Cascading Godown Stock / Order Status
    print("\n[TEST 20] Lot Stage Progression & Auto-Godown / Order Cascading...")
    # Advance Lot through stages until final
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, stage_sequence, department_id FROM lot_process_routes WHERE lot_id = ? ORDER BY stage_sequence ASC;", (new_lot_id,))
        stages = cursor.fetchall()

    print(f"     Lot has {len(stages)} stages in process route.")
    for s in stages:
        resp = client.post("/api/production/advance-stage", json={
            "lot_id": new_lot_id,
            "department_id": s["department_id"],
            "worker_id": 2,
            "pieces_completed": 497
        }, headers={"Authorization": f"Bearer {worker_token}"})
        assert resp.status_code == 200, f"Advance stage failed: {resp.text}"
        adv_res = resp.json()["data"]

    # Verify final stage reached
    assert adv_res["is_final"] is True
    assert adv_res["status"] == "COMPLETED_GODOWN"

    # Verify Finished Stock Inwarded Automatically
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT available_pieces, packed_boxes FROM finished_stock WHERE lot_id = ?;", (new_lot_id,))
        stock_row = cursor.fetchone()
        assert stock_row is not None
        assert stock_row["available_pieces"] == 497
        print(f"[OK] Auto-Godown Inward verified: {stock_row['available_pieces']} pieces ({stock_row['packed_boxes']} boxes) in finished_stock.")

        # Verify Owner Notification created
        cursor.execute("SELECT title, message FROM notifications WHERE reference_id = ? ORDER BY id DESC LIMIT 1;", (new_lot_id,))
        notif = cursor.fetchone()
        assert notif is not None
        assert "Ready for Dispatch" in notif["title"]
        print(f"[OK] Owner Notification verified: '{notif['title']}' generated automatically.")

    print("\n" + "=" * 60)
    print("ALL 20 VERIFICATION TESTS PASSED SUCCESSFULLY! (100% GREEN)")
    print("=" * 60)


if __name__ == "__main__":
    run_all_tests()
