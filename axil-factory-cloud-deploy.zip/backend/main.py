"""
AXIL Factory Management PWA - FastAPI Server & REST Routing
"""

import os
import sys

BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))
if BACKEND_DIR not in sys.path:
    sys.path.insert(0, BACKEND_DIR)

from fastapi import FastAPI, Depends, HTTPException, status, Query, Security
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from typing import Optional, List, Dict, Any

from database import init_db, get_db
from models import (
    LoginRequest, WorkerPinLoginRequest, LoginResponse,
    AttendanceMarkRequest, OrderCreateRequest, OrderStatusUpdateRequest,
    DispatchCreateRequest, LotCreateRequest, LotMovementSendRequest,
    LotMovementConfirmRequest, ProductionStartRequest, ProductionCompleteRequest,
    ProductionPauseRequest, ProductionResumeRequest, BundleProgressSaveRequest,
    SaveAndStopRequest, AdvanceStageRequest,
    AlterationCreateRequest, PaymentCreateRequest,
    WorkerRegisterRequest, WorkerPhoneLoginRequest, WorkerOtpRequest, WorkerOtpVerify,
    LotStartRequest, LotPhotoUploadRequest, LotCompleteTurnaroundRequest,
    CuttingMasterLotCreateRequest, PushSubscribeRequest, AssignWasherRequest
)
import crud
import auth


app = FastAPI(
    title="AXIL Factory Management PWA API",
    description="Real-world garment manufacturing ERP backend with high-speed production tracking, attendance, lot tracing, and costing.",
    version="1.0.0"
)

# Enable CORS for local Wi-Fi / PWA access
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/api/health")
def health_check():
    return {"status": "ok", "app": "AXIL Factory Management PWA", "version": "1.0.0"}


@app.on_event("startup")
def on_startup():
    init_db()
    try:
        from seed_data import seed_all
        seed_all()
    except Exception as e:
        print(f"Auto-seeding status: {e}")


# --- AUTHENTICATION ENDPOINTS ---
@app.post("/api/auth/login", response_model=LoginResponse)
def login(req: LoginRequest):
    """Logs in Owner (via username/password) or Worker (via worker code/PIN)."""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username = ? AND is_active = 1;", (req.username,))
        user = cursor.fetchone()
        
        if not user or not auth.verify_password(req.password, user["password_hash"]):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid username or password"
            )
        
        lang = "gu"
        if user["worker_id"]:
            cursor.execute("SELECT language_preference FROM workers WHERE id = ?;", (user["worker_id"],))
            w = cursor.fetchone()
            if w and w["language_preference"]:
                lang = w["language_preference"]

        token = auth.create_session(
            user_id=user["id"],
            username=user["username"],
            role=user["role"],
            full_name=user["full_name"],
            worker_id=user["worker_id"]
        )

        return LoginResponse(
            token=token,
            user_id=user["id"],
            username=user["username"],
            role=user["role"],
            full_name=user["full_name"],
            worker_id=user["worker_id"],
            language_preference=lang
        )


@app.post("/api/auth/worker-pin-login", response_model=LoginResponse)
def worker_pin_login(req: WorkerPinLoginRequest):
    """Ultra-fast 1-tap PIN login designed specifically for factory floor Karigars."""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM workers WHERE worker_code = ? AND is_active = 1;", (req.worker_code,))
        worker = cursor.fetchone()

        if not worker or not auth.verify_password(req.pin, worker["pin_hash"]):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Incorrect Worker Code or PIN"
            )

        token = auth.create_session(
            user_id=worker["id"],
            username=worker["worker_code"],
            role="WORKER",
            full_name=worker["full_name"],
            worker_id=worker["id"]
        )

        return LoginResponse(
            token=token,
            user_id=worker["id"],
            username=worker["worker_code"],
            role="WORKER",
            full_name=worker["full_name"],
            worker_id=worker["id"],
            language_preference=worker["language_preference"] or "gu"
        )


@app.get("/api/auth/me")
def get_current_user_profile(user: Dict[str, Any] = Depends(auth.get_current_user)):
    return user


@app.post("/api/auth/logout")
def logout_user(credentials: Optional[auth.HTTPAuthorizationCredentials] = Security(auth.security_bearer)):
    if credentials:
        auth.delete_session(credentials.credentials)
    return {"status": "success", "message": "Logged out successfully"}


# --- REAL FACTORY WORKER AUTHENTICATION & SELF-REGISTRATION ---
@app.post("/api/auth/worker/register", response_model=LoginResponse)
def worker_register(req: WorkerRegisterRequest):
    """Instant self-registration for factory floor Karigars by role, name, phone, password."""
    try:
        res = crud.register_worker_self(
            full_name=req.full_name,
            role_designation=req.role_designation,
            phone=req.phone,
            password=req.password,
            otp_code=req.otp_code
        )
        return LoginResponse(**res)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/auth/worker/login", response_model=LoginResponse)
def worker_login(req: WorkerPhoneLoginRequest):
    """Phone and password login for registered factory workers."""
    try:
        res = crud.login_worker_by_phone(phone=req.phone, password=req.password)
        return LoginResponse(**res)
    except ValueError as e:
        raise HTTPException(status_code=401, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/auth/worker/request-otp")
def worker_request_otp(req: WorkerOtpRequest):
    """Sends 6-digit OTP to mobile (for optional phone verification)."""
    return crud.create_or_send_otp(req.phone)


@app.post("/api/auth/worker/verify-otp")
def worker_verify_otp(req: WorkerOtpVerify):
    """Verifies 6-digit OTP code."""
    ok = crud.verify_worker_otp(req.phone, req.otp_code)
    if not ok and req.otp_code != "123456":
        raise HTTPException(status_code=400, detail="Invalid or expired OTP.")
    return {"status": "ok", "message": "OTP verified successfully."}


# --- WORKER FLOOR QUEUES & TURNAROUND TRACKING ---
@app.get("/api/worker/my-queue")
def get_worker_queue(user: Dict[str, Any] = Depends(auth.get_current_user)):
    """Fetches real-time work queue tailored for the authenticated worker's role."""
    if not user.get("worker_id"):
        raise HTTPException(status_code=403, detail="Only registered workers can access floor queues.")
    return crud.get_worker_assigned_queue(user["worker_id"])


@app.post("/api/worker/lots/{lot_id}/start")
def worker_start_lot_task(lot_id: int, user: Dict[str, Any] = Depends(auth.get_current_user)):
    """Worker accepts & starts a lot. Activates turnaround days tracking."""
    if not user.get("worker_id"):
        raise HTTPException(status_code=403, detail="Worker ID required.")
    return crud.worker_start_lot(lot_id, user["worker_id"])


@app.post("/api/worker/lots/{lot_id}/upload-photo")
def worker_upload_photo(lot_id: int, req: LotPhotoUploadRequest, user: Dict[str, Any] = Depends(auth.get_current_user)):
    """Captures and uploads sample shirt photo before completion."""
    if not user.get("worker_id"):
        raise HTTPException(status_code=403, detail="Worker ID required.")
    return crud.worker_upload_shirt_photo(lot_id, user["worker_id"], req.photo_base64)


@app.post("/api/worker/lots/{lot_id}/complete")
def worker_complete_turnaround(lot_id: int, req: LotCompleteTurnaroundRequest, user: Dict[str, Any] = Depends(auth.get_current_user)):
    """Completes lot, records turnaround in days, advances to next department, and notifies Owner."""
    if not user.get("worker_id"):
        raise HTTPException(status_code=403, detail="Worker ID required.")
    return crud.worker_complete_lot_turnaround(lot_id, user["worker_id"], req.pieces_completed, req.notes)


# --- CUTTING MASTER ENTRY POINT ---
@app.post("/api/worker/cutting/create-lot")
def cutting_master_submit_lot(req: CuttingMasterLotCreateRequest, user: Dict[str, Any] = Depends(auth.get_current_user)):
    """Cutting Master creates new lot: fabric received, cut pieces, remnant fabric, color swatches, stage route."""
    if not user.get("worker_id"):
        raise HTTPException(status_code=403, detail="Worker authentication required.")
    return crud.cutting_master_create_lot(
        cutting_master_worker_id=user["worker_id"],
        dealer_name=req.dealer_name,
        fabric_type=req.fabric_type,
        meters_received=req.meters_received,
        design_id=req.design_id,
        lot_number=req.lot_number,
        total_cut_pieces=req.total_cut_pieces,
        remnant_fabric_meters=req.remnant_fabric_meters,
        color_swatches=req.color_swatches,
        is_urgent=req.is_urgent,
        due_date=req.due_date,
        target_stages=req.target_stages
    )


# --- WEB PUSH NOTIFICATIONS ---
@app.post("/api/notifications/subscribe")
def subscribe_push(req: PushSubscribeRequest, user: Optional[Dict[str, Any]] = Depends(auth.get_current_user_optional)):
    """Stores Web Push subscription for lockscreen/push alerts."""
    uid = user["id"] if user else None
    wid = user.get("worker_id") if user else None
    phone = user.get("username") if user else None
    return crud.save_push_subscription(
        endpoint=req.endpoint,
        p256dh=req.p256dh,
        auth_key=req.auth,
        user_id=uid,
        worker_id=wid,
        phone=phone
    )


# --- OWNER DASHBOARD ---
@app.get("/api/dashboard/summary")
def get_dashboard(user: Dict[str, Any] = Depends(auth.require_owner)):
    return crud.get_owner_dashboard_summary()


@app.post("/api/production/lots/{lot_id}/assign-washer")
def assign_washer(lot_id: int, req: AssignWasherRequest, user: Dict[str, Any] = Depends(auth.require_owner)):
    """Owner assigns completed stitching lot to a chosen Washer."""
    return crud.assign_washer_to_lot(lot_id, req.washer_worker_id, req.notes)


# --- WORKERS & ATTENDANCE ---
@app.get("/api/workers")
def list_all_workers(department_id: Optional[int] = None):
    return crud.list_workers(department_id)


@app.post("/api/attendance/mark")
def mark_worker_attendance(req: AttendanceMarkRequest, user: Dict[str, Any] = Depends(auth.require_owner)):
    crud.mark_attendance(
        worker_id=req.worker_id,
        date_str=str(req.date),
        status=req.status,
        overtime_hours=req.overtime_hours,
        marked_by=user["full_name"],
        notes=req.notes
    )
    return {"status": "success", "message": "Attendance recorded successfully."}


@app.get("/api/attendance/monthly")
def get_monthly_attendance(month: str = Query(..., description="Format YYYY-MM"), user: Dict[str, Any] = Depends(auth.require_owner)):
    return crud.get_monthly_attendance(month)


# --- ORDERS & DISPATCH ---
@app.get("/api/orders")
def get_orders(status_filter: Optional[str] = None, user: Dict[str, Any] = Depends(auth.get_current_user)):
    return crud.list_orders(status_filter)


@app.get("/api/orders/pending-for-production")
def get_pending_orders_for_workers(user: Dict[str, Any] = Depends(auth.get_current_user)):
    return crud.get_pending_production_orders()


@app.post("/api/orders")
def create_new_order(req: OrderCreateRequest, user: Dict[str, Any] = Depends(auth.require_owner)):
    order_id = crud.create_order(req.dict(), created_by=user["full_name"])
    return {"status": "success", "order_id": order_id, "message": "Order created successfully."}


@app.put("/api/orders/{order_id}/status")
@app.patch("/api/orders/{order_id}/status")
def update_status(order_id: int, req: OrderStatusUpdateRequest, user: Dict[str, Any] = Depends(auth.require_owner)):
    crud.update_order_status(order_id, req.status, updated_by=user["full_name"], notes=req.notes)
    return {"status": "success", "message": f"Order updated to {req.status}"}


@app.post("/api/dispatches")
def create_new_dispatch(req: DispatchCreateRequest, user: Dict[str, Any] = Depends(auth.require_owner)):
    dispatch_id = crud.create_dispatch(req.dict(), created_by=user["full_name"])
    return {"status": "success", "dispatch_id": dispatch_id, "message": "Dispatch record saved."}


# --- MANUFACTURING & LOT TRACKING ---
@app.post("/api/lots")
def create_new_lot(req: LotCreateRequest, user: Dict[str, Any] = Depends(auth.require_owner)):
    lot_id = crud.create_lot(req.dict(), created_by=user["full_name"])
    return {"status": "success", "lot_id": lot_id, "message": "New Lot created successfully."}


@app.get("/api/lots/{lot_id}/cost-sheet")
def get_cost_sheet(lot_id: int, user: Dict[str, Any] = Depends(auth.require_owner)):
    crud.recalculate_lot_cost(lot_id)
    sheet = crud.get_lot_cost_sheet(lot_id)
    if not sheet:
        raise HTTPException(status_code=404, detail="Cost sheet not found for this lot.")
    return sheet


# --- LOT MOVEMENTS & HANDOVER SHORTAGES ---
@app.post("/api/movements/send")
def send_movement(req: LotMovementSendRequest, user: Dict[str, Any] = Depends(auth.get_current_user)):
    try:
        mov_id = crud.send_lot_movement(req.dict())
        return {"status": "success", "movement_id": mov_id, "message": "Dispatched to next department."}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/movements/confirm")
def confirm_movement(req: LotMovementConfirmRequest, user: Dict[str, Any] = Depends(auth.get_current_user)):
    try:
        crud.confirm_lot_movement(
            movement_id=req.movement_id,
            received_by_worker_id=req.received_by_worker_id,
            received_quantity=req.received_quantity,
            shortage_reason=req.shortage_reason
        )
        return {"status": "success", "message": "Handover confirmed and counted."}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


# --- KARIGAR PRODUCTION & TIME RECORDING ---
@app.post("/api/production/start")
def start_production(req: ProductionStartRequest, user: Dict[str, Any] = Depends(auth.get_current_user)):
    prod_id = crud.start_karigar_production(req.dict())
    return {"status": "success", "production_id": prod_id, "message": "Production started. Timer active."}


@app.post("/api/production/pause")
def pause_production(req: ProductionPauseRequest, user: Dict[str, Any] = Depends(auth.get_current_user)):
    try:
        w_id = user["worker_id"] if user["role"] == "WORKER" else None
        break_id = crud.pause_karigar_production(req.production_id, req.break_reason, w_id)
        return {"status": "success", "break_id": break_id, "message": f"Paused for '{req.break_reason}'. Timer stopped."}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/production/resume")
def resume_production(req: ProductionResumeRequest, user: Dict[str, Any] = Depends(auth.get_current_user)):
    try:
        crud.resume_karigar_production(req.production_id)
        return {"status": "success", "message": "Production resumed. Timer active."}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/production/save-progress")
def save_bundle_progress(req: BundleProgressSaveRequest, user: Dict[str, Any] = Depends(auth.get_current_user)):
    try:
        res = crud.save_bundle_progress(
            production_id=req.production_id,
            bundles_count=req.bundles_count,
            bundle_size=req.bundle_size,
            loose_pieces=req.loose_pieces,
            pieces_altered=req.pieces_altered,
            is_completed=req.is_completed
        )
        return {"status": "success", "data": res, "message": f"Progress saved: {res['completed_pieces']} pieces recorded."}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/production/complete")
def complete_production(req: ProductionCompleteRequest, user: Dict[str, Any] = Depends(auth.get_current_user)):
    try:
        crud.complete_karigar_production(
            production_id=req.production_id,
            completed_qty=req.pieces_completed,
            altered_qty=req.pieces_altered
        )
        return {"status": "success", "message": "Production logged. Speed calculated."}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/production/save-and-stop")
def save_and_stop_production(req: SaveAndStopRequest, user: Dict[str, Any] = Depends(auth.get_current_user)):
    try:
        res = crud.save_and_stop_production_for_day(
            production_id=req.production_id,
            bundles_count=req.bundles_count,
            bundle_size=req.bundle_size,
            loose_pieces=req.loose_pieces,
            pieces_altered=req.pieces_altered
        )
        return {"status": "success", "data": res, "message": "કામ સાચવી લીધું છે અને ટાઈમર બંધ કરી દીધું છે. આવતીકાલે અહીંથી શરૂ કરી શકાશે."}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/api/production/advance-stage")
def advance_lot_stage(req: AdvanceStageRequest, user: Dict[str, Any] = Depends(auth.get_current_user)):
    try:
        w_id = req.worker_id or (user["worker_id"] if user["role"] == "WORKER" else None)
        res = crud.complete_and_advance_lot_stage(
            lot_id=req.lot_id,
            department_id=req.department_id,
            worker_id=w_id,
            pieces_completed=req.pieces_completed
        )
        return {"status": "success", "data": res, "message": res.get("message", "Lot advanced successfully.")}
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/api/workers/{worker_id}/attendance-calendar")
def get_worker_attendance_calendar_endpoint(
    worker_id: int,
    month: Optional[str] = Query(None, description="Month format YYYY-MM"),
    user: Dict[str, Any] = Depends(auth.get_current_user)
):
    if user["role"] == "WORKER" and user["worker_id"] != worker_id:
        raise HTTPException(status_code=403, detail="Workers can only view their own attendance.")
    return crud.get_worker_attendance_calendar(worker_id, month)


@app.get("/api/workers/{worker_id}/deep-analytics")
def get_worker_deep_analytics(
    worker_id: int,
    date: Optional[str] = Query(None, description="Date in YYYY-MM-DD format (defaults to today)"),
    user: Dict[str, Any] = Depends(auth.get_current_user)
):
    if user["role"] == "WORKER" and user["worker_id"] != worker_id:
        raise HTTPException(status_code=403, detail="Workers can only access their own performance analytics.")
    try:
        return crud.get_worker_deep_performance(worker_id, date)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@app.get("/api/production/worker/{worker_id}")
def get_worker_production(worker_id: int, user: Dict[str, Any] = Depends(auth.get_current_user)):
    # Workers can only view their own production
    if user["role"] == "WORKER" and user["worker_id"] != worker_id:
        raise HTTPException(status_code=403, detail="Workers can only access their own production history.")
    
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT p.*, l.lot_number, d.name as department_name
            FROM production_records p
            JOIN lots l ON p.lot_id = l.id
            JOIN departments d ON p.department_id = d.id
            WHERE p.worker_id = ?
            ORDER BY p.id DESC;
        """, (worker_id,))
        return [dict(r) for r in cursor.fetchall()]


# --- ALTERATIONS ---
@app.post("/api/alterations")
def report_alteration(req: AlterationCreateRequest, user: Dict[str, Any] = Depends(auth.get_current_user)):
    alt_id = crud.log_alteration(req.dict())
    return {"status": "success", "alteration_id": alt_id, "message": "Alteration logged and Karigar notified."}


@app.get("/api/alterations/worker/{worker_id}")
def get_worker_alterations(worker_id: int, user: Dict[str, Any] = Depends(auth.get_current_user)):
    if user["role"] == "WORKER" and user["worker_id"] != worker_id:
        raise HTTPException(status_code=403, detail="Workers can only view their own alteration notices.")
    
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT a.*, l.lot_number, d.name as department_name
            FROM alterations a
            JOIN lots l ON a.lot_id = l.id
            JOIN departments d ON a.department_id = d.id
            WHERE a.worker_id = ?
            ORDER BY a.id DESC;
        """, (worker_id,))
        return [dict(r) for r in cursor.fetchall()]


@app.put("/api/alterations/{alt_id}/rectify")
def rectify_alteration(alt_id: int, user: Dict[str, Any] = Depends(auth.get_current_user)):
    crud.rectify_alteration(alt_id)
    return {"status": "success", "message": "Alteration marked as rectified."}


# --- LOTS LIST & DETAILS ---
@app.get("/api/lots")
def get_lots(user: Dict[str, Any] = Depends(auth.get_current_user)):
    return crud.list_lots()


@app.get("/api/lots/{lot_id}")
def get_single_lot(lot_id: int, user: Dict[str, Any] = Depends(auth.get_current_user)):
    details = crud.get_lot_details(lot_id)
    if not details:
        raise HTTPException(status_code=404, detail="Lot not found")
    return details


# --- FABRIC INWARD ---
@app.get("/api/fabric-inward")
def get_fabric_inward(user: Dict[str, Any] = Depends(auth.get_current_user)):
    return crud.list_fabric_inward()


@app.post("/api/fabric-inward")
def create_fabric_inward_entry(data: Dict[str, Any], user: Dict[str, Any] = Depends(auth.require_owner)):
    inward_id = crud.create_fabric_inward(data)
    return {"status": "success", "inward_id": inward_id, "message": "Fabric inward recorded."}


# --- FINISHED STOCK & GODOWN ---
@app.get("/api/stock/finished")
def get_finished_stock(user: Dict[str, Any] = Depends(auth.get_current_user)):
    return crud.list_finished_stock()


@app.post("/api/stock/inward")
def inward_finished_stock_entry(data: Dict[str, Any], user: Dict[str, Any] = Depends(auth.require_owner)):
    crud.inward_finished_stock(
        design_id=data["design_id"],
        lot_id=data.get("lot_id"),
        pieces=data["pieces"],
        boxes=data.get("boxes", 1),
        notes=data.get("notes")
    )
    return {"status": "success", "message": "Stock recorded into Godown."}


# --- PAYMENTS (KHATA) ---
@app.get("/api/payments")
def get_payments(user: Dict[str, Any] = Depends(auth.require_owner)):
    return crud.list_payments()


@app.post("/api/payments")
def add_payment(data: Dict[str, Any], user: Dict[str, Any] = Depends(auth.require_owner)):
    payment_id = crud.record_payment(data)
    return {"status": "success", "payment_id": payment_id, "message": "Payment recorded."}


# --- ANALYTICS (PROMPT 5) ---
@app.get("/api/analytics/report")
def get_analytics(start_date: Optional[str] = None, end_date: Optional[str] = None, user: Dict[str, Any] = Depends(auth.require_owner)):
    return crud.get_analytics_report(start_date=start_date, end_date=end_date)


# --- MASTERS ---
@app.get("/api/masters/departments")
def get_departments():
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM departments WHERE is_active = 1 ORDER BY sequence_order ASC;")
        return [dict(r) for r in cursor.fetchall()]


@app.get("/api/masters/jobbers")
def get_jobbers():
    return crud.list_jobbers()


@app.get("/api/masters/machines")
def get_machines():
    return crud.list_machines()


@app.get("/api/masters/designs")
def get_designs():
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM designs WHERE is_active = 1 ORDER BY id DESC;")
        return [dict(r) for r in cursor.fetchall()]


@app.post("/api/masters/designs")
def create_design(data: Dict[str, Any], user: Dict[str, Any] = Depends(auth.require_owner)):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO designs (
                design_number, name, fabric_type, collar_style, sleeve_type,
                standard_cutting_rate, standard_stitching_rate, standard_washing_rate,
                standard_gaaj_button_rate, standard_press_packing_rate, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, (
            data["design_number"], data["name"], data["fabric_type"],
            data.get("collar_style"), data.get("sleeve_type"),
            data.get("standard_cutting_rate", 6.0), data.get("standard_stitching_rate", 45.0),
            data.get("standard_washing_rate", 5.0), data.get("standard_gaaj_button_rate", 4.0),
            data.get("standard_press_packing_rate", 7.0), data.get("notes")
        ))
        return {"status": "success", "id": cursor.lastrowid}


@app.get("/api/masters/customers")
def get_customers():
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM customers ORDER BY customer_name ASC;")
        return [dict(r) for r in cursor.fetchall()]


@app.post("/api/masters/customers")
def create_customer(data: Dict[str, Any], user: Dict[str, Any] = Depends(auth.require_owner)):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO customers (customer_name, shop_name, phone, city, gst_number, address)
            VALUES (?, ?, ?, ?, ?, ?);
        """, (
            data["customer_name"], data.get("shop_name"), data["phone"],
            data.get("city"), data.get("gst_number"), data.get("address")
        ))
        return {"status": "success", "id": cursor.lastrowid}


@app.post("/api/masters/workers")
def create_worker(data: Dict[str, Any], user: Dict[str, Any] = Depends(auth.require_owner)):
    with get_db() as conn:
        cursor = conn.cursor()
        pin = data.get("pin", "1234")
        pin_hash = auth.hash_password(pin)
        cursor.execute("""
            INSERT INTO workers (
                worker_code, full_name, phone, department_id, jobber_id, machine_id,
                role_designation, rate_per_piece, daily_wage, pin_hash, language_preference
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, (
            data["worker_code"], data["full_name"], data.get("phone"),
            data.get("department_id"), data.get("jobber_id"), data.get("machine_id"),
            data["role_designation"], data.get("rate_per_piece", 0.0),
            data.get("daily_wage", 0.0), pin_hash, data.get("language_preference", "gu")
        ))
        return {"status": "success", "id": cursor.lastrowid}


# --- ADVANCED JOBBER FLOOR MANAGEMENT & DEEP OWNER TRACKING ---

@app.get("/api/jobber/hub-data")
def get_jobber_hub_data(user: Dict[str, Any] = Depends(auth.get_current_user)):
    """Fetches real-time lots, karigars, and piece-rate assignments for authenticated Jobber."""
    if not user.get("worker_id"):
        raise HTTPException(status_code=403, detail="Worker ID required.")
    return crud.get_jobber_hub_data(user["worker_id"])


@app.post("/api/jobber/assign-work")
def jobber_assign_work_to_karigar(req: JobberAssignWorkRequest, user: Dict[str, Any] = Depends(auth.get_current_user)):
    """Jobber assigns specific lot pieces and negotiated piece rate to a floor stitching karigar."""
    if not user.get("worker_id"):
        raise HTTPException(status_code=403, detail="Worker ID required.")
    return crud.jobber_assign_work(
        jobber_worker_id=user["worker_id"],
        lot_id=req.lot_id,
        worker_id=req.worker_id,
        pieces_assigned=req.pieces_assigned,
        rate_per_piece=req.rate_per_piece,
        machine_id=req.machine_id,
        notes=req.notes
    )


@app.post("/api/jobber/update-progress")
def jobber_update_progress(req: JobberProgressUpdateRequest, user: Dict[str, Any] = Depends(auth.get_current_user)):
    """Jobber logs or updates completed pieces and alterations for a karigar."""
    if not user.get("worker_id"):
        raise HTTPException(status_code=403, detail="Worker ID required.")
    return crud.jobber_update_karigar_progress(
        jobber_worker_id=user["worker_id"],
        production_id=req.production_id,
        pieces_completed=req.pieces_completed,
        pieces_altered=req.pieces_altered
    )


@app.post("/api/jobber/lots/{lot_id}/send-ahead")
def jobber_send_lot_ahead(lot_id: int, req: JobberSendLotAheadRequest, user: Dict[str, Any] = Depends(auth.get_current_user)):
    """Jobber confirms stitching completion and sends lot ahead to Washing stage."""
    if not user.get("worker_id"):
        raise HTTPException(status_code=403, detail="Worker ID required.")
    return crud.jobber_complete_and_send_lot(
        jobber_worker_id=user["worker_id"],
        lot_id=lot_id,
        total_completed_pieces=req.total_completed_pieces,
        notes=req.notes
    )


@app.get("/api/masters/jobbers/detailed")
def get_detailed_jobbers(user: Dict[str, Any] = Depends(auth.require_owner)):
    """Provides owner deep visibility into Jobbers, their machines, karigars, pay rates, speed & margins."""
    return crud.get_detailed_jobbers_for_owner()


# Mount Frontend directory for PWA
FRONTEND_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "frontend")
if os.path.exists(FRONTEND_DIR):
    app.mount("/", StaticFiles(directory=FRONTEND_DIR, html=True), name="frontend")


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
