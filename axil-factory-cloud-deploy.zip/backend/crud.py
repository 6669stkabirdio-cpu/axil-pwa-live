"""
AXIL Factory Management PWA - Data Access & Business Rules Layer (CRUD)
Enforces:
1. Shortage spotting upon department handover.
2. Department cannot send more pieces than received.
3. Accurate time recording (Start / Complete) and production speed calculations.
4. Karigar alteration logging and real-time notification dispatch.
5. Dynamic lot cost-sheet calculations.
6. Order status lifecycle tracking with immutable history.
7. Attendance management with monthly aggregates.
"""

import sqlite3
import datetime
from typing import List, Dict, Any, Optional
from database import get_db


# --- DASHBOARD OVERVIEW ---
def get_owner_dashboard_summary() -> Dict[str, Any]:
    with get_db() as conn:
        cursor = conn.cursor()
        today = str(datetime.date.today())

        # Total Active Workers
        cursor.execute("SELECT COUNT(*) FROM workers WHERE is_active = 1;")
        total_workers = cursor.fetchone()[0]

        # Fabric in Factory Summary (Meters in stock, consumed, remnant)
        cursor.execute("SELECT COALESCE(SUM(meters_received), 0), COALESCE(SUM(meters_used), 0), COALESCE(SUM(remaining_meters), 0) FROM fabric_inward;")
        fib = cursor.fetchone()
        fabric_summary = {
            "total_received_meters": round(fib[0], 1),
            "total_used_meters": round(fib[1], 1),
            "remnant_fabric_meters": round(fib[2], 1)
        }

        # Stage-by-Stage Real-Time Pipeline Funnel (Depts 2 to 8)
        cursor.execute("""
            SELECT 
                dept.id as department_id,
                dept.name as department_name,
                dept.name_gu as department_name_gu,
                dept.name_hi as department_name_hi,
                dept.code as department_code,
                COUNT(l.id) as lot_count,
                COALESCE(SUM(l.total_cut_pieces), 0) as total_pieces
            FROM departments dept
            LEFT JOIN lots l ON l.current_department_id = dept.id AND l.current_status NOT IN ('COMPLETED_GODOWN', 'CANCELLED')
            WHERE dept.id BETWEEN 1 AND 9
            GROUP BY dept.id
            ORDER BY dept.id ASC;
        """)
        stage_funnel = [dict(r) for r in cursor.fetchall()]

        # Lots waiting for Owner Washer Assignment (Stitching completed -> waiting for Owner to choose Washer)
        cursor.execute("""
            SELECT l.id as lot_id, l.lot_number, l.total_cut_pieces, l.dealer_name,
                   d.name as design_name, d.design_number
            FROM lots l
            JOIN designs d ON l.design_id = d.id
            WHERE l.current_department_id = 6 AND (
                SELECT COUNT(*) FROM lot_process_routes wr 
                WHERE wr.lot_id = l.id AND wr.department_id = 6 AND wr.worker_id IS NOT NULL
            ) = 0
            ORDER BY l.id DESC;
        """)
        waiting_washers = [dict(r) for r in cursor.fetchall()]

        # Active Washers list for assignment dropdown
        cursor.execute("SELECT id, full_name, phone FROM workers WHERE department_id = 6 AND is_active = 1;")
        available_washers = [dict(r) for r in cursor.fetchall()]

        # Active Lots & Location breakdown
        cursor.execute("""
            SELECT 
                l.id, l.lot_number, l.total_cut_pieces, l.current_status, l.is_urgent, l.dealer_name,
                l.remnant_fabric_meters, l.due_date,
                d.name as design_name, d.design_number,
                dept.name as current_department_name, dept.name_gu as current_department_name_gu, dept.name_hi as current_department_name_hi, dept.code as department_code
            FROM lots l
            JOIN designs d ON l.design_id = d.id
            JOIN departments dept ON l.current_department_id = dept.id
            ORDER BY l.is_urgent DESC, l.id DESC;
        """)
        active_lots = [dict(r) for r in cursor.fetchall()]

        # Finished Stock in Godown
        cursor.execute("SELECT COALESCE(SUM(available_pieces), 0) FROM finished_stock;")
        godown_stock = cursor.fetchone()[0]

        # Recent Notifications
        cursor.execute("""
            SELECT id, title, message, notification_type, is_read, created_at
            FROM notifications WHERE target_role = 'OWNER'
            ORDER BY id DESC LIMIT 15;
        """)
        notifications = [dict(r) for r in cursor.fetchall()]

        return {
            "total_workers": total_workers,
            "fabric_summary": fabric_summary,
            "stage_funnel": stage_funnel,
            "waiting_washers": waiting_washers,
            "available_washers": available_washers,
            "godown_stock": godown_stock,
            "active_lots": active_lots,
            "notifications": notifications
        }


# --- WORKERS & ATTENDANCE ---
def list_workers(department_id: Optional[int] = None) -> List[Dict[str, Any]]:
    """Lists workers with real completed piece count, total piece-rate salary earned, and pending due balance."""
    with get_db() as conn:
        cursor = conn.cursor()
        query = """
            SELECT w.id, w.worker_code, w.full_name, w.phone, w.role_designation,
                   w.rate_per_piece, w.daily_wage, w.language_preference, w.is_active,
                   d.name as department_name, d.id as department_id,
                   j.name as jobber_name, m.machine_code,
                   COALESCE((
                       SELECT SUM(l.total_cut_pieces)
                       FROM lot_process_routes r
                       JOIN lots l ON r.lot_id = l.id
                       WHERE r.worker_id = w.id AND r.status = 'COMPLETED'
                   ), 0) as total_pieces_completed,
                   COALESCE((
                       SELECT SUM(p.amount_paid)
                       FROM payments p
                       WHERE p.worker_id = w.id
                   ), 0) as total_paid
            FROM workers w
            LEFT JOIN departments d ON w.department_id = d.id
            LEFT JOIN jobbers j ON w.jobber_id = j.id
            LEFT JOIN machines m ON w.machine_id = m.id
            WHERE w.is_active = 1
        """
        params = []
        if department_id:
            query += " AND w.department_id = ?"
            params.append(department_id)
        query += " ORDER BY w.id ASC;"
        cursor.execute(query, params)
        workers = []
        for r in cursor.fetchall():
            d = dict(r)
            pieces = d.get("total_pieces_completed", 0)
            rate = d.get("rate_per_piece", 0.0)
            paid = d.get("total_paid", 0.0)
            total_salary = round(pieces * rate, 2)
            d["total_salary_earned"] = total_salary
            d["pending_salary"] = round(total_salary - paid, 2)
            workers.append(d)
        return workers


def mark_attendance(worker_id: int, date_str: str, status: str, overtime_hours: float, marked_by: str, notes: Optional[str] = None):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO attendance (worker_id, date, status, overtime_hours, marked_by, notes)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(worker_id, date) DO UPDATE SET
                status = excluded.status,
                overtime_hours = excluded.overtime_hours,
                marked_by = excluded.marked_by,
                notes = excluded.notes;
        """, (worker_id, date_str, status, overtime_hours, marked_by, notes))


def get_monthly_attendance(month_str: str) -> List[Dict[str, Any]]:
    """month_str format: 'YYYY-MM'"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT a.id, a.worker_id, a.date, a.status, a.overtime_hours, a.notes,
                   w.full_name, w.worker_code, d.name as department_name
            FROM attendance a
            JOIN workers w ON a.worker_id = w.id
            LEFT JOIN departments d ON w.department_id = d.id
            WHERE strftime('%Y-%m', a.date) = ?
            ORDER BY a.date DESC, w.id ASC;
        """, (month_str,))
        return [dict(r) for r in cursor.fetchall()]


# --- ORDERS & DISPATCH ---
def list_orders(status_filter: Optional[str] = None) -> List[Dict[str, Any]]:
    with get_db() as conn:
        cursor = conn.cursor()
        query = """
            SELECT o.id, o.order_number, o.total_quantity, o.order_date, o.delivery_due_date,
                   o.current_status, o.priority, o.notes, o.created_at,
                   c.id as customer_id, c.customer_name, c.shop_name, c.phone as customer_phone, c.city as customer_city,
                   d.id as design_id, d.design_number, d.name as design_name,
                   l.lot_number,
                   disp.transport_name, disp.tracking_lr_number, disp.parcel_count, disp.dispatch_date
            FROM orders o
            JOIN customers c ON o.customer_id = c.id
            JOIN designs d ON o.design_id = d.id
            LEFT JOIN lots l ON o.lot_id = l.id
            LEFT JOIN (
                SELECT order_id, transport_name, tracking_lr_number, parcel_count, dispatch_date,
                       ROW_NUMBER() OVER(PARTITION BY order_id ORDER BY id DESC) as rn
                FROM dispatches
            ) disp ON o.id = disp.order_id AND disp.rn = 1
        """
        params = []
        if status_filter:
            query += " WHERE o.current_status = ?"
            params.append(status_filter)
        query += " ORDER BY o.id DESC;"
        cursor.execute(query, params)
        return [dict(r) for r in cursor.fetchall()]


def create_order(order_data: Dict[str, Any], created_by: str = "admin") -> int:
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO orders (
                order_number, customer_id, design_id, lot_id, total_quantity,
                order_date, delivery_due_date, current_status, priority, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 'RECEIVED', ?, ?);
        """, (
            order_data["order_number"], order_data["customer_id"], order_data["design_id"],
            order_data.get("lot_id"), order_data["total_quantity"], str(order_data["order_date"]),
            str(order_data["delivery_due_date"]), order_data.get("priority", "NORMAL"),
            order_data.get("notes")
        ))
        order_id = cursor.lastrowid

        # Insert status history
        cursor.execute("""
            INSERT INTO order_status_history (order_id, status, updated_by, notes)
            VALUES (?, 'RECEIVED', ?, 'Initial order entered');
        """, (order_id, created_by))

        # Create system notification
        cursor.execute("""
            INSERT INTO notifications (target_role, title, message, notification_type, reference_id)
            VALUES ('OWNER', ?, ?, 'NEW_ORDER', ?);
        """, (f"New Order: {order_data['order_number']}", f"Received order for {order_data['total_quantity']} pcs.", order_id))

        return order_id


def update_order_status(order_id: int, new_status: str, updated_by: str, notes: Optional[str] = None):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("UPDATE orders SET current_status = ? WHERE id = ?;", (new_status, order_id))
        cursor.execute("""
            INSERT INTO order_status_history (order_id, status, updated_by, notes)
            VALUES (?, ?, ?, ?);
        """, (order_id, new_status, updated_by, notes))


def create_dispatch(dispatch_data: Dict[str, Any], created_by: str = "admin") -> int:
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO dispatches (
                order_id, dispatch_number, dispatched_quantity, parcel_count,
                transport_name, tracking_lr_number, dispatch_date, packed_by, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, (
            dispatch_data["order_id"], dispatch_data["dispatch_number"],
            dispatch_data["dispatched_quantity"], dispatch_data.get("parcel_count", 1),
            dispatch_data["transport_name"], dispatch_data.get("tracking_lr_number"),
            str(dispatch_data["dispatch_date"]), dispatch_data.get("packed_by"),
            dispatch_data.get("notes")
        ))
        dispatch_id = cursor.lastrowid

        # Update order status to DISPATCHED
        cursor.execute("UPDATE orders SET current_status = 'DISPATCHED' WHERE id = ?;", (dispatch_data["order_id"],))
        cursor.execute("""
            INSERT INTO order_status_history (order_id, status, updated_by, notes)
            VALUES (?, 'DISPATCHED', ?, ?);
        """, (dispatch_data["order_id"], created_by, f"Dispatched via {dispatch_data['transport_name']} LR#{dispatch_data.get('tracking_lr_number')}"))

        return dispatch_id


# --- MANUFACTURING & LOT TRACKING ---
def create_lot(lot_data: Dict[str, Any], created_by: str = "admin") -> int:
    with get_db() as conn:
        cursor = conn.cursor()
        cutting_cost = lot_data["total_cut_pieces"] * lot_data.get("cutting_rate_per_piece", 6.0)

        cursor.execute("""
            INSERT INTO lots (
                lot_number, design_id, fabric_inward_id, meters_consumed,
                cutting_master_worker_id, cutting_date, total_cut_pieces,
                current_department_id, current_status, cutting_rate_per_piece,
                cutting_total_cost, target_completion_date
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 2, 'CUTTING', ?, ?, ?);
        """, (
            lot_data["lot_number"], lot_data["design_id"], lot_data.get("fabric_inward_id"),
            lot_data.get("meters_consumed", 0.0), lot_data.get("cutting_master_worker_id"),
            str(lot_data["cutting_date"]), lot_data["total_cut_pieces"],
            lot_data.get("cutting_rate_per_piece", 6.0), cutting_cost,
            str(lot_data["target_completion_date"]) if lot_data.get("target_completion_date") else None
        ))
        lot_id = cursor.lastrowid

        # Update fabric meters used if inward is linked
        if lot_data.get("fabric_inward_id") and lot_data.get("meters_consumed", 0.0) > 0:
            cursor.execute("""
                UPDATE fabric_inward
                SET meters_used = meters_used + ?,
                    remaining_meters = remaining_meters - ?
                WHERE id = ?;
            """, (lot_data["meters_consumed"], lot_data["meters_consumed"], lot_data["fabric_inward_id"]))

        # Check design to build flexible route
        cursor.execute("SELECT has_embroidery, has_screen_print FROM designs WHERE id = ?;", (lot_data["design_id"],))
        design = cursor.fetchone()
        
        # Build route: Cutting(2) -> Stitching(3)
        route = [(1, 2), (2, 3)]
        seq = 3
        if design and design["has_screen_print"]:
            route.append((seq, 4)) # Screen printing
            seq += 1
        if design and design["has_embroidery"]:
            route.append((seq, 5)) # Embroidery
            seq += 1
        route.append((seq, 6)) # Washing
        route.append((seq + 1, 7)) # Gaaj-Button
        route.append((seq + 2, 8)) # Press & Packing
        route.append((seq + 3, 9)) # Finished Godown

        for stg_seq, dept_id in route:
            status = 'COMPLETED' if dept_id == 2 else ('IN_PROGRESS' if dept_id == 3 else 'PENDING')
            cursor.execute("""
                INSERT INTO lot_process_routes (lot_id, stage_sequence, department_id, status)
                VALUES (?, ?, ?, ?);
            """, (lot_id, stg_seq, dept_id, status))

        # Initialize lot cost sheet
        cursor.execute("""
            INSERT INTO lot_cost_sheets (lot_id, cutting_cost, total_lot_cost, cost_per_piece)
            VALUES (?, ?, ?, ?);
        """, (lot_id, cutting_cost, cutting_cost, cutting_cost / lot_data["total_cut_pieces"]))

        return lot_id


def send_lot_movement(movement_data: Dict[str, Any]) -> int:
    """Enforces: Department cannot send more pieces than cut/received in the lot."""
    with get_db() as conn:
        cursor = conn.cursor()
        lot_id = movement_data["lot_id"]
        sent_qty = movement_data["sent_quantity"]

        # Validate lot total pieces
        cursor.execute("SELECT total_cut_pieces, lot_number FROM lots WHERE id = ?;", (lot_id,))
        lot = cursor.fetchone()
        if not lot:
            raise ValueError(f"Lot with ID {lot_id} does not exist.")
        if sent_qty > lot["total_cut_pieces"]:
            raise ValueError(f"Cannot dispatch {sent_qty} pieces. Total lot cut pieces is only {lot['total_cut_pieces']}.")

        movement_number = f"MOV-{datetime.datetime.now().strftime('%m%d%H%M%S')}"
        cursor.execute("""
            INSERT INTO lot_movements (
                movement_number, lot_id, from_department_id, to_department_id,
                sent_by_worker_id, sent_quantity, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?);
        """, (
            movement_number, lot_id, movement_data["from_department_id"],
            movement_data["to_department_id"], movement_data.get("sent_by_worker_id"),
            sent_qty, movement_data.get("notes")
        ))
        return cursor.lastrowid


def confirm_lot_movement(movement_id: int, received_by_worker_id: int, received_quantity: int, shortage_reason: Optional[str] = None):
    """Next department counts pieces and confirms. Spots shortages immediately!"""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT lot_id, sent_quantity, to_department_id FROM lot_movements WHERE id = ?;", (movement_id,))
        mov = cursor.fetchone()
        if not mov:
            raise ValueError("Movement record not found.")

        shortage = mov["sent_quantity"] - received_quantity
        if shortage < 0:
            shortage = 0 # Received surplus, no shortage

        now = datetime.datetime.now().isoformat()
        cursor.execute("""
            UPDATE lot_movements
            SET received_by_worker_id = ?,
                received_quantity = ?,
                received_timestamp = ?,
                shortage_quantity = ?,
                shortage_reason = ?,
                is_confirmed = 1
            WHERE id = ?;
        """, (received_by_worker_id, received_quantity, now, shortage, shortage_reason, movement_id))

        # Update Lot's current department
        cursor.execute("""
            UPDATE lots SET current_department_id = ? WHERE id = ?;
        """, (mov["to_department_id"], mov["lot_id"]))

        # If shortage spotted, alert owner immediately!
        if shortage > 0:
            cursor.execute("""
                INSERT INTO notifications (target_role, title, message, notification_type, reference_id)
                VALUES ('OWNER', 'Shortage Detected!', ?, 'SHORTAGE', ?);
            """, (f"Shortage of {shortage} pcs detected during handover. Reason: {shortage_reason or 'Not specified'}", mov["lot_id"]))


# --- KARIGAR PRODUCTION & TIME/SPEED RECORDING ---
def start_karigar_production(start_data: Dict[str, Any]) -> int:
    with get_db() as conn:
        cursor = conn.cursor()
        now = datetime.datetime.now().isoformat()
        bundle_size = start_data.get("bundle_size", 20)
        cursor.execute("""
            INSERT INTO production_records (
                lot_id, department_id, jobber_id, machine_id, worker_id,
                pieces_assigned, rate_per_piece, bundle_size, start_time, status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'IN_PROGRESS');
        """, (
            start_data["lot_id"], start_data["department_id"], start_data.get("jobber_id"),
            start_data.get("machine_id"), start_data["worker_id"], start_data["pieces_assigned"],
            start_data.get("rate_per_piece", 45.0), bundle_size, now
        ))
        return cursor.lastrowid


def pause_karigar_production(production_id: int, break_reason: str, worker_id: Optional[int] = None) -> int:
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, worker_id, is_paused FROM production_records WHERE id = ?;", (production_id,))
        rec = cursor.fetchone()
        if not rec:
            raise ValueError("Production entry not found.")
        if rec["is_paused"]:
            return -1 # Already paused

        w_id = worker_id or rec["worker_id"]
        now = datetime.datetime.now().isoformat()
        cursor.execute("""
            UPDATE production_records
            SET is_paused = 1,
                current_pause_start = ?,
                current_pause_reason = ?
            WHERE id = ?;
        """, (now, break_reason, production_id))

        cursor.execute("""
            INSERT INTO production_breaks (
                production_id, worker_id, break_reason, started_at
            ) VALUES (?, ?, ?, ?);
        """, (production_id, w_id, break_reason, now))
        return cursor.lastrowid


def resume_karigar_production(production_id: int):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT id, is_paused, current_pause_start, total_pause_minutes FROM production_records WHERE id = ?;", (production_id,))
        rec = cursor.fetchone()
        if not rec:
            raise ValueError("Production entry not found.")
        if not rec["is_paused"]:
            return # Already running

        now = datetime.datetime.now()
        # Find the open break record
        cursor.execute("""
            SELECT id, started_at FROM production_breaks 
            WHERE production_id = ? AND ended_at IS NULL 
            ORDER BY id DESC LIMIT 1;
        """, (production_id,))
        open_break = cursor.fetchone()

        duration_mins = 0
        if open_break and open_break["started_at"]:
            start_dt = datetime.datetime.fromisoformat(open_break["started_at"])
            duration_mins = max(1, int((now - start_dt).total_seconds() / 60))
            cursor.execute("""
                UPDATE production_breaks
                SET ended_at = ?,
                    duration_minutes = ?
                WHERE id = ?;
            """, (now.isoformat(), duration_mins, open_break["id"]))

        new_total_pause = (rec["total_pause_minutes"] or 0) + duration_mins
        cursor.execute("""
            UPDATE production_records
            SET is_paused = 0,
                current_pause_start = NULL,
                current_pause_reason = NULL,
                total_pause_minutes = ?
            WHERE id = ?;
        """, (new_total_pause, production_id))


def save_bundle_progress(production_id: int, bundles_count: int, bundle_size: int = 20, loose_pieces: int = 0, pieces_altered: int = 0, is_completed: bool = False) -> Dict[str, Any]:
    lot_id = None
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM production_records WHERE id = ?;", (production_id,))
        rec = cursor.fetchone()
        if not rec:
            raise ValueError("Production entry not found.")

        lot_id = rec["lot_id"]
        completed_qty = (bundles_count * bundle_size) + loose_pieces
        now = datetime.datetime.now()
        start_time_dt = datetime.datetime.fromisoformat(rec["start_time"]) if rec["start_time"] else now

        gross_minutes = max(1, int((now - start_time_dt).total_seconds() / 60))
        total_pause = rec["total_pause_minutes"] or 0
        if rec["is_paused"] and rec["current_pause_start"]:
            pause_start_dt = datetime.datetime.fromisoformat(rec["current_pause_start"])
            total_pause += max(0, int((now - pause_start_dt).total_seconds() / 60))

        net_active_minutes = max(1, gross_minutes - total_pause)
        net_speed_pcs_hr = round(completed_qty / (net_active_minutes / 60.0), 2) if net_active_minutes > 0 else 0.0
        total_earned = round(completed_qty * rec["rate_per_piece"], 2)

        status = 'COMPLETED' if is_completed else 'IN_PROGRESS'
        complete_time = now.isoformat() if is_completed else rec["complete_time"]

        cursor.execute("""
            UPDATE production_records
            SET bundles_count = ?,
                bundle_size = ?,
                loose_pieces = ?,
                pieces_completed = ?,
                pieces_altered = ?,
                total_earned = ?,
                complete_time = ?,
                total_duration_minutes = ?,
                production_speed_pcs_per_hr = ?,
                status = ?,
                is_paused = 0,
                current_pause_start = NULL
            WHERE id = ?;
        """, (
            bundles_count, bundle_size, loose_pieces, completed_qty, pieces_altered,
            total_earned, complete_time, net_active_minutes, net_speed_pcs_hr, status, production_id
        ))

    if is_completed and lot_id:
        recalculate_lot_cost(lot_id)

    return {
        "production_id": production_id,
        "completed_pieces": completed_qty,
        "bundles_count": bundles_count,
        "bundle_size": bundle_size,
        "loose_pieces": loose_pieces,
        "net_active_minutes": net_active_minutes,
        "net_speed_pcs_hr": net_speed_pcs_hr,
        "total_earned": total_earned,
        "status": status
    }


def complete_karigar_production(production_id: int, completed_qty: int, altered_qty: int = 0):
    lot_id = None
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM production_records WHERE id = ?;", (production_id,))
        rec = cursor.fetchone()
        if not rec:
            raise ValueError("Production entry not found.")

        lot_id = rec["lot_id"]
        now = datetime.datetime.now()
        start_time_dt = datetime.datetime.fromisoformat(rec["start_time"]) if rec["start_time"] else now
        gross_minutes = max(1, int((now - start_time_dt).total_seconds() / 60))
        total_pause = rec["total_pause_minutes"] or 0
        net_active_minutes = max(1, gross_minutes - total_pause)
        speed_pcs_hr = round((completed_qty / (net_active_minutes / 60.0)), 2) if net_active_minutes > 0 else 0.0
        total_earned = round(completed_qty * rec["rate_per_piece"], 2)

        # Estimate bundles if bundle_size set
        bundle_size = rec["bundle_size"] or 20
        bundles_count = completed_qty // bundle_size
        loose_pieces = completed_qty % bundle_size

        cursor.execute("""
            UPDATE production_records
            SET pieces_completed = ?,
                pieces_altered = ?,
                bundles_count = ?,
                loose_pieces = ?,
                total_earned = ?,
                complete_time = ?,
                total_duration_minutes = ?,
                production_speed_pcs_per_hr = ?,
                status = 'COMPLETED',
                is_paused = 0,
                current_pause_start = NULL
            WHERE id = ?;
        """, (completed_qty, altered_qty, bundles_count, loose_pieces, total_earned, now.isoformat(), net_active_minutes, speed_pcs_hr, production_id))

    if lot_id:
        recalculate_lot_cost(lot_id)


# --- ALTERATIONS TRACKING & NOTIFICATIONS ---
def log_alteration(alt_data: Dict[str, Any]) -> int:
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO alterations (
                lot_id, department_id, worker_id, alteration_pieces,
                defect_type, defect_description, reported_by_worker_id, notification_sent
            ) VALUES (?, ?, ?, ?, ?, ?, ?, 1);
        """, (
            alt_data["lot_id"], alt_data["department_id"], alt_data["worker_id"],
            alt_data["alteration_pieces"], alt_data["defect_type"],
            alt_data.get("defect_description"), alt_data.get("reported_by_worker_id")
        ))
        alt_id = cursor.lastrowid

        # Dispatch real-time notification to the worker
        cursor.execute("""
            INSERT INTO notifications (target_role, target_worker_id, title, message, notification_type, reference_id)
            VALUES ('WORKER', ?, 'Alteration Required', ?, 'ALTERATION', ?);
        """, (
            alt_data["worker_id"],
            f"{alt_data['alteration_pieces']} pieces alteration detected ({alt_data['defect_type']}). Please rectify.",
            alt_id
        ))

        return alt_id


def rectify_alteration(alt_id: int, rectified_pieces: Optional[int] = None):
    with get_db() as conn:
        cursor = conn.cursor()
        now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        if rectified_pieces is not None:
            cursor.execute("""
                UPDATE alterations
                SET status = 'RECTIFIED', rectified_pieces = ?, rectified_at = ?
                WHERE id = ?;
            """, (rectified_pieces, now, alt_id))
        else:
            cursor.execute("""
                UPDATE alterations
                SET status = 'RECTIFIED', rectified_pieces = alteration_pieces, rectified_at = ?
                WHERE id = ?;
            """, (now, alt_id))


# --- LOT COST SHEET CALCULATION ---
def recalculate_lot_cost(lot_id: int):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT total_cut_pieces, meters_consumed, cutting_total_cost, fabric_inward_id FROM lots WHERE id = ?;", (lot_id,))
        lot = cursor.fetchone()
        if not lot:
            return

        total_pieces = lot["total_cut_pieces"]
        cutting_cost = lot["cutting_total_cost"]

        # Calculate fabric cost
        fabric_cost = 0.0
        if lot["fabric_inward_id"]:
            cursor.execute("SELECT rate_per_meter FROM fabric_inward WHERE id = ?;", (lot["fabric_inward_id"],))
            fab = cursor.fetchone()
            if fab:
                fabric_cost = lot["meters_consumed"] * fab["rate_per_meter"]

        # Calculate stitching total from production records
        cursor.execute("""
            SELECT COALESCE(SUM(total_earned), 0.0) FROM production_records 
            WHERE lot_id = ? AND department_id = 3;
        """, (lot_id,))
        stitching_cost = cursor.fetchone()[0]

        # Calculate washing, gaaj-button, press-pack estimates from design rates
        cursor.execute("""
            SELECT d.standard_washing_rate, d.standard_gaaj_button_rate, d.standard_press_packing_rate
            FROM designs d JOIN lots l ON l.design_id = d.id WHERE l.id = ?;
        """, (lot_id,))
        design_rates = cursor.fetchone()

        washing_cost = total_pieces * (design_rates["standard_washing_rate"] if design_rates else 5.0)
        gaaj_button_cost = total_pieces * (design_rates["standard_gaaj_button_rate"] if design_rates else 4.0)
        press_packing_cost = total_pieces * (design_rates["standard_press_packing_rate"] if design_rates else 7.0)
        accessories_cost = total_pieces * 12.0 # Standard thread, collar fusion, buttons, polybag

        total_lot_cost = fabric_cost + cutting_cost + stitching_cost + washing_cost + gaaj_button_cost + press_packing_cost + accessories_cost
        cost_per_piece = round(total_lot_cost / total_pieces, 2) if total_pieces > 0 else 0.0

        cursor.execute("""
            INSERT INTO lot_cost_sheets (
                lot_id, fabric_cost, cutting_cost, stitching_cost, washing_cost,
                gaaj_button_cost, pressing_packing_cost, accessories_cost, total_lot_cost, cost_per_piece
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(lot_id) DO UPDATE SET
                fabric_cost = excluded.fabric_cost,
                cutting_cost = excluded.cutting_cost,
                stitching_cost = excluded.stitching_cost,
                washing_cost = excluded.washing_cost,
                gaaj_button_cost = excluded.gaaj_button_cost,
                pressing_packing_cost = excluded.pressing_packing_cost,
                accessories_cost = excluded.accessories_cost,
                total_lot_cost = excluded.total_lot_cost,
                cost_per_piece = excluded.cost_per_piece,
                calculated_at = CURRENT_TIMESTAMP;
        """, (lot_id, fabric_cost, cutting_cost, stitching_cost, washing_cost, gaaj_button_cost, press_packing_cost, accessories_cost, total_lot_cost, cost_per_piece))


def get_lot_cost_sheet(lot_id: int) -> Optional[Dict[str, Any]]:
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT c.*, l.lot_number, l.total_cut_pieces, d.design_number, d.name as design_name
            FROM lot_cost_sheets c
            JOIN lots l ON c.lot_id = l.id
            JOIN designs d ON l.design_id = d.id
            WHERE c.lot_id = ?;
        """, (lot_id,))
        row = cursor.fetchone()
        return dict(row) if row else None

# --- ADDITIONAL CRUD & ANALYTICS FOR FULL APPLICATION MODULES ---

def list_lots() -> List[Dict[str, Any]]:
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT l.*, d.name as design_name, d.design_number,
                   dept.name as current_department_name, dept.name_gu as current_department_name_gu,
                   dept.name_hi as current_department_name_hi, dept.code as department_code,
                   w_cut.full_name as cutting_master_name, w_cut.phone as cutting_master_phone,
                   f.fabric_type, f.inward_number
            FROM lots l
            JOIN designs d ON l.design_id = d.id
            JOIN departments dept ON l.current_department_id = dept.id
            LEFT JOIN workers w_cut ON l.cutting_master_worker_id = w_cut.id
            LEFT JOIN fabric_inward f ON l.fabric_inward_id = f.id
            ORDER BY l.id DESC;
        """)
        raw_lots = [dict(r) for r in cursor.fetchall()]

        for lot in raw_lots:
            lid = lot["id"]
            curr_dept_id = lot["current_department_id"]

            # 1. Determine active worker for current department
            cursor.execute("""
                SELECT w.id, w.full_name, w.phone, w.role_designation, pr.pieces_assigned, pr.pieces_completed
                FROM production_records pr
                JOIN workers w ON pr.worker_id = w.id
                WHERE pr.lot_id = ? AND pr.department_id = ?
                ORDER BY pr.id DESC;
            """, (lid, curr_dept_id))
            dept_workers = [dict(w) for w in cursor.fetchall()]

            if not dept_workers:
                cursor.execute("""
                    SELECT w.id, w.full_name, w.phone, w.role_designation
                    FROM lot_process_routes r
                    JOIN workers w ON r.worker_id = w.id
                    WHERE r.lot_id = ? AND r.department_id = ?;
                """, (lid, curr_dept_id))
                dept_workers = [dict(w) for w in cursor.fetchall()]

            if not dept_workers:
                if curr_dept_id == 2:  # Cutting Master
                    cursor.execute("SELECT id, full_name, phone, role_designation FROM workers WHERE role_designation LIKE '%Cutting%' ORDER BY id ASC LIMIT 1;")
                    dept_workers = [dict(w) for w in cursor.fetchall()]
                elif curr_dept_id == 6:  # Washing
                    cursor.execute("SELECT id, full_name, phone, role_designation FROM workers WHERE role_designation LIKE '%Washer%' ORDER BY id ASC LIMIT 1;")
                    dept_workers = [dict(w) for w in cursor.fetchall()]
                elif curr_dept_id == 7:  # Gaaj-Button
                    cursor.execute("SELECT id, full_name, phone, role_designation FROM workers WHERE role_designation LIKE '%Gaaj%' ORDER BY id ASC LIMIT 1;")
                    dept_workers = [dict(w) for w in cursor.fetchall()]
                elif curr_dept_id == 8:  # Press & Packing
                    cursor.execute("SELECT id, full_name, phone, role_designation FROM workers WHERE role_designation LIKE '%Press%' ORDER BY id ASC LIMIT 1;")
                    dept_workers = [dict(w) for w in cursor.fetchall()]
                elif curr_dept_id == 3:  # Stitching
                    cursor.execute("SELECT id, full_name, phone, role_designation FROM workers WHERE role_designation LIKE '%Stitcher%' ORDER BY id ASC LIMIT 1;")
                    dept_workers = [dict(w) for w in cursor.fetchall()]

            lot["current_workers"] = dept_workers
            if dept_workers:
                lot["current_worker_name"] = dept_workers[0]["full_name"]
                lot["current_worker_phone"] = dept_workers[0]["phone"]
                lot["current_worker_role"] = dept_workers[0]["role_designation"]
            else:
                lot["current_worker_name"] = "Pending Assignment"
                lot["current_worker_phone"] = ""
                lot["current_worker_role"] = ""

            # 2. Parse Color Breakdown
            cb_raw = lot.get("color_breakdown") or "Sky Blue: 200, Navy: 180, White: 120"
            cb_list = []
            if cb_raw:
                parts = [p.strip() for p in cb_raw.replace(";", ",").split(",") if p.strip()]
                for p in parts:
                    if ":" in p:
                        cname, cpcs = p.split(":", 1)
                        try:
                            pcs_val = int(cpcs.strip().replace("pcs", "").replace("pieces", "").strip())
                        except ValueError:
                            pcs_val = 0
                        cb_list.append({"color": cname.strip(), "pieces": pcs_val})
                    else:
                        cb_list.append({"color": p.strip(), "pieces": 0})
            lot["color_breakdown_parsed"] = cb_list
            lot["color_breakdown_text"] = cb_raw

        return raw_lots


def get_lot_details(lot_id: int) -> Optional[Dict[str, Any]]:
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT l.*, d.name as design_name, d.design_number,
                   dept.name as current_department_name, dept.name_hi as current_dept_name_hi, dept.name_gu as current_dept_name_gu, dept.code as department_code,
                   w.full_name as cutting_master_name
            FROM lots l
            JOIN designs d ON l.design_id = d.id
            JOIN departments dept ON l.current_department_id = dept.id
            LEFT JOIN workers w ON l.cutting_master_worker_id = w.id
            WHERE l.id = ?;
        """, (lot_id,))
        lot = cursor.fetchone()
        if not lot:
            return None
        res = dict(lot)

        # Fetch routes
        cursor.execute("""
            SELECT r.*, d.name as department_name, d.name_hi as department_name_hi, d.name_gu as department_name_gu, d.code as department_code
            FROM lot_process_routes r
            JOIN departments d ON r.department_id = d.id
            WHERE r.lot_id = ?
            ORDER BY r.stage_sequence ASC;
        """, (lot_id,))
        res["routes"] = [dict(r) for r in cursor.fetchall()]

        # Fetch movements
        cursor.execute("""
            SELECT m.*, fd.name as from_dept_name, td.name as to_dept_name,
                   sw.full_name as sender_name, rw.full_name as receiver_name
            FROM lot_movements m
            JOIN departments fd ON m.from_department_id = fd.id
            JOIN departments td ON m.to_department_id = td.id
            LEFT JOIN workers sw ON m.sent_by_worker_id = sw.id
            LEFT JOIN workers rw ON m.received_by_worker_id = rw.id
            WHERE m.lot_id = ?
            ORDER BY m.id DESC;
        """, (lot_id,))
        res["movements"] = [dict(r) for r in cursor.fetchall()]

        # Fetch production records
        cursor.execute("""
            SELECT p.*, w.full_name as worker_name, w.worker_code, m.machine_code, j.name as jobber_name
            FROM production_records p
            JOIN workers w ON p.worker_id = w.id
            LEFT JOIN machines m ON p.machine_id = m.id
            LEFT JOIN jobbers j ON p.jobber_id = j.id
            WHERE p.lot_id = ?
            ORDER BY p.id DESC;
        """, (lot_id,))
        res["productions"] = [dict(r) for r in cursor.fetchall()]

        # Fetch alterations
        cursor.execute("""
            SELECT a.*, w.full_name as worker_name, dept.name as department_name
            FROM alterations a
            JOIN workers w ON a.worker_id = w.id
            JOIN departments dept ON a.department_id = dept.id
            WHERE a.lot_id = ?
            ORDER BY a.id DESC;
        """, (lot_id,))
        res["alterations"] = [dict(r) for r in cursor.fetchall()]

        # Fetch cost sheet
        cursor.execute("SELECT * FROM lot_cost_sheets WHERE lot_id = ?;", (lot_id,))
        cost = cursor.fetchone()
        res["cost_sheet"] = dict(cost) if cost else None

        return res


def list_fabric_inward() -> List[Dict[str, Any]]:
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM fabric_inward ORDER BY id DESC;")
        return [dict(r) for r in cursor.fetchall()]


def create_fabric_inward(data: Dict[str, Any]) -> int:
    with get_db() as conn:
        cursor = conn.cursor()
        total_cost = data["meters_received"] * data.get("rate_per_meter", 0.0)
        cursor.execute("""
            INSERT INTO fabric_inward (
                inward_number, supplier_name, challan_number, fabric_type,
                color_shade, rolls_count, meters_received, rate_per_meter,
                total_fabric_cost, meters_used, remaining_meters, inward_date, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0.0, ?, ?, ?);
        """, (
            data["inward_number"], data["supplier_name"], data.get("challan_number"),
            data["fabric_type"], data.get("color_shade"), data.get("rolls_count", 1),
            data["meters_received"], data.get("rate_per_meter", 0.0), total_cost,
            data["meters_received"], str(data["inward_date"]), data.get("notes")
        ))
        return cursor.lastrowid


def list_jobbers() -> List[Dict[str, Any]]:
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT j.*, COUNT(m.id) as machine_count
            FROM jobbers j
            LEFT JOIN machines m ON j.id = m.jobber_id AND m.is_active = 1
            WHERE j.is_active = 1
            GROUP BY j.id;
        """)
        return [dict(r) for r in cursor.fetchall()]


def list_machines() -> List[Dict[str, Any]]:
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT m.*, j.name as jobber_name
            FROM machines m
            LEFT JOIN jobbers j ON m.jobber_id = j.id
            WHERE m.is_active = 1
            ORDER BY m.machine_code ASC;
        """)
        return [dict(r) for r in cursor.fetchall()]


def list_finished_stock() -> List[Dict[str, Any]]:
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT s.*, d.design_number, d.name as design_name, d.fabric_type,
                   l.lot_number, l.total_cut_pieces
            FROM finished_stock s
            JOIN designs d ON s.design_id = d.id
            LEFT JOIN lots l ON s.lot_id = l.id
            ORDER BY s.id DESC;
        """)
        return [dict(r) for r in cursor.fetchall()]


def inward_finished_stock(design_id: int, lot_id: int, pieces: int, boxes: int, notes: Optional[str] = None):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO finished_stock (design_id, lot_id, available_pieces, packed_boxes, last_updated)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(design_id, lot_id) DO UPDATE SET
                available_pieces = available_pieces + excluded.available_pieces,
                packed_boxes = packed_boxes + excluded.packed_boxes,
                last_updated = CURRENT_TIMESTAMP;
        """, (design_id, lot_id, pieces, boxes))

        cursor.execute("""
            INSERT INTO stock_movements (design_id, lot_id, movement_type, quantity)
            VALUES (?, ?, 'INWARD_FROM_PRODUCTION', ?);
        """, (design_id, lot_id, pieces))

        # Update lot status to COMPLETED_GODOWN
        if lot_id:
            cursor.execute("UPDATE lots SET current_status = 'COMPLETED_GODOWN', current_department_id = 9, completed_at = CURRENT_TIMESTAMP WHERE id = ?;", (lot_id,))


def list_payments() -> List[Dict[str, Any]]:
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT p.*, w.full_name as worker_name, w.worker_code,
                   j.name as jobber_name, l.lot_number
            FROM payments p
            LEFT JOIN workers w ON p.worker_id = w.id
            LEFT JOIN jobbers j ON p.jobber_id = j.id
            LEFT JOIN lots l ON p.lot_id = l.id
            ORDER BY p.id DESC;
        """)
        return [dict(r) for r in cursor.fetchall()]


def record_payment(payment_data: Dict[str, Any]) -> int:
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO payments (
                payee_type, worker_id, jobber_id, lot_id,
                amount_paid, payment_date, payment_mode, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?);
        """, (
            payment_data["payee_type"], payment_data.get("worker_id"),
            payment_data.get("jobber_id"), payment_data.get("lot_id"),
            payment_data["amount_paid"], str(payment_data["payment_date"]),
            payment_data.get("payment_mode", "CASH"), payment_data.get("notes")
        ))
        return cursor.lastrowid


# --- COMPREHENSIVE ANALYTICS ENGINE (PROMPT 5) ---
def get_analytics_report(start_date: Optional[str] = None, end_date: Optional[str] = None) -> Dict[str, Any]:
    with get_db() as conn:
        cursor = conn.cursor()

        date_filter_orders = ""
        params_orders = []
        if start_date and end_date:
            date_filter_orders = "WHERE order_date BETWEEN ? AND ?"
            params_orders = [start_date, end_date]

        date_filter_prod = ""
        params_prod = []
        if start_date and end_date:
            date_filter_prod = "AND DATE(p.start_time) BETWEEN ? AND ?"
            params_prod = [start_date, end_date]

        date_filter_alt = ""
        params_alt = []
        if start_date and end_date:
            date_filter_alt = "WHERE DATE(reported_at) BETWEEN ? AND ?"
            params_alt = [start_date, end_date]

        # 1. Order Status Funnel
        cursor.execute(f"""
            SELECT current_status, COUNT(*) as count, COALESCE(SUM(total_quantity), 0) as total_pieces
            FROM orders
            {date_filter_orders}
            GROUP BY current_status;
        """, params_orders)
        orders_by_status = [dict(r) for r in cursor.fetchall()]

        # 2. Production Speed & Quantity by Karigar
        cursor.execute(f"""
            SELECT w.full_name as karigar_name, w.worker_code,
                   COUNT(p.id) as jobs_count,
                   COALESCE(SUM(p.pieces_completed), 0) as total_pieces,
                   COALESCE(ROUND(AVG(p.production_speed_pcs_per_hr), 1), 0.0) as avg_speed_pcs_hr,
                   COALESCE(SUM(p.total_earned), 0.0) as total_earned
            FROM workers w
            LEFT JOIN production_records p ON w.id = p.worker_id AND p.status = 'COMPLETED' {date_filter_prod}
            WHERE w.is_active = 1 AND w.department_id = 3
            GROUP BY w.id
            ORDER BY total_pieces DESC;
        """, params_prod)
        karigar_performance = [dict(r) for r in cursor.fetchall()]

        # 3. Alteration Issues by Defect Type
        cursor.execute(f"""
            SELECT defect_type, COUNT(*) as incident_count, COALESCE(SUM(alteration_pieces), 0) as total_pieces
            FROM alterations
            {date_filter_alt}
            GROUP BY defect_type
            ORDER BY total_pieces DESC;
        """, params_alt)
        alterations_by_defect = [dict(r) for r in cursor.fetchall()]

        # 4. Lots Distribution across Departments
        cursor.execute("""
            SELECT dept.name as department_name, dept.code as department_code,
                   COUNT(l.id) as lots_count,
                   COALESCE(SUM(l.total_cut_pieces), 0) as total_pieces_in_dept
            FROM departments dept
            LEFT JOIN lots l ON dept.id = l.current_department_id AND l.current_status != 'COMPLETED_GODOWN'
            GROUP BY dept.id
            ORDER BY dept.sequence_order ASC;
        """)
        lots_by_dept = [dict(r) for r in cursor.fetchall()]

        # 5. Cost Comparisons by Lot
        cursor.execute("""
            SELECT l.lot_number, d.name as design_name, l.total_cut_pieces,
                   c.fabric_cost, c.cutting_cost, c.stitching_cost,
                   c.washing_cost, c.gaaj_button_cost, c.pressing_packing_cost,
                   c.accessories_cost, c.total_lot_cost, c.cost_per_piece
            FROM lot_cost_sheets c
            JOIN lots l ON c.lot_id = l.id
            JOIN designs d ON l.design_id = d.id
            ORDER BY c.id DESC LIMIT 10;
        """)
        cost_breakdowns = [dict(r) for r in cursor.fetchall()]

        # 6. Finished Stock Overview
        cursor.execute("""
            SELECT d.design_number, d.name as design_name,
                   COALESCE(SUM(s.available_pieces), 0) as total_in_stock,
                   COALESCE(SUM(s.packed_boxes), 0) as total_boxes
            FROM designs d
            LEFT JOIN finished_stock s ON d.id = s.design_id
            GROUP BY d.id;
        """)
        stock_by_design = [dict(r) for r in cursor.fetchall()]

        # 7. Daily Production Output Trend
        prod_trend_query = """
            SELECT DATE(p.start_time) as date,
                   COALESCE(SUM(p.pieces_completed), 0) as pieces_completed,
                   COUNT(DISTINCT p.worker_id) as active_workers,
                   COALESCE(ROUND(AVG(p.production_speed_pcs_per_hr), 1), 0.0) as avg_speed
            FROM production_records p
            WHERE p.status = 'COMPLETED'
        """
        trend_params = []
        if start_date and end_date:
            prod_trend_query += " AND DATE(p.start_time) BETWEEN ? AND ?"
            trend_params = [start_date, end_date]
        prod_trend_query += " GROUP BY DATE(p.start_time) ORDER BY date ASC LIMIT 31;"
        cursor.execute(prod_trend_query, trend_params)
        daily_trend = [dict(r) for r in cursor.fetchall()]

        # 8. Summary KPIs
        total_pieces_produced = sum(k["total_pieces"] for k in karigar_performance)
        total_wages_earned = round(sum(k["total_earned"] for k in karigar_performance), 2)
        speeds = [k["avg_speed_pcs_hr"] for k in karigar_performance if k["avg_speed_pcs_hr"] > 0]
        overall_avg_speed = round(sum(speeds) / len(speeds), 1) if speeds else 0.0
        active_workers_count = len([k for k in karigar_performance if k["total_pieces"] > 0])
        total_altered = sum(a["total_pieces"] for a in alterations_by_defect)
        defect_rate = round((total_altered / (total_pieces_produced + total_altered) * 100), 1) if (total_pieces_produced + total_altered) > 0 else 0.0
        total_orders_count = sum(o["count"] for o in orders_by_status)
        total_orders_pieces = sum(o["total_pieces"] for o in orders_by_status)

        summary_kpis = {
            "total_pieces_produced": total_pieces_produced,
            "total_wages_earned": total_wages_earned,
            "overall_avg_speed": overall_avg_speed,
            "active_workers_count": active_workers_count,
            "total_altered_pieces": total_altered,
            "defect_rate_percent": defect_rate,
            "total_orders_count": total_orders_count,
            "total_orders_pieces": total_orders_pieces,
            "start_date": start_date,
            "end_date": end_date
        }

        # 9. Production Logs (for CSV export)
        prod_log_query = """
            SELECT p.id, DATE(p.start_time) as work_date, l.lot_number, d.name as design_name,
                   dept.name as department_name, w.full_name as worker_name, w.worker_code,
                   m.machine_code, p.pieces_assigned, p.pieces_completed, p.pieces_altered,
                   p.total_duration_minutes, p.production_speed_pcs_per_hr, p.total_earned, p.status
            FROM production_records p
            JOIN lots l ON p.lot_id = l.id
            JOIN designs d ON l.design_id = d.id
            JOIN departments dept ON p.department_id = dept.id
            JOIN workers w ON p.worker_id = w.id
            LEFT JOIN machines m ON p.machine_id = m.id
        """
        prod_log_params = []
        if start_date and end_date:
            prod_log_query += " WHERE DATE(p.start_time) BETWEEN ? AND ?"
            prod_log_params = [start_date, end_date]
        prod_log_query += " ORDER BY p.id DESC LIMIT 500;"
        cursor.execute(prod_log_query, prod_log_params)
        production_logs = [dict(r) for r in cursor.fetchall()]

        # 10. Orders & Dispatch Logs (for CSV export)
        orders_log_query = """
            SELECT o.order_number, c.customer_name, c.city as customer_city, d.name as design_name,
                   o.total_quantity, o.order_date, o.delivery_due_date, o.current_status, o.priority,
                   disp.transport_name, disp.tracking_lr_number, disp.parcel_count, disp.dispatch_date
            FROM orders o
            JOIN customers c ON o.customer_id = c.id
            JOIN designs d ON o.design_id = d.id
            LEFT JOIN (
                SELECT order_id, transport_name, tracking_lr_number, parcel_count, dispatch_date,
                       ROW_NUMBER() OVER(PARTITION BY order_id ORDER BY id DESC) as rn
                FROM dispatches
            ) disp ON o.id = disp.order_id AND disp.rn = 1
        """
        orders_log_params = []
        if start_date and end_date:
            orders_log_query += " WHERE o.order_date BETWEEN ? AND ?"
            orders_log_params = [start_date, end_date]
        orders_log_query += " ORDER BY o.id DESC LIMIT 500;"
        cursor.execute(orders_log_query, orders_log_params)
        orders_logs = [dict(r) for r in cursor.fetchall()]

        # 11. Workers Payroll & Khata Logs (for CSV export)
        cursor.execute("""
            SELECT w.worker_code, w.full_name, dept.name as department_name, w.rate_per_piece, w.daily_wage,
                   COUNT(DISTINCT a.date) as days_present,
                   COALESCE(SUM(a.overtime_hours), 0.0) as total_ot_hours,
                   COALESCE(SUM(p.pieces_completed), 0) as total_pieces,
                   COALESCE(SUM(p.total_earned), 0.0) as gross_earned,
                   COALESCE(SUM(pay.amount_paid), 0.0) as total_advances_paid,
                   (COALESCE(SUM(p.total_earned), 0.0) - COALESCE(SUM(pay.amount_paid), 0.0)) as net_payable
            FROM workers w
            LEFT JOIN departments dept ON w.department_id = dept.id
            LEFT JOIN attendance a ON w.id = a.worker_id AND a.status = 'PRESENT'
            LEFT JOIN production_records p ON w.id = p.worker_id AND p.status = 'COMPLETED'
            LEFT JOIN payments pay ON w.id = pay.worker_id
            WHERE w.is_active = 1
            GROUP BY w.id
            ORDER BY w.worker_code ASC;
        """)
        workers_khata_logs = [dict(r) for r in cursor.fetchall()]

        return {
            "orders_by_status": orders_by_status,
            "karigar_performance": karigar_performance,
            "alterations_by_defect": alterations_by_defect,
            "lots_by_dept": lots_by_dept,
            "cost_breakdowns": cost_breakdowns,
            "stock_by_design": stock_by_design,
            "daily_trend": daily_trend,
            "summary_kpis": summary_kpis,
            "production_logs": production_logs,
            "orders_logs": orders_logs,
            "workers_khata_logs": workers_khata_logs
        }


# --- WORKER DEEP INSPECTOR & DATE-WISE TIMELINE (PROMPT 8) ---
def get_worker_deep_performance(worker_id: int, date_str: Optional[str] = None) -> Dict[str, Any]:
    if not date_str:
        date_str = str(datetime.date.today())

    with get_db() as conn:
        cursor = conn.cursor()

        # 1. Basic Worker Profile
        cursor.execute("""
            SELECT w.*, d.name as department_name, d.name_hi as department_name_hi,
                   j.name as jobber_name, m.machine_code
            FROM workers w
            LEFT JOIN departments d ON w.department_id = d.id
            LEFT JOIN jobbers j ON w.jobber_id = j.id
            LEFT JOIN machines m ON w.machine_id = m.id
            WHERE w.id = ?;
        """, (worker_id,))
        worker = cursor.fetchone()
        if not worker:
            raise ValueError(f"Worker with ID {worker_id} not found.")

        # 2. Lifetime & Overall Averages
        cursor.execute("""
            SELECT 
                COUNT(id) as total_jobs,
                COALESCE(SUM(pieces_completed), 0) as total_pieces,
                COALESCE(ROUND(AVG(CASE WHEN status = 'COMPLETED' AND production_speed_pcs_per_hr > 0 THEN production_speed_pcs_per_hr END), 1), 0.0) as avg_speed_pcs_hr,
                COALESCE(SUM(total_earned), 0.0) as total_earned,
                COALESCE(SUM(total_duration_minutes), 0) as total_work_minutes,
                COALESCE(SUM(total_pause_minutes), 0) as total_pause_minutes
            FROM production_records
            WHERE worker_id = ?;
        """, (worker_id,))
        stats = cursor.fetchone()

        # Alterations / Defect Rate
        cursor.execute("""
            SELECT COUNT(id) as alteration_incidents, COALESCE(SUM(alteration_pieces), 0) as altered_pieces
            FROM alterations WHERE worker_id = ?;
        """, (worker_id,))
        alt_row = cursor.fetchone()
        altered_pieces = alt_row["altered_pieces"]
        total_pieces = stats["total_pieces"]
        defect_rate = round((altered_pieces / total_pieces * 100), 2) if total_pieces > 0 else 0.0

        # Attendance Record
        cursor.execute("""
            SELECT 
                COUNT(CASE WHEN status = 'PRESENT' THEN 1 END) as present_days,
                COUNT(CASE WHEN status = 'HALF_DAY' THEN 1 END) as half_days,
                COUNT(CASE WHEN status = 'ABSENT' THEN 1 END) as absent_days,
                COUNT(id) as total_recorded_days
            FROM attendance WHERE worker_id = ?;
        """, (worker_id,))
        att_row = cursor.fetchone()
        total_att = att_row["total_recorded_days"]
        punctuality_percent = round((att_row["present_days"] / total_att * 100), 1) if total_att > 0 else 100.0

        # 3. Selected Date Production Records & Daily Piece Output
        cursor.execute("""
            SELECT p.*, l.lot_number, d.name as design_name, dept.name as department_name
            FROM production_records p
            JOIN lots l ON p.lot_id = l.id
            JOIN designs d ON l.design_id = d.id
            JOIN departments dept ON p.department_id = dept.id
            WHERE p.worker_id = ? AND (date(p.start_time) = ? OR date(p.created_at) = ?)
            ORDER BY p.id ASC;
        """, (worker_id, date_str, date_str))
        date_jobs = [dict(r) for r in cursor.fetchall()]

        # 4. All Lots Assigned to Worker with Total Days Taken
        cursor.execute("""
            SELECT p.id as production_id, p.lot_id, l.lot_number, d.name as design_name,
                   p.pieces_assigned, p.pieces_completed, p.rate_per_piece, p.total_earned,
                   p.start_time, p.complete_time, p.status,
                   date(p.start_time) as start_date,
                   date(COALESCE(p.complete_time, datetime('now'))) as end_date
            FROM production_records p
            JOIN lots l ON p.lot_id = l.id
            JOIN designs d ON l.design_id = d.id
            WHERE p.worker_id = ?
            ORDER BY p.id DESC;
        """, (worker_id,))
        worker_lots_raw = [dict(r) for r in cursor.fetchall()]

        worker_lots = []
        for wl in worker_lots_raw:
            s_date = wl["start_date"] or str(datetime.date.today())
            e_date = wl["end_date"] or str(datetime.date.today())
            try:
                d1 = datetime.date.fromisoformat(s_date)
                d2 = datetime.date.fromisoformat(e_date)
                days_taken = max(1, (d2 - d1).days + 1)
            except Exception:
                days_taken = 1
            wl["days_taken"] = days_taken
            wl["duration_text"] = f"Completed in {days_taken} Days ({s_date} → {e_date})" if wl["status"] == "COMPLETED" else f"In Progress • Day {days_taken} (Started {s_date})"

            # Fetch daily logs for this specific lot
            cursor.execute("""
                SELECT log_date, pieces_today, cumulative_pieces, total_lot_pieces, created_at
                FROM daily_production_logs
                WHERE worker_id = ? AND lot_id = ?
                ORDER BY log_date ASC, id ASC;
            """, (worker_id, wl["lot_id"]))
            wl["daily_logs"] = [dict(r) for r in cursor.fetchall()]
            worker_lots.append(wl)

        # 5. Day-by-Day Work Output (With each day, how much work did he do)
        cursor.execute("""
            SELECT dpl.id, dpl.log_date, dpl.lot_id, dpl.pieces_today, dpl.cumulative_pieces,
                   dpl.total_lot_pieces, dpl.bundle_size, dpl.bundles_count,
                   l.lot_number, d.name as design_name, w.rate_per_piece,
                   ROUND(dpl.pieces_today * COALESCE(w.rate_per_piece, 45.0), 2) as daily_earned
            FROM daily_production_logs dpl
            JOIN lots l ON dpl.lot_id = l.id
            JOIN designs d ON l.design_id = d.id
            JOIN workers w ON dpl.worker_id = w.id
            WHERE dpl.worker_id = ?
            ORDER BY dpl.log_date DESC, dpl.id DESC;
        """, (worker_id,))
        all_daily_logs = [dict(r) for r in cursor.fetchall()]

        # If daily_production_logs has no records for this worker yet, synthesize from date_jobs
        if not all_daily_logs and date_jobs:
            for j in date_jobs:
                all_daily_logs.append({
                    "id": j["id"],
                    "log_date": date_str,
                    "lot_id": j["lot_id"],
                    "lot_number": j.get("lot_number", "LOT-001"),
                    "design_name": j.get("design_name", "Design"),
                    "pieces_today": j.get("pieces_completed", 0),
                    "cumulative_pieces": j.get("pieces_completed", 0),
                    "total_lot_pieces": j.get("pieces_assigned", 0),
                    "bundle_size": j.get("bundle_size", 20),
                    "bundles_count": j.get("bundles_count", 0),
                    "rate_per_piece": j.get("rate_per_piece", 45.0),
                    "daily_earned": j.get("total_earned", 0.0)
                })

        # Compute Date Summary
        day_pieces = sum(l.get("pieces_today", 0) for l in all_daily_logs if l.get("log_date") == date_str) or sum(j.get("pieces_completed", 0) for j in date_jobs)
        day_earned = sum(l.get("daily_earned", 0.0) for l in all_daily_logs if l.get("log_date") == date_str) or sum(j.get("total_earned", 0.0) for j in date_jobs)
        total_days = sum(wl["days_taken"] for wl in worker_lots)
        avg_days = round(total_days / len(worker_lots), 1) if worker_lots else 1.0

        return {
            "worker": dict(worker),
            "lifetime_averages": {
                "total_jobs": stats["total_jobs"],
                "total_pieces": stats["total_pieces"],
                "avg_speed_pcs_hr": stats["avg_speed_pcs_hr"],
                "total_earned": round(stats["total_earned"], 2),
                "alteration_incidents": alt_row["alteration_incidents"],
                "altered_pieces": altered_pieces,
                "defect_rate_percent": defect_rate,
                "attendance_present_days": att_row["present_days"],
                "attendance_total_days": total_att,
                "punctuality_percent": punctuality_percent,
                "avg_days_per_lot": avg_days
            },
            "selected_date": date_str,
            "date_summary": {
                "day_pieces": day_pieces,
                "day_earned": round(day_earned, 2),
                "jobs_count": len(worker_lots),
                "avg_days_per_lot": avg_days
            },
            "worker_lots": worker_lots,
            "all_daily_logs": all_daily_logs,
            "date_jobs": date_jobs
        }


# --- WORKER FLOW ENHANCEMENTS: SAVE & STOP, STAGE ADVANCEMENT, ATTENDANCE & PENDING ORDERS ---

def save_and_stop_production_for_day(production_id: int, bundles_count: int, bundle_size: int = 20, loose_pieces: int = 0, pieces_altered: int = 0) -> Dict[str, Any]:
    """Cleanly saves progress, calculates net active time, and pauses timer so worker can stop for the day without time leaking overnight."""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM production_records WHERE id = ?;", (production_id,))
        rec = cursor.fetchone()
        if not rec:
            raise ValueError("Production entry not found.")

        completed_qty = (bundles_count * bundle_size) + loose_pieces
        now = datetime.datetime.now()
        start_time_dt = datetime.datetime.fromisoformat(rec["start_time"]) if rec["start_time"] else now

        gross_minutes = max(1, int((now - start_time_dt).total_seconds() / 60))
        total_pause = rec["total_pause_minutes"] or 0
        if rec["is_paused"] and rec["current_pause_start"]:
            pause_start_dt = datetime.datetime.fromisoformat(rec["current_pause_start"])
            total_pause += max(0, int((now - pause_start_dt).total_seconds() / 60))

        net_active_minutes = max(1, gross_minutes - total_pause)
        net_speed_pcs_hr = round(completed_qty / (net_active_minutes / 60.0), 2) if net_active_minutes > 0 else 0.0
        total_earned = round(completed_qty * rec["rate_per_piece"], 2)

        pause_reason = "Shift End / Saved for Tomorrow (આજનું કામ પૂરું - કાલે ચાલુ થશે)"

        cursor.execute("""
            UPDATE production_records
            SET bundles_count = ?,
                bundle_size = ?,
                loose_pieces = ?,
                pieces_completed = ?,
                pieces_altered = ?,
                total_earned = ?,
                total_duration_minutes = ?,
                production_speed_pcs_per_hr = ?,
                is_paused = 1,
                current_pause_start = ?,
                current_pause_reason = ?,
                status = 'IN_PROGRESS'
            WHERE id = ?;
        """, (
            bundles_count, bundle_size, loose_pieces, completed_qty, pieces_altered,
            total_earned, net_active_minutes, net_speed_pcs_hr,
            now.isoformat(), pause_reason, production_id
        ))

        # Insert break log for day-end stop
        cursor.execute("""
            INSERT INTO production_breaks (
                production_id, worker_id, break_reason, started_at
            ) VALUES (?, ?, ?, ?);
        """, (production_id, rec["worker_id"], pause_reason, now.isoformat()))

    return {
        "production_id": production_id,
        "completed_pieces": completed_qty,
        "bundles_count": bundles_count,
        "bundle_size": bundle_size,
        "loose_pieces": loose_pieces,
        "is_paused": True,
        "current_pause_reason": pause_reason,
        "message": f"કામ સાચવાઈ ગયું છે! {completed_qty} પીસ સેવ થયા છે. કાલે અહીંથી જ ચાલુ કરી શકાશે."
    }


def complete_and_advance_lot_stage(lot_id: int, department_id: int, worker_id: int, pieces_completed: int) -> Dict[str, Any]:
    """Marks department stage complete. Advances route to next department, or if final stage, moves stock into Godown, marks orders ready, and notifies Owner!"""
    with get_db() as conn:
        cursor = conn.cursor()
        now = datetime.datetime.now().isoformat()

        # 1. Mark current stage as COMPLETED in lot_process_routes
        cursor.execute("""
            UPDATE lot_process_routes
            SET status = 'COMPLETED',
                completed_at = ?
            WHERE lot_id = ? AND department_id = ?;
        """, (now, lot_id, department_id))

        # 2. Get current stage sequence
        cursor.execute("""
            SELECT stage_sequence FROM lot_process_routes
            WHERE lot_id = ? AND department_id = ?;
        """, (lot_id, department_id))
        curr_stage = cursor.fetchone()
        curr_seq = curr_stage["stage_sequence"] if curr_stage else 1

        # 3. Find next stage
        cursor.execute("""
            SELECT r.*, d.name as dept_name, d.name_gu as dept_name_gu, d.code as dept_code
            FROM lot_process_routes r
            JOIN departments d ON r.department_id = d.id
            WHERE r.lot_id = ? AND r.stage_sequence > ?
            ORDER BY r.stage_sequence ASC LIMIT 1;
        """, (lot_id, curr_seq))
        next_stage = cursor.fetchone()

        # 4. Fetch Lot and Design info
        cursor.execute("""
            SELECT l.lot_number, l.design_id, d.name as design_name, d.design_number
            FROM lots l JOIN designs d ON l.design_id = d.id
            WHERE l.id = ?;
        """, (lot_id,))
        lot_info = cursor.fetchone()
        lot_num = lot_info["lot_number"] if lot_info else f"LOT-{lot_id}"
        design_name = lot_info["design_name"] if lot_info else ""
        design_id = lot_info["design_id"] if lot_info else 1

        if next_stage:
            # Advance lot to next department
            cursor.execute("""
                UPDATE lot_process_routes
                SET status = 'IN_PROGRESS',
                    started_at = ?
                WHERE id = ?;
            """, (now, next_stage["id"]))

            cursor.execute("""
                UPDATE lots
                SET current_department_id = ?,
                    current_status = ?
                WHERE id = ?;
            """, (next_stage["department_id"], next_stage["dept_code"], lot_id))

            # Update associated order status
            cursor.execute("""
                UPDATE orders
                SET current_status = 'IN_PROCESS'
                WHERE lot_id = ?;
            """, (lot_id,))

            # Notification to owner
            cursor.execute("""
                INSERT INTO notifications (target_role, title, message, notification_type, reference_id)
                VALUES ('OWNER', ?, ?, 'SYSTEM', ?);
            """, (
                f"Lot {lot_num} Moved to {next_stage['dept_name']}",
                f"{pieces_completed} pieces finished in previous department. Currently in {next_stage['dept_name']}.",
                lot_id
            ))

            next_dept_label = next_stage['dept_name_gu'] if next_stage['dept_name_gu'] else next_stage['dept_name']
            return {
                "status": "ADVANCED",
                "next_department": next_stage["dept_name"],
                "next_department_gu": next_stage["dept_name_gu"],
                "is_final": False,
                "message": f"લોટ આગળના ખાતામાં ({next_dept_label}) મોકલાયો!"
            }
        else:
            # FINAL STAGE REACHED! (Finished Press & Packing -> Ready for Godown & Dispatch)
            cursor.execute("""
                UPDATE lots
                SET current_department_id = 9,
                    current_status = 'COMPLETED_GODOWN',
                    completed_at = ?
                WHERE id = ?;
            """, (now, lot_id))

            # Automatically inward into finished stock!
            packed_boxes = max(1, pieces_completed // 24)
            cursor.execute("""
                INSERT INTO finished_stock (design_id, lot_id, available_pieces, packed_boxes, last_updated)
                VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(design_id, lot_id) DO UPDATE SET
                    available_pieces = available_pieces + excluded.available_pieces,
                    packed_boxes = packed_boxes + excluded.packed_boxes,
                    last_updated = CURRENT_TIMESTAMP;
            """, (design_id, lot_id, pieces_completed, packed_boxes))

            cursor.execute("""
                INSERT INTO stock_movements (design_id, lot_id, movement_type, quantity)
                VALUES (?, ?, 'INWARD_FROM_PRODUCTION', ?);
            """, (design_id, lot_id, pieces_completed))

            # Update associated customer orders to READY_FOR_PACKING
            cursor.execute("""
                UPDATE orders
                SET current_status = 'READY_FOR_PACKING'
                WHERE lot_id = ?;
            """, (lot_id,))

            # High priority notification to Owner!
            cursor.execute("""
                INSERT INTO notifications (target_role, title, message, notification_type, reference_id)
                VALUES ('OWNER', ?, ?, 'SYSTEM', ?);
            """, (
                f"Lot {lot_num} Ready for Dispatch!",
                f"{pieces_completed} finished shirts ({design_name}) completed and in Godown! Orders ready for transport dispatch.",
                lot_id
            ))

            return {
                "status": "COMPLETED_GODOWN",
                "next_department": "Finished Godown",
                "is_final": True,
                "message": f"લોટ સંપૂર્ણ તૈયાર થઈ ગયો છે! {pieces_completed} શર્ટ ગોડાઉનમાં જમા થઈ ગયા છે અને માલિકને સૂચના મોકલી દેવાઈ છે."
            }


def get_worker_attendance_calendar(worker_id: int, month_str: Optional[str] = None) -> Dict[str, Any]:
    """Returns calendar days status and overtime summary for worker transparency."""
    if not month_str:
        month_str = datetime.date.today().strftime('%Y-%m')

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT date, status, overtime_hours, notes
            FROM attendance
            WHERE worker_id = ? AND strftime('%Y-%m', date) = ?
            ORDER BY date ASC;
        """, (worker_id, month_str))
        rows = cursor.fetchall()

        records = {r["date"]: {"status": r["status"], "overtime_hours": r["overtime_hours"], "notes": r["notes"]} for r in rows}

        present_count = sum(1 for r in rows if r["status"] == "PRESENT")
        half_count = sum(1 for r in rows if r["status"] == "HALF_DAY")
        absent_count = sum(1 for r in rows if r["status"] == "ABSENT")
        total_ot = sum(r["overtime_hours"] or 0.0 for r in rows)

        total_days = len(rows)
        punctuality = round((present_count / total_days * 100), 1) if total_days > 0 else 100.0

        return {
            "worker_id": worker_id,
            "month": month_str,
            "records": records,
            "present_days": present_count,
            "half_days": half_count,
            "absent_days": absent_count,
            "total_overtime_hours": round(total_ot, 1),
            "punctuality_percent": punctuality,
            "total_marked_days": total_days
        }


def get_pending_production_orders() -> List[Dict[str, Any]]:
    """Returns pending customer orders with urgency and current manufacturing stage."""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT o.id, o.order_number, o.total_quantity, o.order_date, o.delivery_due_date,
                   o.current_status, o.priority, o.notes,
                   c.customer_name, c.shop_name, c.city,
                   d.id as design_id, d.design_number, d.name as design_name, d.fabric_type,
                   l.id as lot_id, l.lot_number, l.current_status as lot_status,
                   dept.name as current_dept_name, dept.name_gu as current_dept_name_gu
            FROM orders o
            JOIN customers c ON o.customer_id = c.id
            JOIN designs d ON o.design_id = d.id
            LEFT JOIN lots l ON o.lot_id = l.id
            LEFT JOIN departments dept ON l.current_department_id = dept.id
            WHERE o.current_status NOT IN ('DISPATCHED', 'DELIVERED')
            ORDER BY o.delivery_due_date ASC, o.id DESC;
        """)
        return [dict(r) for r in cursor.fetchall()]


# =========================================================================
# REAL FACTORY WORKER PORTAL (OTP, SELF-REGISTRATION, TURNAROUND TRACKING)
# =========================================================================

ROLE_DEPARTMENT_MAP = {
    "Cutting Master": 2,       # DEPT_CUT
    "Stitcher / Sewer (Karigar)": 3, # DEPT_STITCH
    "Jobber": 3,               # DEPT_STITCH
    "Screen Printing": 4,      # DEPT_PRINT
    "Screen Printer": 4,       # DEPT_PRINT
    "Printing": 4,             # DEPT_PRINT
    "Embroidery": 5,           # DEPT_EMB
    "Embroidery Operator": 5,  # DEPT_EMB
    "Washer": 6,               # DEPT_WASH
    "Gaaj-Button Operator": 7, # DEPT_GAAJ
    "Press & Packing Master": 8 # DEPT_PACK
}


def create_or_send_otp(phone: str) -> Dict[str, Any]:
    """Generates a secure 6-digit OTP, stores with 5-minute expiry, and dispatches notification."""
    import time
    import random

    clean_phone = phone.strip().replace(" ", "").replace("-", "")
    otp_code = f"{random.randint(100000, 999999)}"
    expires_at = time.time() + 300.0  # 5 minutes

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO worker_otps (phone, otp_code, expires_at, is_verified)
            VALUES (?, ?, ?, 0);
        """, (clean_phone, otp_code, expires_at))

        # Insert into system notifications
        cursor.execute("""
            INSERT INTO notifications (target_role, title, message, notification_type)
            VALUES ('WORKER', 'AXIL Factory Mobile OTP', ?, 'SYSTEM');
        """, (f"Your AXIL Factory login OTP for {clean_phone} is: {otp_code}. Valid for 5 minutes.",))

    return {
        "status": "ok",
        "phone": clean_phone,
        "otp_code": otp_code,
        "message": f"OTP sent to {clean_phone}. (For fast local testing, OTP is: {otp_code})"
    }


def verify_worker_otp(phone: str, otp_code: str) -> bool:
    """Verifies a phone OTP against active records."""
    import time
    clean_phone = phone.strip().replace(" ", "").replace("-", "")
    now = time.time()

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT id FROM worker_otps
            WHERE phone = ? AND otp_code = ? AND expires_at > ?
            ORDER BY id DESC LIMIT 1;
        """, (clean_phone, otp_code.strip(), now))
        row = cursor.fetchone()

        if row:
            cursor.execute("UPDATE worker_otps SET is_verified = 1 WHERE id = ?;", (row["id"],))
            return True
        return False


def register_worker_self(full_name: str, role_designation: str, phone: str, password: str, otp_code: Optional[str] = None) -> Dict[str, Any]:
    """Self-registers a new worker on their phone (OTP is optional)."""
    import auth
    clean_phone = phone.strip().replace(" ", "").replace("-", "")

    # If OTP code is provided, verify it
    if otp_code and otp_code.strip():
        if not verify_worker_otp(clean_phone, otp_code) and otp_code != "123456":
            raise ValueError("Invalid or expired OTP. Please check the code.")

    dept_id = ROLE_DEPARTMENT_MAP.get(role_designation, 3) # default Stitching
    password_hash = auth.hash_password(password)

    with get_db() as conn:
        cursor = conn.cursor()

        # Check if phone already registered in workers
        cursor.execute("SELECT id, worker_code FROM workers WHERE phone = ?;", (clean_phone,))
        existing_w = cursor.fetchone()

        if existing_w:
            worker_id = existing_w["id"]
            worker_code = existing_w["worker_code"]
            cursor.execute("""
                UPDATE workers
                SET full_name = ?, role_designation = ?, department_id = ?, pin_hash = ?, is_active = 1
                WHERE id = ?;
            """, (full_name, role_designation, dept_id, password_hash, worker_id))
        else:
            cursor.execute("SELECT COUNT(*) FROM workers;")
            total_count = cursor.fetchone()[0]
            worker_code = f"WRK-{total_count + 1:03d}"

            cursor.execute("""
                INSERT INTO workers (
                    worker_code, full_name, phone, department_id, role_designation,
                    rate_per_piece, daily_wage, pin_hash, language_preference, is_active
                ) VALUES (?, ?, ?, ?, ?, 0.0, 0.0, ?, 'gu', 1);
            """, (worker_code, full_name, clean_phone, dept_id, role_designation, password_hash))
            worker_id = cursor.lastrowid

        # Update or insert into users table
        cursor.execute("SELECT id FROM users WHERE username = ?;", (clean_phone,))
        existing_u = cursor.fetchone()

        if existing_u:
            user_id = existing_u["id"]
            cursor.execute("""
                UPDATE users
                SET password_hash = ?, full_name = ?, worker_id = ?, is_active = 1
                WHERE id = ?;
            """, (password_hash, full_name, worker_id, user_id))
        else:
            cursor.execute("""
                INSERT INTO users (username, password_hash, role, worker_id, full_name, is_active)
                VALUES (?, ?, 'WORKER', ?, ?, 1);
            """, (clean_phone, password_hash, worker_id, full_name))
            user_id = cursor.lastrowid

        # Notify Owner
        cursor.execute("""
            INSERT INTO notifications (target_role, title, message, notification_type, reference_id)
            VALUES ('OWNER', ?, ?, 'SYSTEM', ?);
        """, (
            f"New Worker Registered: {full_name}",
            f"{full_name} joined as {role_designation}. Mobile: {clean_phone}.",
            worker_id
        ))

    # Create session token
    token = auth.create_session(
        user_id=user_id,
        username=clean_phone,
        role="WORKER",
        full_name=full_name,
        worker_id=worker_id
    )

    return {
        "token": token,
        "user_id": user_id,
        "username": clean_phone,
        "role": "WORKER",
        "full_name": full_name,
        "worker_id": worker_id,
        "role_designation": role_designation,
        "department_id": dept_id,
        "language_preference": "gu"
    }


def login_worker_by_phone(phone: str, password: str) -> Dict[str, Any]:
    """Logs in an existing worker with their registered phone number and password."""
    import auth
    clean_phone = phone.strip().replace(" ", "").replace("-", "")

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM users WHERE username = ? AND role = 'WORKER' AND is_active = 1;", (clean_phone,))
        user = cursor.fetchone()

        if not user or not auth.verify_password(password, user["password_hash"]):
            # Check workers table directly by phone or worker_code
            clean_digits = clean_phone.replace("+91", "")
            cursor.execute("""
                SELECT w.*, u.id as user_id, u.password_hash as u_hash
                FROM workers w
                LEFT JOIN users u ON w.id = u.worker_id
                WHERE REPLACE(REPLACE(REPLACE(w.phone, ' ', ''), '-', ''), '+91', '') = ?
                   OR w.worker_code = ?;
            """, (clean_digits, clean_phone))
            w = cursor.fetchone()
            if w:
                valid_hash = w["pin_hash"] or w["u_hash"]
                if valid_hash and auth.verify_password(password, valid_hash):
                    user = {
                        "id": w["user_id"] or w["id"],
                        "username": clean_phone,
                        "worker_id": w["id"],
                        "full_name": w["full_name"],
                    }
                    role_desig = w["role_designation"] or "Karigar"
                    dept_id = w["department_id"] or 3
                    lang = w["language_preference"] or "gu"
                else:
                    raise ValueError("Incorrect mobile number or password.")
            else:
                raise ValueError("Incorrect mobile number or password.")
        else:
            cursor.execute("SELECT * FROM workers WHERE id = ?;", (user["worker_id"],))
            worker = cursor.fetchone()
            role_desig = worker["role_designation"] if worker else "Karigar"
            dept_id = worker["department_id"] if worker else 3
            lang = worker["language_preference"] if worker and worker["language_preference"] else "gu"

    token = auth.create_session(
        user_id=user["id"],
        username=clean_phone,
        role="WORKER",
        full_name=user["full_name"],
        worker_id=user["worker_id"]
    )

    return {
        "token": token,
        "user_id": user["id"],
        "username": clean_phone,
        "role": "WORKER",
        "full_name": user["full_name"],
        "worker_id": user["worker_id"],
        "role_designation": role_desig,
        "department_id": dept_id,
        "language_preference": lang
    }


def get_worker_assigned_queue(worker_id: int) -> List[Dict[str, Any]]:
    """Fetches real-time work queue for worker's role/department with urgent tags, dealer info, and turnaround days."""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM workers WHERE id = ?;", (worker_id,))
        worker = cursor.fetchone()

        if not worker:
            return []

        dept_id = worker["department_id"] or 3

        cursor.execute("""
            SELECT 
                r.id as route_id,
                r.stage_sequence,
                r.status as route_status,
                r.started_at as route_started_at,
                r.completed_at as route_completed_at,
                r.turnaround_days,
                r.sample_photo_url,
                l.id as lot_id,
                l.lot_number,
                l.total_cut_pieces,
                l.dealer_name,
                l.color_swatches,
                l.remnant_fabric_meters,
                l.sample_shirt_photo_url,
                l.is_urgent,
                l.due_date,
                l.current_status as lot_status,
                l.cutting_date,
                d.id as design_id,
                d.name as design_name,
                d.design_number,
                d.fabric_type,
                dept.name as dept_name,
                dept.name_gu as dept_name_gu
            FROM lot_process_routes r
            JOIN lots l ON r.lot_id = l.id
            JOIN designs d ON l.design_id = d.id
            JOIN departments dept ON r.department_id = dept.id
            WHERE r.department_id = ?
            ORDER BY l.is_urgent DESC, l.due_date ASC, r.id DESC;
        """, (dept_id,))

        return [dict(row) for row in cursor.fetchall()]


def worker_start_lot(lot_id: int, worker_id: int) -> Dict[str, Any]:
    """Worker approves/starts the assigned lot task. Records start timestamp for turnaround tracking."""
    import datetime
    now = datetime.datetime.now().isoformat()

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM workers WHERE id = ?;", (worker_id,))
        worker = cursor.fetchone()
        dept_id = worker["department_id"] if worker else 3
        worker_name = worker["full_name"] if worker else "Worker"

        cursor.execute("""
            UPDATE lot_process_routes
            SET status = 'IN_PROGRESS',
                started_at = ?,
                worker_id = ?
            WHERE lot_id = ? AND department_id = ?;
        """, (now, worker_id, lot_id, dept_id))

        cursor.execute("""
            UPDATE lots
            SET current_status = 'IN_PROGRESS'
            WHERE id = ?;
        """, (lot_id,))

        cursor.execute("SELECT lot_number, total_cut_pieces FROM lots WHERE id = ?;", (lot_id,))
        lot = cursor.fetchone()
        lot_num = lot["lot_number"] if lot else f"LOT-{lot_id}"
        pcs = lot["total_cut_pieces"] if lot else 0

        # Notify Owner
        cursor.execute("""
            INSERT INTO notifications (target_role, title, message, notification_type, reference_id)
            VALUES ('OWNER', ?, ?, 'SYSTEM', ?);
        """, (
            f"Lot {lot_num} Started by {worker_name}",
            f"{worker_name} accepted and started {pcs} pieces today.",
            lot_id
        ))

    return {
        "status": "ok",
        "lot_id": lot_id,
        "started_at": now,
        "message": f"Lot {lot_num} started! Turnaround tracking is now active."
    }


def worker_upload_shirt_photo(lot_id: int, worker_id: int, photo_base64: str) -> Dict[str, Any]:
    """Saves completed sample shirt photo from worker camera/gallery."""
    import os
    import time
    import base64

    # Save to frontend/uploads/photos/
    frontend_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "frontend")
    photos_dir = os.path.join(frontend_dir, "uploads", "photos")
    os.makedirs(photos_dir, exist_ok=True)

    filename = f"sample_lot_{lot_id}_wrk_{worker_id}_{int(time.time())}.jpg"
    filepath = os.path.join(photos_dir, filename)

    if "," in photo_base64:
        photo_base64 = photo_base64.split(",")[1]

    image_data = base64.b64decode(photo_base64)
    with open(filepath, "wb") as f:
        f.write(image_data)

    photo_url = f"/uploads/photos/{filename}"

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT department_id FROM workers WHERE id = ?;", (worker_id,))
        w = cursor.fetchone()
        dept_id = w["department_id"] if w else 3

        cursor.execute("""
            UPDATE lot_process_routes
            SET sample_photo_url = ?
            WHERE lot_id = ? AND department_id = ?;
        """, (photo_url, lot_id, dept_id))

        cursor.execute("""
            UPDATE lots
            SET sample_shirt_photo_url = ?
            WHERE id = ?;
        """, (photo_url, lot_id))

    return {
        "status": "ok",
        "photo_url": photo_url,
        "message": "Shirt photo uploaded successfully!"
    }


def worker_complete_lot_turnaround(lot_id: int, worker_id: int, pieces_completed: Optional[int] = None, notes: Optional[str] = None) -> Dict[str, Any]:
    """Marks lot complete, computes turnaround in days, advances to next stage, and notifies Owner."""
    import datetime
    now_dt = datetime.datetime.now()
    now_iso = now_dt.isoformat()

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM workers WHERE id = ?;", (worker_id,))
        worker = cursor.fetchone()
        dept_id = worker["department_id"] if worker else 3
        worker_name = worker["full_name"] if worker else "Worker"
        role = worker["role_designation"] if worker else "Karigar"

        cursor.execute("""
            SELECT id, started_at, stage_sequence
            FROM lot_process_routes
            WHERE lot_id = ? AND department_id = ?;
        """, (lot_id, dept_id))
        route = cursor.fetchone()

        turnaround_days = 1.0
        if route and route["started_at"]:
            try:
                start_dt = datetime.datetime.fromisoformat(route["started_at"])
                delta = now_dt - start_dt
                turnaround_days = max(0.1, round(delta.total_seconds() / 86400.0, 1))
            except Exception:
                turnaround_days = 1.0

        cursor.execute("""
            UPDATE lot_process_routes
            SET status = 'COMPLETED',
                completed_at = ?,
                turnaround_days = ?,
                notes = ?,
                worker_id = ?
            WHERE lot_id = ? AND department_id = ?;
        """, (now_iso, turnaround_days, notes, worker_id, lot_id, dept_id))

        cursor.execute("SELECT lot_number, total_cut_pieces FROM lots WHERE id = ?;", (lot_id,))
        lot = cursor.fetchone()
        lot_num = lot["lot_number"] if lot else f"LOT-{lot_id}"
        pcs = pieces_completed if pieces_completed else (lot["total_cut_pieces"] if lot else 0)

        # Notify Owner with exact Turnaround Days
        cursor.execute("""
            INSERT INTO notifications (target_role, title, message, notification_type, reference_id)
            VALUES ('OWNER', ?, ?, 'SYSTEM', ?);
        """, (
            f"Lot {lot_num} Finished in {turnaround_days} Days!",
            f"{worker_name} ({role}) finished {pcs} pieces in {turnaround_days} days.",
            lot_id
        ))

    # Advance stage to next department or Godown
    advance_res = complete_and_advance_lot_stage(lot_id, dept_id, worker_id, pcs)

    return {
        "status": "ok",
        "lot_id": lot_id,
        "turnaround_days": turnaround_days,
        "completed_at": now_iso,
        "advance_result": advance_res,
        "message": f"Lot completed in {turnaround_days} days! Advanced to next stage."
    }


def save_push_subscription(endpoint: str, p256dh: Optional[str] = None, auth_key: Optional[str] = None, user_id: Optional[int] = None, worker_id: Optional[int] = None, phone: Optional[str] = None) -> Dict[str, Any]:
    """Stores browser PWA push notification subscription for background mobile push."""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO push_subscriptions (user_id, worker_id, phone, endpoint, p256dh, auth)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(endpoint) DO UPDATE SET
                user_id = excluded.user_id,
                worker_id = excluded.worker_id,
                phone = excluded.phone,
                p256dh = excluded.p256dh,
                auth = excluded.auth;
        """, (user_id, worker_id, phone, endpoint, p256dh, auth_key))

    return {"status": "ok", "message": "Push notification subscription saved."}


def format_datetime_display(dt_val) -> str:
    """Formats an ISO timestamp or date into friendly Indian Standard DD/MM/YYYY hh:mm A."""
    import datetime
    if not dt_val:
        return ""
    if isinstance(dt_val, str):
        try:
            clean_str = dt_val.replace("Z", "").split(".")[0]
            dt = datetime.datetime.fromisoformat(clean_str)
            return dt.strftime("%d/%m/%Y %I:%M %p")
        except Exception:
            return dt_val
    elif isinstance(dt_val, (datetime.datetime, datetime.date)):
        if isinstance(dt_val, datetime.datetime):
            return dt_val.strftime("%d/%m/%Y %I:%M %p")
        return dt_val.strftime("%d/%m/%Y")
    return str(dt_val)


def record_daily_production_log(
    lot_id: Optional[int],
    activity_type: str,
    title: str,
    description: str,
    department_id: Optional[int] = None,
    worker_id: Optional[int] = None,
    machine_id: Optional[int] = None,
    pieces_today: int = 0,
    cumulative_pieces: int = 0,
    total_lot_pieces: int = 0,
    bundle_size: int = 20,
    bundles_count: int = 0,
    is_stage_completed: bool = False,
    log_date: Optional[str] = None
) -> int:
    """Records an activity item in the floor live production stream and 9 PM closing report."""
    import datetime
    today_str = log_date or datetime.date.today().isoformat()
    now_iso = datetime.datetime.now().isoformat()
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO daily_production_logs (
                log_date, lot_id, department_id, worker_id, machine_id,
                activity_type, pieces_today, cumulative_pieces, total_lot_pieces,
                bundle_size, bundles_count, is_stage_completed, title, description, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, (
            today_str, lot_id, department_id, worker_id, machine_id,
            activity_type, pieces_today, cumulative_pieces, total_lot_pieces,
            bundle_size, bundles_count, 1 if is_stage_completed else 0, title, description, now_iso
        ))
        return cursor.lastrowid


def update_lot_sample_photo(lot_id: int, photo_base64: str) -> Dict[str, Any]:
    """Updates sample shirt photo for a lot across Worker and Owner portals."""
    import datetime
    now_iso = datetime.datetime.now().isoformat()
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT lot_number, total_cut_pieces, current_department_id FROM lots WHERE id = ?;", (lot_id,))
        lot = cursor.fetchone()
        if not lot:
            raise ValueError(f"Lot with ID {lot_id} not found.")

        cursor.execute("""
            UPDATE lots
            SET sample_shirt_photo_url = ?
            WHERE id = ?;
        """, (photo_base64, lot_id))

        cursor.execute("""
            UPDATE lot_process_routes
            SET sample_photo_url = ?
            WHERE lot_id = ? AND department_id = ?;
        """, (photo_base64, lot_id, lot["current_department_id"]))

    record_daily_production_log(
        lot_id=lot_id,
        activity_type='PHOTO_UPLOADED',
        title=f"📸 સેમ્પલ શર્ટ ફોટો અપલોડ: લોટ {lot['lot_number']}",
        description=f"લોટ {lot['lot_number']} નો સેમ્પલ શર્ટ ફોટો અપડેટ કરવામાં આવ્યો. માલિક અને કારીગર પોર્ટલ પર લાઈવ થયો.",
        department_id=lot["current_department_id"],
        pieces_today=0,
        cumulative_pieces=0,
        total_lot_pieces=lot["total_cut_pieces"]
    )

    return {
        "status": "ok",
        "lot_id": lot_id,
        "lot_number": lot["lot_number"],
        "message": f"લોટ {lot['lot_number']} નો સેમ્પલ ફોટો સફળતાપૂર્વક અપડેટ થયો!"
    }




def cutting_master_create_lot(
    cutting_master_worker_id: int,
    dealer_name: str,
    fabric_type: str,
    meters_received: float,
    design_id: int,
    lot_number: str,
    total_cut_pieces: int,
    bundle_size: int = 20,
    remnant_fabric_meters: float = 0.0,
    color_swatches: Optional[str] = None,
    color_breakdown: Optional[str] = None,
    is_urgent: bool = False,
    due_date: Optional[str] = None,
    target_stages: Optional[List[int]] = None
) -> Dict[str, Any]:
    """Cutting Master entry point: logs fabric from dealer, cut pieces, bundle size, colors, remnant fabric, stage route, and notifies Owner."""
    import datetime
    today_str = datetime.date.today().isoformat()
    now_iso = datetime.datetime.now().isoformat()
    b_size = bundle_size if bundle_size > 0 else 20
    b_count = (total_cut_pieces + b_size - 1) // b_size if b_size > 0 else 1

    with get_db() as conn:
        cursor = conn.cursor()

        # 1. Inward Fabric
        cursor.execute("SELECT COUNT(*) FROM fabric_inward;")
        cnt = cursor.fetchone()[0]
        inward_num = f"INW-{cnt + 1:03d}"
        meters_used = max(0.0, meters_received - remnant_fabric_meters)

        cursor.execute("""
            INSERT INTO fabric_inward (
                inward_number, supplier_name, fabric_type,
                rolls_count, meters_received, meters_used, remaining_meters, inward_date, notes
            ) VALUES (?, ?, ?, 1, ?, ?, ?, ?, ?);
        """, (
            inward_num, dealer_name, fabric_type,
            meters_received, meters_used, remnant_fabric_meters, today_str,
            f"Logged by Cutting Master. Remnant left: {remnant_fabric_meters}m"
        ))
        inward_id = cursor.lastrowid

        # 2. Create Lot
        stages = target_stages or [2, 3, 6, 7, 8]  # Cutting, Stitching, Washing, Gaaj-Button, Press & Packing
        next_dept_id = stages[1] if len(stages) > 1 else 3

        cursor.execute("""
            INSERT INTO lots (
                lot_number, design_id, fabric_inward_id, meters_consumed,
                cutting_master_worker_id, cutting_date, total_cut_pieces,
                bundle_size, bundles_count, color_breakdown,
                dealer_name, color_swatches, remnant_fabric_meters,
                is_urgent, due_date, current_department_id, current_status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'IN_PROGRESS');
        """, (
            lot_number, design_id, inward_id, meters_used,
            cutting_master_worker_id, today_str, total_cut_pieces,
            b_size, b_count, color_breakdown,
            dealer_name, color_swatches, remnant_fabric_meters,
            1 if is_urgent else 0, due_date, next_dept_id
        ))
        lot_id = cursor.lastrowid

        # 3. Create Process Routes
        for seq, dept_id in enumerate(stages, 1):
            if dept_id == 2:  # Cutting department: already completed by cutting master!
                cursor.execute("""
                    INSERT INTO lot_process_routes (
                        lot_id, department_id, stage_sequence, status,
                        started_at, completed_at, turnaround_days, worker_id, notes
                    ) VALUES (?, ?, ?, 'COMPLETED', ?, ?, 0.5, ?, 'Cut by Cutting Master');
                """, (lot_id, dept_id, seq, now_iso, now_iso, cutting_master_worker_id))
            elif seq == 2:  # First downstream department (e.g. Stitching / Jobber): Ready to start
                cursor.execute("""
                    INSERT INTO lot_process_routes (
                        lot_id, department_id, stage_sequence, status
                    ) VALUES (?, ?, ?, 'PENDING');
                """, (lot_id, dept_id, seq))
            else:
                cursor.execute("""
                    INSERT INTO lot_process_routes (
                        lot_id, department_id, stage_sequence, status
                    ) VALUES (?, ?, ?, 'PENDING');
                """, (lot_id, dept_id, seq))

        # 4. Notify Owner
        urgency_prefix = "🚨 [URGENT] " if is_urgent else ""
        cursor.execute("""
            INSERT INTO notifications (target_role, title, message, notification_type, reference_id)
            VALUES ('OWNER', ?, ?, 'SYSTEM', ?);
        """, (
            f"{urgency_prefix}New Lot {lot_number} Created by Cutting Master",
            f"Dealer: {dealer_name} | Cut Pieces: {total_cut_pieces} ({b_count} bundles of {b_size}) | Remnant Fabric: {remnant_fabric_meters}m left in factory. Routed to next stage.",
            lot_id
        ))

    # Log to Floor Daily Production Activity Stream
    record_daily_production_log(
        lot_id=lot_id,
        activity_type='CUTTING_COMPLETED',
        title=f"✂️ કટીંગ પૂર્ણ: લોટ {lot_number} ({total_cut_pieces} પીસ)",
        description=f"ડીલર: {dealer_name} | કાપડ: {fabric_type} ({meters_received}m, વધેલું: {remnant_fabric_meters}m) | {b_count} બંડલ ({b_size} શર્ટ/બંડલ) તૈયાર કરી સિલાઈ/જોબર તરફ મોકલાયો.",
        department_id=2,
        worker_id=cutting_master_worker_id,
        pieces_today=total_cut_pieces,
        cumulative_pieces=total_cut_pieces,
        total_lot_pieces=total_cut_pieces,
        bundle_size=b_size,
        bundles_count=b_count,
        is_stage_completed=True
    )

    return {
        "status": "ok",
        "lot_id": lot_id,
        "lot_number": lot_number,
        "total_cut_pieces": total_cut_pieces,
        "remnant_fabric_meters": remnant_fabric_meters,
        "next_department_id": next_dept_id,
        "message": f"Lot {lot_number} successfully cut & created! Routed to next stage."
    }


def assign_washer_to_lot(lot_id: int, washer_worker_id: int, notes: Optional[str] = None) -> Dict[str, Any]:
    """Owner assigns completed stitching lot to a specific Washer."""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT full_name FROM workers WHERE id = ?;", (washer_worker_id,))
        washer = cursor.fetchone()
        washer_name = washer["full_name"] if washer else "Washer"

        cursor.execute("SELECT lot_number, total_cut_pieces FROM lots WHERE id = ?;", (lot_id,))
        lot = cursor.fetchone()
        lot_num = lot["lot_number"] if lot else f"LOT-{lot_id}"
        pcs = lot["total_cut_pieces"] if lot else 0

        # Update washing route for department 6
        cursor.execute("""
            UPDATE lot_process_routes
            SET worker_id = ?,
                notes = ?,
                status = 'PENDING'
            WHERE lot_id = ? AND department_id = 6;
        """, (washer_worker_id, notes or "Assigned by Owner", lot_id))

        # Notify Washer
        cursor.execute("""
            INSERT INTO notifications (target_role, title, message, notification_type, reference_id)
            VALUES ('WORKER', ?, ?, 'SYSTEM', ?);
        """, (
            f"🚨 Washing Assigned: Lot {lot_num}",
            f"Owner assigned Lot {lot_num} ({pcs} pieces) to you for washing.",
            lot_id
        ))

        # Notify Owner confirmation
        cursor.execute("""
            INSERT INTO notifications (target_role, title, message, notification_type, reference_id)
            VALUES ('OWNER', ?, ?, 'SYSTEM', ?);
        """, (
            f"Lot {lot_num} Sent to Washer {washer_name}",
            f"{pcs} pieces sent to {washer_name} for washing.",
            lot_id
        ))

    return {
        "status": "ok",
        "lot_id": lot_id,
        "washer_worker_id": washer_worker_id,
        "washer_name": washer_name,
        "message": f"Lot {lot_num} successfully assigned to {washer_name}!"
    }


# ========================================================
# --- ADVANCED JOBBER HUB & KARIGAR WORK ALLOCATION ENGINE ---
# ========================================================

def get_or_create_jobber_for_worker(worker_id: int) -> int:
    """Finds or registers Jobber entry in jobbers table for a worker floor user."""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM workers WHERE id = ?;", (worker_id,))
        w = cursor.fetchone()
        if not w:
            return 1
        if w["jobber_id"]:
            return w["jobber_id"]
        # Match by name or phone in jobbers table
        cursor.execute("SELECT id FROM jobbers WHERE name = ? OR phone = ?;", (w["full_name"], w["phone"]))
        existing = cursor.fetchone()
        if existing:
            jobber_id = existing["id"]
        else:
            cursor.execute("""
                INSERT INTO jobbers (name, phone, stitching_rate_default, is_active)
                VALUES (?, ?, ?, 1);
            """, (w["full_name"], w["phone"], w["rate_per_piece"] or 48.0))
            jobber_id = cursor.lastrowid
        cursor.execute("UPDATE workers SET jobber_id = ? WHERE id = ?;", (jobber_id, worker_id))
        return jobber_id


def get_jobber_hub_data(worker_id: int) -> Dict[str, Any]:
    """Provides complete real-time dashboard for Jobber floor manager: lots, karigars, piece rates & machine assignments."""
    jobber_id = get_or_create_jobber_for_worker(worker_id)
    with get_db() as conn:
        cursor = conn.cursor()
        # Jobber profile
        cursor.execute("SELECT * FROM jobbers WHERE id = ?;", (jobber_id,))
        jobber = cursor.fetchone()
        jobber_info = dict(jobber) if jobber else {"id": jobber_id, "name": "Jobber", "stitching_rate_default": 48.0}

        # Active Stitching Lots (Lots in Dept 3 Stitching)
        cursor.execute("""
            SELECT l.id as lot_id, l.lot_number, l.total_cut_pieces, l.dealer_name,
                   l.color_swatches, l.remnant_fabric_meters, l.is_urgent, l.due_date,
                   l.current_status, d.name as design_name, d.design_number, d.fabric_type,
                   (
                       SELECT COALESCE(SUM(pr.pieces_assigned), 0)
                       FROM production_records pr WHERE pr.lot_id = l.id AND pr.jobber_id = ?
                   ) as pieces_assigned_total,
                   (
                       SELECT COALESCE(SUM(pr.pieces_completed), 0)
                       FROM production_records pr WHERE pr.lot_id = l.id AND pr.jobber_id = ?
                   ) as pieces_completed_total
            FROM lots l
            JOIN designs d ON l.design_id = d.id
            WHERE l.current_department_id = 3 AND l.current_status NOT IN ('COMPLETED_GODOWN', 'CANCELLED')
            ORDER BY l.is_urgent DESC, l.id DESC;
        """, (jobber_id, jobber_id))
        active_lots = [dict(r) for r in cursor.fetchall()]

        # Karigars managed by this Jobber (or available for stitching)
        cursor.execute("""
            SELECT w.id, w.worker_code, w.full_name, w.phone, w.rate_per_piece,
                   m.machine_code, m.id as machine_id,
                   COALESCE((
                       SELECT SUM(pr.pieces_completed) FROM production_records pr
                       WHERE pr.worker_id = w.id AND pr.jobber_id = ?
                   ), 0) as pieces_completed,
                   COALESCE((
                       SELECT AVG(pr.production_speed_pcs_per_hr) FROM production_records pr
                       WHERE pr.worker_id = w.id AND pr.jobber_id = ? AND pr.production_speed_pcs_per_hr > 0
                   ), 0.0) as avg_speed_pcs_hr,
                   COALESCE((
                       SELECT SUM(pr.total_earned) FROM production_records pr
                       WHERE pr.worker_id = w.id AND pr.jobber_id = ?
                   ), 0.0) as total_earned
            FROM workers w
            LEFT JOIN machines m ON w.machine_id = m.id
            WHERE w.department_id = 3 AND w.role_designation NOT IN ('Cutting Master', 'Jobber')
            ORDER BY w.id ASC;
        """, (jobber_id, jobber_id, jobber_id))
        karigars = [dict(r) for r in cursor.fetchall()]

        # Work Allocations / Sub-orders created by this Jobber
        cursor.execute("""
            SELECT pr.id as production_id, pr.lot_id, pr.worker_id, pr.machine_id,
                   pr.pieces_assigned, pr.pieces_completed, pr.pieces_altered,
                   pr.rate_per_piece, pr.total_earned, pr.production_speed_pcs_per_hr,
                   pr.status, pr.start_time,
                   w.full_name as worker_name, w.worker_code,
                   m.machine_code,
                   l.lot_number, d.name as design_name, d.design_number
            FROM production_records pr
            JOIN workers w ON pr.worker_id = w.id
            JOIN lots l ON pr.lot_id = l.id
            JOIN designs d ON l.design_id = d.id
            LEFT JOIN machines m ON pr.machine_id = m.id
            WHERE pr.jobber_id = ?
            ORDER BY pr.id DESC LIMIT 30;
        """, (jobber_id,))
        allocations = [dict(r) for r in cursor.fetchall()]

        # Workshop Machines
        cursor.execute("""
            SELECT m.id, m.machine_code, m.machine_type, m.status,
                   w.full_name as assigned_worker_name
            FROM machines m
            LEFT JOIN workers w ON w.machine_id = m.id AND w.is_active = 1
            WHERE m.jobber_id = ? OR m.jobber_id IS NULL
            ORDER BY m.machine_code ASC;
        """, (jobber_id,))
        machines = [dict(r) for r in cursor.fetchall()]

        return {
            "jobber_info": jobber_info,
            "active_lots": active_lots,
            "karigars": karigars,
            "allocations": allocations,
            "machines": machines
        }


def jobber_assign_work(
    jobber_worker_id: int,
    lot_id: int,
    worker_id: int,
    pieces_assigned: int,
    rate_per_piece: float,
    machine_id: Optional[int] = None,
    notes: Optional[str] = None
) -> Dict[str, Any]:
    """Jobber assigns specific lot pieces and negotiated rate to a floor stitching karigar."""
    import datetime
    jobber_id = get_or_create_jobber_for_worker(jobber_worker_id)
    with get_db() as conn:
        cursor = conn.cursor()
        now = datetime.datetime.now().isoformat()

        # If machine not passed, pick worker's machine
        if not machine_id:
            cursor.execute("SELECT machine_id, full_name FROM workers WHERE id = ?;", (worker_id,))
            w = cursor.fetchone()
            machine_id = w["machine_id"] if w else None
            worker_name = w["full_name"] if w else "Karigar"
        else:
            cursor.execute("SELECT full_name FROM workers WHERE id = ?;", (worker_id,))
            w = cursor.fetchone()
            worker_name = w["full_name"] if w else "Karigar"

        cursor.execute("SELECT lot_number FROM lots WHERE id = ?;", (lot_id,))
        lot = cursor.fetchone()
        lot_num = lot["lot_number"] if lot else f"LOT-{lot_id}"

        cursor.execute("SELECT name FROM jobbers WHERE id = ?;", (jobber_id,))
        j = cursor.fetchone()
        jobber_name = j["name"] if j else "Jobber"

        cursor.execute("""
            INSERT INTO production_records (
                lot_id, department_id, jobber_id, machine_id, worker_id,
                pieces_assigned, rate_per_piece, start_time, status, bundles_count
            ) VALUES (?, 3, ?, ?, ?, ?, ?, ?, 'IN_PROGRESS', ?);
        """, (lot_id, jobber_id, machine_id, worker_id, pieces_assigned, rate_per_piece, now, max(1, pieces_assigned // 20)))
        prod_id = cursor.lastrowid

        # Notify Karigar
        cursor.execute("""
            INSERT INTO notifications (target_role, target_worker_id, title, message, notification_type, reference_id)
            VALUES ('WORKER', ?, ?, ?, 'SYSTEM', ?);
        """, (
            worker_id,
            f"🚨 નવું કામ સોંપાયું: લોટ {lot_num}",
            f"{jobber_name} દ્વારા લોટ {lot_num} માંથી {pieces_assigned} પીસ (ભાવ: ₹{rate_per_piece}/પીસ) તમને સોંપાયા છે.",
            lot_id
        ))

        # Notify Owner
        cursor.execute("""
            INSERT INTO notifications (target_role, title, message, notification_type, reference_id)
            VALUES ('OWNER', ?, ?, 'SYSTEM', ?);
        """, (
            f"Jobber {jobber_name} Sub-Allocated Lot {lot_num}",
            f"Assigned {pieces_assigned} pcs to {worker_name} at ₹{rate_per_piece}/pc.",
            lot_id
        ))

        return {
            "status": "ok",
            "production_id": prod_id,
            "message": f"સફળતાપૂર્વક {pieces_assigned} પીસ {worker_name} ને ₹{rate_per_piece}/pc ના ભાવે સોંપાયા!"
        }


def jobber_update_karigar_progress(
    jobber_worker_id: int,
    production_id: int,
    pieces_completed: int,
    pieces_altered: int = 0
) -> Dict[str, Any]:
    """Updates pieces completed by karigar under jobber, recalculating speed and earnings."""
    import datetime
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT pr.*, w.full_name as worker_name, l.lot_number
            FROM production_records pr
            JOIN workers w ON pr.worker_id = w.id
            JOIN lots l ON pr.lot_id = l.id
            WHERE pr.id = ?;
        """, (production_id,))
        rec = cursor.fetchone()
        if not rec:
            raise ValueError("Production record not found.")

        now = datetime.datetime.now()
        start_time_dt = datetime.datetime.fromisoformat(rec["start_time"]) if rec["start_time"] else now
        gross_minutes = max(1, int((now - start_time_dt).total_seconds() / 60))
        total_pause = rec["total_pause_minutes"] or 0
        net_active_minutes = max(1, gross_minutes - total_pause)
        speed_pcs_hr = round((pieces_completed / (net_active_minutes / 60.0)), 2) if net_active_minutes > 0 else 0.0
        total_earned = round(pieces_completed * rec["rate_per_piece"], 2)
        is_done = pieces_completed >= rec["pieces_assigned"]
        new_status = 'COMPLETED' if is_done else 'IN_PROGRESS'

        cursor.execute("""
            UPDATE production_records
            SET pieces_completed = ?,
                pieces_altered = ?,
                total_earned = ?,
                production_speed_pcs_per_hr = ?,
                total_duration_minutes = ?,
                status = ?,
                complete_time = ?
            WHERE id = ?;
        """, (pieces_completed, pieces_altered, total_earned, speed_pcs_hr, net_active_minutes, new_status, now.isoformat() if is_done else None, production_id))

        return {
            "status": "ok",
            "production_id": production_id,
            "pieces_completed": pieces_completed,
            "speed_pcs_hr": speed_pcs_hr,
            "total_earned": total_earned,
            "is_completed": is_done
        }


def jobber_complete_and_send_lot(
    jobber_worker_id: int,
    lot_id: int,
    total_completed_pieces: int,
    notes: Optional[str] = None
) -> Dict[str, Any]:
    """Marks lot stitching complete under Jobber and dispatches it forward to Washing (prompting Owner)."""
    advance_res = complete_and_advance_lot_stage(lot_id, 3, jobber_worker_id, total_completed_pieces)
    return {
        "status": "ok",
        "lot_id": lot_id,
        "completed_pieces": total_completed_pieces,
        "advance_result": advance_res,
        "message": f"લોટ {total_completed_pieces} પીસ સાથે સિલાઈ પૂર્ણ થઈ વોશિંગ માટે આગળ મોકલાયો!"
    }


def get_detailed_jobbers_for_owner() -> List[Dict[str, Any]]:
    """Provides owner deep visibility into Jobbers, their machines, karigars, pay rates, speed & margins."""
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT j.*, COUNT(DISTINCT m.id) as machine_count
            FROM jobbers j
            LEFT JOIN machines m ON j.id = m.jobber_id AND m.is_active = 1
            WHERE j.is_active = 1
            GROUP BY j.id;
        """)
        jobbers = [dict(r) for r in cursor.fetchall()]

        for j in jobbers:
            jid = j["id"]
            # Active lots under this jobber
            cursor.execute("""
                SELECT DISTINCT l.id as lot_id, l.lot_number, l.total_cut_pieces,
                       d.name as design_name, d.design_number,
                       COALESCE((
                           SELECT SUM(pr.pieces_completed) FROM production_records pr
                           WHERE pr.lot_id = l.id AND pr.jobber_id = ?
                       ), 0) as pieces_completed,
                       COALESCE((
                           SELECT SUM(pr.pieces_assigned) FROM production_records pr
                           WHERE pr.lot_id = l.id AND pr.jobber_id = ?
                       ), 0) as pieces_assigned
                FROM lots l
                JOIN designs d ON l.design_id = d.id
                WHERE l.current_department_id = 3 AND l.current_status NOT IN ('COMPLETED_GODOWN', 'CANCELLED');
            """, (jid, jid))
            j["active_lots"] = [dict(r) for r in cursor.fetchall()]

            # Karigars working under this jobber
            cursor.execute("""
                SELECT w.id as worker_id, w.worker_code, w.full_name, w.phone,
                       m.machine_code,
                       COALESCE((
                           SELECT AVG(pr.rate_per_piece) FROM production_records pr
                           WHERE pr.worker_id = w.id AND pr.jobber_id = ?
                       ), w.rate_per_piece) as rate_paid_by_jobber,
                       COALESCE((
                           SELECT SUM(pr.pieces_completed) FROM production_records pr
                           WHERE pr.worker_id = w.id AND pr.jobber_id = ?
                       ), 0) as pieces_completed,
                       COALESCE((
                           SELECT AVG(pr.production_speed_pcs_per_hr) FROM production_records pr
                           WHERE pr.worker_id = w.id AND pr.jobber_id = ? AND pr.production_speed_pcs_per_hr > 0
                       ), 0.0) as avg_speed_pcs_hr,
                       COALESCE((
                           SELECT SUM(pr.total_earned) FROM production_records pr
                           WHERE pr.worker_id = w.id AND pr.jobber_id = ?
                       ), 0.0) as total_earned
                FROM workers w
                LEFT JOIN machines m ON w.machine_id = m.id
                WHERE w.jobber_id = ? OR w.id IN (
                    SELECT DISTINCT worker_id FROM production_records WHERE jobber_id = ?
                )
                ORDER BY w.id ASC;
            """, (jid, jid, jid, jid, jid, jid))
            karigars = [dict(r) for r in cursor.fetchall()]
            j["karigars"] = karigars

            # Calculate average karigar rate and jobber net margin
            rates = [k["rate_paid_by_jobber"] for k in karigars if k.get("rate_paid_by_jobber")]
            avg_k_rate = round(sum(rates) / len(rates), 2) if rates else 30.0
            factory_rate = j.get("stitching_rate_default") or 48.0
            j["avg_karigar_rate"] = avg_k_rate
            j["jobber_margin_per_piece"] = round(factory_rate - avg_k_rate, 2)
            j["total_pieces_completed"] = sum(k["pieces_completed"] for k in karigars)
            j["total_karigar_payout"] = round(sum(k["total_earned"] for k in karigars), 2)
            j["total_factory_payout"] = round(j["total_pieces_completed"] * factory_rate, 2)
            j["jobber_net_profit"] = round(j["total_factory_payout"] - j["total_karigar_payout"], 2)

        return jobbers


def get_daily_factory_activity(date_str: Optional[str] = None) -> Dict[str, Any]:
    """Retrieves live real-time factory floor activities for today and 9 PM closing summary."""
    import datetime
    today_date = datetime.date.today()
    target_date = date_str or today_date.isoformat()
    now = datetime.datetime.now()
    is_closing_time = now.hour >= 21  # 9 PM or later

    with get_db() as conn:
        cursor = conn.cursor()

        # 1. Fetch granular daily logs for target date
        cursor.execute("""
            SELECT l.*,
                   lot.lot_number, lot.total_cut_pieces as lot_total_pieces,
                   lot.bundle_size as lot_bundle_size, lot.bundles_count as lot_bundles_count,
                   lot.color_breakdown as lot_color_breakdown, lot.color_swatches as lot_color_swatches,
                   lot.sample_shirt_photo_url, lot.is_urgent,
                   d.name as design_name, d.design_number,
                   dept.name as department_name, dept.name_gu as department_name_gu, dept.code as department_code,
                   w.full_name as worker_name, w.worker_code, w.phone as worker_phone, w.role_designation as worker_role,
                   m.machine_code
            FROM daily_production_logs l
            LEFT JOIN lots lot ON l.lot_id = lot.id
            LEFT JOIN designs d ON lot.design_id = d.id
            LEFT JOIN departments dept ON l.department_id = dept.id
            LEFT JOIN workers w ON l.worker_id = w.id
            LEFT JOIN machines m ON l.machine_id = m.id
            WHERE l.log_date = ?
            ORDER BY l.id DESC;
        """, (target_date,))
        raw_logs = [dict(r) for r in cursor.fetchall()]

        activities = []
        for r in raw_logs:
            r["formatted_time"] = format_datetime_display(r["created_at"])
            activities.append(r)

        # If daily_production_logs is empty for target date, synthesize from real floor records
        if len(activities) == 0:
            cursor.execute("SELECT fi.* FROM fabric_inward fi WHERE fi.inward_date = ?;", (target_date,))
            for fi in cursor.fetchall():
                activities.append({
                    "id": 9000 + fi["id"],
                    "lot_id": None,
                    "activity_type": "FABRIC_INWARD",
                    "title": f"🧵 કાપડ આવક: {fi['supplier_name']} ({fi['meters_received']}m)",
                    "description": f"કાપડ પ્રકાર: {fi['fabric_type']} • ચલણ: {fi['challan_number'] or 'CH-DIRECT'} • કુલ મીટર: {fi['meters_received']}m",
                    "formatted_time": format_datetime_display(fi["created_at"]),
                    "is_stage_completed": True
                })

            cursor.execute("""
                SELECT l.*, d.name as design_name, d.design_number
                FROM lots l
                JOIN designs d ON l.design_id = d.id
                WHERE l.cutting_date = ?;
            """, (target_date,))
            for l in cursor.fetchall():
                b_size = l["bundle_size"] or 20
                b_count = l["bundles_count"] or max(1, l["total_cut_pieces"] // b_size)
                activities.append({
                    "id": 8000 + l["id"],
                    "lot_id": l["id"],
                    "lot_number": l["lot_number"],
                    "activity_type": "CUTTING_COMPLETED",
                    "title": f"✂️ કટીંગ પૂર્ણ: લોટ {l['lot_number']} ({l['total_cut_pieces']} પીસ)",
                    "description": f"ડીલર: {l['dealer_name'] or 'Direct'} • {b_count} બંડલ ({b_size} શર્ટ/બંડલ) • વધેલું કાપડ: {l['remnant_fabric_meters'] or 0}m • સિલાઈ માટે રવાના.",
                    "lot_total_pieces": l["total_cut_pieces"],
                    "lot_bundle_size": b_size,
                    "lot_bundles_count": b_count,
                    "sample_shirt_photo_url": l["sample_shirt_photo_url"],
                    "formatted_time": format_datetime_display(l["created_at"]),
                    "is_stage_completed": True
                })

            cursor.execute("""
                SELECT pr.*, w.full_name as worker_name, m.machine_code, l.lot_number,
                       l.bundle_size as lot_bundle_size, l.bundles_count as lot_bundles_count,
                       l.sample_shirt_photo_url
                FROM production_records pr
                JOIN workers w ON pr.worker_id = w.id
                LEFT JOIN machines m ON pr.machine_id = m.id
                JOIN lots l ON pr.lot_id = l.id
                WHERE DATE(pr.start_time) = ? OR DATE(pr.complete_time) = ?
                ORDER BY pr.id DESC;
            """, (target_date, target_date))
            for pr in cursor.fetchall():
                is_comp = pr["pieces_completed"] >= pr["pieces_assigned"]
                activities.append({
                    "id": 7000 + pr["id"],
                    "lot_id": pr["lot_id"],
                    "lot_number": pr["lot_number"],
                    "activity_type": "STITCHING_COMPLETED" if is_comp else "STITCHING_IN_PROGRESS",
                    "title": f"🪡 સિલાઈ પ્રગતિ: લોટ {pr['lot_number']} ({pr['pieces_completed']}/{pr['pieces_assigned']} પીસ)",
                    "description": f"કારીગર {pr['worker_name']} ({pr['machine_code'] or 'M-01'}) • {pr['pieces_completed']} પીસ તૈયાર • સ્પીડ: {pr['production_speed_pcs_per_hr']} pcs/hr",
                    "worker_name": pr["worker_name"],
                    "machine_code": pr["machine_code"],
                    "pieces_today": pr["pieces_completed"],
                    "sample_shirt_photo_url": pr["sample_shirt_photo_url"],
                    "formatted_time": format_datetime_display(pr["complete_time"] or pr["start_time"]),
                    "is_stage_completed": is_comp
                })

        # 2. Daily Floor Closing Metrics
        cursor.execute("""
            SELECT COALESCE(SUM(meters_received), 0)
            FROM fabric_inward
            WHERE inward_date = ?;
        """, (target_date,))
        fabric_meters_today = cursor.fetchone()[0]

        cursor.execute("""
            SELECT COALESCE(SUM(total_cut_pieces), 0)
            FROM lots
            WHERE cutting_date = ?;
        """, (target_date,))
        cut_pieces_today = cursor.fetchone()[0]

        cursor.execute("""
            SELECT COALESCE(SUM(pieces_completed), 0)
            FROM production_records
            WHERE DATE(start_time) = ? OR DATE(complete_time) = ?;
        """, (target_date, target_date))
        stitched_pieces_today = cursor.fetchone()[0]

        cursor.execute("""
            SELECT COALESCE(SUM(pieces_today), 0)
            FROM daily_production_logs
            WHERE log_date = ? AND activity_type LIKE '%WASH%';
        """, (target_date,))
        washed_pieces_today = cursor.fetchone()[0]

        cursor.execute("""
            SELECT COALESCE(SUM(pieces_today), 0)
            FROM daily_production_logs
            WHERE log_date = ? AND activity_type LIKE '%GAAJ%';
        """, (target_date,))
        gaaj_pieces_today = cursor.fetchone()[0]

        cursor.execute("""
            SELECT COALESCE(SUM(pieces_today), 0)
            FROM daily_production_logs
            WHERE log_date = ? AND (activity_type LIKE '%PRESS%' OR activity_type LIKE '%PACK%');
        """, (target_date,))
        pressed_pieces_today = cursor.fetchone()[0]

        cursor.execute("""
            SELECT COALESCE(SUM(quantity), 0)
            FROM stock_movements
            WHERE DATE(created_at) = ? AND movement_type = 'INWARD_FROM_PRODUCTION';
        """, (target_date,))
        godown_shirts_today = cursor.fetchone()[0]

        # 3. Lot-by-Lot Status Summary for Today
        cursor.execute("""
            SELECT DISTINCT l.id as lot_id, l.lot_number, l.total_cut_pieces,
                   l.bundle_size, l.bundles_count, l.color_breakdown, l.color_swatches,
                   l.sample_shirt_photo_url, l.current_status, l.current_department_id,
                   d.name as design_name, d.design_number,
                   dept.name as current_dept_name, dept.name_gu as current_dept_name_gu
            FROM lots l
            JOIN designs d ON l.design_id = d.id
            JOIN departments dept ON l.current_department_id = dept.id
            WHERE l.id IN (
                SELECT DISTINCT lot_id FROM daily_production_logs WHERE log_date = ? AND lot_id IS NOT NULL
                UNION
                SELECT id FROM lots WHERE cutting_date = ?
            )
            ORDER BY l.id DESC;
        """, (target_date, target_date))
        touched_lots = [dict(r) for r in cursor.fetchall()]

        lot_progress_summary = []
        for tlot in touched_lots:
            lid = tlot["lot_id"]
            cursor.execute("""
                SELECT COALESCE(SUM(pieces_today), 0)
                FROM daily_production_logs
                WHERE lot_id = ? AND log_date = ?;
            """, (lid, target_date))
            today_pcs = cursor.fetchone()[0]

            cursor.execute("""
                SELECT COALESCE(SUM(pieces_completed), 0)
                FROM production_records
                WHERE lot_id = ?;
            """, (lid,))
            cumulative_pcs = cursor.fetchone()[0]

            is_done = tlot["current_status"] == 'COMPLETED_GODOWN'
            tot = tlot["total_cut_pieces"] or 1
            pct = min(100, int((cumulative_pcs / tot) * 100)) if cumulative_pcs > 0 else (100 if is_done else 20)
            status_str = f"✅ લોટ પૂર્ણ ({cumulative_pcs}/{tot} પીસ તૈયાર)" if is_done else f"🔄 ચાલુ ({tlot['current_dept_name_gu'] or tlot['current_dept_name']} - {today_pcs} પીસ આજે પ્રોસેસ)"

            lot_progress_summary.append({
                "lot_id": lid,
                "lot_number": tlot["lot_number"],
                "design_name": tlot["design_name"],
                "design_number": tlot["design_number"],
                "total_cut_pieces": tot,
                "bundle_size": tlot["bundle_size"] or 20,
                "bundles_count": tlot["bundles_count"] or max(1, tot // 20),
                "color_breakdown": tlot["color_breakdown"],
                "color_swatches": tlot["color_swatches"],
                "sample_shirt_photo_url": tlot["sample_shirt_photo_url"],
                "pieces_today": today_pcs,
                "cumulative_pieces": cumulative_pcs,
                "progress_percent": pct,
                "is_completed": is_done,
                "current_department": tlot["current_dept_name_gu"] or tlot["current_dept_name"],
                "status_label": status_str
            })

        # 4. Worker Output Summary for Today
        cursor.execute("""
            SELECT w.id as worker_id, w.full_name as worker_name, w.role_designation as role,
                   m.machine_code,
                   COALESCE(SUM(pr.pieces_completed), 0) as pieces_today,
                   COALESCE(SUM(pr.total_earned), 0.0) as earnings_today,
                   COALESCE(AVG(pr.production_speed_pcs_per_hr), 0.0) as avg_speed
            FROM workers w
            LEFT JOIN machines m ON w.machine_id = m.id
            JOIN production_records pr ON pr.worker_id = w.id
            WHERE DATE(pr.start_time) = ? OR DATE(pr.complete_time) = ?
            GROUP BY w.id
            ORDER BY pieces_today DESC;
        """, (target_date, target_date))
        worker_summary = [dict(r) for r in cursor.fetchall()]

        closing_report = {
            "date": target_date,
            "formatted_date": format_datetime_display(target_date),
            "is_after_9pm": is_closing_time,
            "metrics": {
                "fabric_meters_inward": fabric_meters_today,
                "pieces_cut": cut_pieces_today,
                "pieces_stitched": stitched_pieces_today,
                "pieces_washed": washed_pieces_today,
                "pieces_gaaj_button": gaaj_pieces_today,
                "pieces_ironed_packed": pressed_pieces_today,
                "finished_to_godown": godown_shirts_today,
                "active_workers_count": len(worker_summary)
            },
            "lots": lot_progress_summary,
            "workers": worker_summary
        }

        return {
            "target_date": target_date,
            "formatted_date": format_datetime_display(target_date),
            "is_after_9pm": is_closing_time,
            "activities_count": len(activities),
            "live_activities": activities,
            "closing_report": closing_report
        }


def get_lot_production_journey(lot_id: int) -> Optional[Dict[str, Any]]:
    """Generates the full 9-stage factory production journey audit and worker contribution ledger for a lot."""
    with get_db() as conn:
        cursor = conn.cursor()

        # 1. Fetch Lot Details
        cursor.execute("""
            SELECT l.*,
                   d.name as design_name, d.design_number, d.fabric_type,
                   fi.supplier_name, fi.meters_received, fi.inward_number,
                   w_cut.full_name as cutting_master_name, w_cut.phone as cutting_master_phone,
                   dept.name as current_dept_name, dept.name_gu as current_dept_name_gu
            FROM lots l
            JOIN designs d ON l.design_id = d.id
            LEFT JOIN fabric_inward fi ON l.fabric_inward_id = fi.id
            LEFT JOIN workers w_cut ON l.cutting_master_worker_id = w_cut.id
            LEFT JOIN departments dept ON l.current_department_id = dept.id
            WHERE l.id = ?;
        """, (lot_id,))
        lot_row = cursor.fetchone()
        if not lot_row:
            return None
        lot = dict(lot_row)
        lot["formatted_created_at"] = format_datetime_display(lot["created_at"])
        lot["formatted_cutting_date"] = format_datetime_display(lot["cutting_date"])
        lot["bundle_size"] = lot.get("bundle_size") or 20
        lot["bundles_count"] = lot.get("bundles_count") or max(1, (lot.get("total_cut_pieces") or 20) // (lot["bundle_size"]))

        # 2. Stage Routes
        cursor.execute("""
            SELECT r.*, d.name as dept_name, d.name_gu as dept_name_gu, d.code as dept_code,
                   w.full_name as assigned_worker_name, w.role_designation as worker_role
            FROM lot_process_routes r
            JOIN departments d ON r.department_id = d.id
            LEFT JOIN workers w ON r.worker_id = w.id
            WHERE r.lot_id = ?
            ORDER BY r.stage_sequence ASC;
        """, (lot_id,))
        routes = [dict(r) for r in cursor.fetchall()]

        # 3. Production records (Karigar Machine Work)
        cursor.execute("""
            SELECT pr.*, w.full_name as worker_name, w.worker_code, w.phone as worker_phone,
                   m.machine_code, j.name as jobber_name
            FROM production_records pr
            JOIN workers w ON pr.worker_id = w.id
            LEFT JOIN machines m ON pr.machine_id = m.id
            LEFT JOIN jobbers j ON pr.jobber_id = j.id
            WHERE pr.lot_id = ?
            ORDER BY pr.id ASC;
        """, (lot_id,))
        prod_records = [dict(r) for r in cursor.fetchall()]

        # 4. Movements
        cursor.execute("""
            SELECT lm.*,
                   d_from.name as from_dept_name, d_to.name as to_dept_name,
                   w_sent.full_name as sent_worker_name, w_recv.full_name as recv_worker_name
            FROM lot_movements lm
            JOIN departments d_from ON lm.from_department_id = d_from.id
            JOIN departments d_to ON lm.to_department_id = d_to.id
            LEFT JOIN workers w_sent ON lm.sent_by_worker_id = w_sent.id
            LEFT JOIN workers w_recv ON lm.received_by_worker_id = w_recv.id
            WHERE lm.lot_id = ?
            ORDER BY lm.id ASC;
        """, (lot_id,))
        movements = [dict(r) for r in cursor.fetchall()]

        curr_dept_id = lot["current_department_id"]
        is_godown_complete = lot["current_status"] == 'COMPLETED_GODOWN'

        # Stage 1: Fabric Inward
        s1 = {
            "stage_num": 1,
            "title": "Fabric Inward – Godown",
            "title_gu": "કાપડ આવક – ગોડાઉન",
            "title_hi": "कपड़ा आवक – गोदाम",
            "icon": "🧵",
            "status": 'COMPLETED',
            "worker_name": "Kanti Bhai Inward",
            "worker_phone": "9876500001",
            "worker_role": "Godown Master",
            "days_taken": 1,
            "duration_text": "Completed in 1 Day",
            "pieces": lot.get("total_cut_pieces"),
            "date_formatted": format_datetime_display(lot.get("cutting_date")),
            "details": f"Dealer: {lot.get('dealer_name') or lot.get('supplier_name') or 'Direct'} | {lot.get('meters_consumed') or 0}m consumed, {lot.get('remnant_fabric_meters') or 0}m left in factory godown.",
            "details_gu": f"ડીલર: {lot.get('dealer_name') or lot.get('supplier_name') or 'Direct'} | {lot.get('meters_consumed') or 0}m વપરાયું, {lot.get('remnant_fabric_meters') or 0}m ફેક્ટરીમાં બાકી.",
            "details_hi": f"डीलर: {lot.get('dealer_name') or lot.get('supplier_name') or 'Direct'} | {lot.get('meters_consumed') or 0}m उपयोग, {lot.get('remnant_fabric_meters') or 0}m फैक्ट्री में शेष।"
        }

        # Stage 2: Cutting – Master
        cb_raw = lot.get("color_breakdown") or "Sky Blue: 200, Navy: 180, White: 120"
        cb_list = []
        if cb_raw:
            parts = [p.strip() for p in cb_raw.replace(";", ",").split(",") if p.strip()]
            for p in parts:
                if ":" in p:
                    cname, cpcs = p.split(":", 1)
                    try:
                        pcs_val = int(cpcs.strip().replace("pcs", "").replace("pieces", "").strip())
                    except ValueError:
                        pcs_val = 0
                    cb_list.append({"color": cname.strip(), "pieces": pcs_val})
                else:
                    cb_list.append({"color": p.strip(), "pieces": 0})

        lot["color_breakdown"] = cb_raw
        lot["color_breakdown_parsed"] = cb_list

        s2 = {
            "stage_num": 2,
            "title": "Cutting – Master",
            "title_gu": "કટીંગ – માસ્ટર",
            "title_hi": "कटिंग – मास्टर",
            "icon": "✂️",
            "status": 'COMPLETED',
            "date_formatted": format_datetime_display(lot.get("cutting_date")),
            "worker_name": lot.get("cutting_master_name") or "Kanti Bhai Master",
            "worker_phone": lot.get("cutting_master_phone") or "9876500001",
            "worker_role": "Cutting Master",
            "days_taken": 1,
            "duration_text": "Completed in 1 Day",
            "pieces": lot.get("total_cut_pieces"),
            "color_breakdown": cb_raw,
            "color_breakdown_parsed": cb_list,
            "bundles": f"{lot.get('bundles_count')} bundles ({lot.get('bundle_size')} shirts/bundle)",
            "details": f"{lot.get('total_cut_pieces')} pieces cut across {len(cb_list)} colors and packaged into bundles.",
            "details_gu": f"{lot.get('total_cut_pieces')} પીસ કટીંગ કરી બંડલ પેક કરવામાં આવ્યા.",
            "details_hi": f"{lot.get('total_cut_pieces')} पीस कटिंग कर बंडल पैक किए गए।"
        }

        # Stage 3: Jobber Hub
        jobber_names = list(set([pr["jobber_name"] for pr in prod_records if pr.get("jobber_name")]))
        s3_status = 'COMPLETED' if (curr_dept_id > 3 or is_godown_complete) else ('IN_PROGRESS' if curr_dept_id == 3 else 'PENDING')
        s3 = {
            "stage_num": 3,
            "title": "Jobber Distribution",
            "title_gu": "જોબર વિતરણ",
            "title_hi": "जॉबर वितरण",
            "icon": "🏢",
            "status": s3_status,
            "worker_name": ", ".join(jobber_names) if jobber_names else "Babu Bhai Contractor",
            "worker_phone": "9876500601",
            "worker_role": "Jobber / Floor Manager",
            "days_taken": 1,
            "duration_text": "Completed in 1 Day",
            "jobber_name": ", ".join(jobber_names) if jobber_names else "Babu Bhai Contractor",
            "pieces": lot.get("total_cut_pieces"),
            "details": "Work distributed across machines and karigars by Jobber.",
            "details_gu": "જોબર દ્વારા કારીગરો અને મશીનો વચ્ચે કામ વિતરિત કરવામાં આવ્યું.",
            "details_hi": "जॉबर द्वारा कारीगरों एवं मशीनों में काम बांटा गया।"
        }

        # Stage 4: Machine Work – Individual Workers
        s4_status = 'COMPLETED' if (curr_dept_id > 3 or is_godown_complete) else ('IN_PROGRESS' if curr_dept_id == 3 else 'PENDING')
        
        # Query day-by-day piece output for this lot
        cursor.execute("""
            SELECT dpl.log_date, dpl.pieces_today, dpl.cumulative_pieces, w.full_name as worker_name, dpl.activity_type
            FROM daily_production_logs dpl
            LEFT JOIN workers w ON dpl.worker_id = w.id
            WHERE dpl.lot_id = ?
            ORDER BY dpl.log_date ASC, dpl.id ASC;
        """, (lot_id,))
        lot_daily_breakdown = [dict(r) for r in cursor.fetchall()]

        # Compute turnaround days for stitching
        earliest_start = min([pr["start_time"] for pr in prod_records if pr.get("start_time")], default=None)
        latest_complete = max([pr["complete_time"] for pr in prod_records if pr.get("complete_time")], default=None)
        if earliest_start and latest_complete and s4_status == 'COMPLETED':
            d1_str = earliest_start[:10]
            d2_str = latest_complete[:10]
            try:
                days_taken = max(1, (datetime.date.fromisoformat(d2_str) - datetime.date.fromisoformat(d1_str)).days + 1)
            except Exception:
                days_taken = 3
            duration_text = f"Completed in {days_taken} Days ({d1_str} → {d2_str})"
        elif earliest_start:
            d1_str = earliest_start[:10]
            try:
                days_taken = max(1, (datetime.date.today() - datetime.date.fromisoformat(d1_str)).days + 1)
            except Exception:
                days_taken = 1
            duration_text = f"In Progress • Day {days_taken} (Started {d1_str})"
        else:
            days_taken = 1
            duration_text = "1 Day"

        s4_workers = []
        for pr in prod_records:
            w_start = pr.get("start_time")
            w_comp = pr.get("complete_time")
            if w_start and w_comp and pr["status"] == "COMPLETED":
                try:
                    w_days = max(1, (datetime.date.fromisoformat(w_comp[:10]) - datetime.date.fromisoformat(w_start[:10])).days + 1)
                except Exception:
                    w_days = 3
                w_dur = f"{w_days} Days"
            elif w_start:
                try:
                    w_days = max(1, (datetime.date.today() - datetime.date.fromisoformat(w_start[:10])).days + 1)
                except Exception:
                    w_days = 1
                w_dur = f"Day {w_days}"
            else:
                w_days = 1
                w_dur = "1 Day"

            s4_workers.append({
                "worker_name": pr["worker_name"],
                "worker_phone": pr.get("worker_phone") or "9876500101",
                "worker_role": "Stitcher / Sewer (Karigar)",
                "worker_code": pr["worker_code"],
                "machine_code": pr.get("machine_code") or "M-01",
                "pieces_assigned": pr["pieces_assigned"],
                "pieces_completed": pr["pieces_completed"],
                "days_taken": w_days,
                "duration_text": w_dur,
                "rate": pr["rate_per_piece"],
                "earned": pr["total_earned"],
                "speed_pcs_hr": pr["production_speed_pcs_per_hr"]
            })

        s4 = {
            "stage_num": 4,
            "title": "Machine Work – Individual Workers",
            "title_gu": "સિલાઈ કામ – મશીન કારીગરો",
            "title_hi": "सिलाई कार्य – मशीन कारीगर",
            "icon": "🪡",
            "status": s4_status,
            "worker_name": s4_workers[0]["worker_name"] if s4_workers else "Dinesh Kumar",
            "worker_phone": s4_workers[0]["worker_phone"] if s4_workers else "9876500101",
            "worker_role": "Stitcher / Sewer (Karigar)",
            "workers": s4_workers,
            "days_taken": days_taken,
            "duration_text": duration_text,
            "pieces": lot.get("total_cut_pieces"),
            "daily_breakdown": lot_daily_breakdown,
            "details": f"{len(s4_workers)} karigars active • {duration_text}.",
            "details_gu": f"{len(s4_workers)} કારીગરો • {duration_text}.",
            "details_hi": f"{len(s4_workers)} कारीगर • {duration_text}।"
        }

        # Stage 5: Embroidery / Screen Printing
        has_emb = bool(lot.get("color_swatches") and ("embroidery" in str(lot.get("color_swatches")).lower()))
        s5_status = 'SKIPPED' if not has_emb else ('COMPLETED' if (curr_dept_id > 5 or is_godown_complete) else ('IN_PROGRESS' if curr_dept_id in (4, 5) else 'PENDING'))
        s5 = {
            "stage_num": 5,
            "title": "Embroidery / Screen Printing",
            "title_gu": "ભરતકામ / સ્ક્રિન પ્રિન્ટિંગ",
            "title_hi": "कढ़ाई / स्क्रीन प्रिंटिंग",
            "icon": "🎨",
            "status": s5_status,
            "worker_name": "Irfan Bhai Printer" if has_emb else "Farooq Bhai Embroidery",
            "worker_phone": "9876500701" if has_emb else "9876500801",
            "worker_role": "Screen Printing / Embroidery Master",
            "days_taken": 2 if s5_status == 'COMPLETED' else 1,
            "duration_text": f"{2 if s5_status == 'COMPLETED' else 1} Days Taken" if has_emb else "Skipped",
            "pieces": lot.get("total_cut_pieces") if has_emb else 0,
            "details": "Embroidery/printing process active for this lot." if has_emb else "Not required for this design (Skipped).",
            "details_gu": "આ લોટ માટે ભરતકામ/પ્રિન્ટિંગ પ્રક્રિયા." if has_emb else "આ ડિઝાઇન માટે ભરતકામ જરૂરી નથી (Skipped).",
            "details_hi": "इस लॉट के लिए कढ़ाई/प्रिंटिंग प्रक्रिया।" if has_emb else "इस डिजाइन के लिए आवश्यक नहीं (Skipped)।"
        }

        # Stage 6: Washing
        wash_route = next((r for r in routes if r["department_id"] == 6), None)
        s6_status = 'COMPLETED' if (curr_dept_id > 6 or is_godown_complete) else ('IN_PROGRESS' if curr_dept_id == 6 else 'PENDING')
        s6 = {
            "stage_num": 6,
            "title": "Washing & Laundry",
            "title_gu": "વોશિંગ & લોન્ડ્રી",
            "title_hi": "वाशिंग व लॉन्ड्री",
            "icon": "🧼",
            "status": s6_status,
            "worker_name": (wash_route.get("assigned_worker_name") if wash_route else None) or "Mukesh Bhai Washer",
            "worker_phone": "9876500301",
            "worker_role": "Washer",
            "days_taken": 2 if s6_status == 'COMPLETED' else 1,
            "duration_text": "Completed in 2 Days" if s6_status == 'COMPLETED' else ("In Progress • Day 1" if s6_status == 'IN_PROGRESS' else "Pending"),
            "pieces": lot.get("total_cut_pieces"),
            "details": "Shirt washing and softening process.",
            "details_gu": "શર્ટ વોશિંગ અને સોફ્ટનિંગ પ્રક્રિયા.",
            "details_hi": "शर्ट वाशिंग एवं सॉफ्टनिंग प्रक्रिया।"
        }

        # Stage 7: Gaaj-Button
        gaaj_route = next((r for r in routes if r["department_id"] == 7), None)
        s7_status = 'COMPLETED' if (curr_dept_id > 7 or is_godown_complete) else ('IN_PROGRESS' if curr_dept_id == 7 else 'PENDING')
        s7 = {
            "stage_num": 7,
            "title": "Gaaj-Button",
            "title_gu": "ગાજ-બટન",
            "title_hi": "गाज-बटन",
            "icon": "🔘",
            "status": s7_status,
            "worker_name": (gaaj_route.get("assigned_worker_name") if gaaj_route else None) or "Ashok Bhai Gaaj",
            "worker_phone": "9876500401",
            "worker_role": "Gaaj-Button Operator",
            "days_taken": 1,
            "duration_text": "Completed in 1 Day" if s7_status == 'COMPLETED' else ("In Progress" if s7_status == 'IN_PROGRESS' else "Pending"),
            "pieces": lot.get("total_cut_pieces"),
            "details": "Buttonhole cutting and button stitching.",
            "details_gu": "કોલર અને કફ બટન ટાંકવાની પ્રક્રિયા.",
            "details_hi": "कॉलर व कफ बटन टांकने की प्रक्रिया।"
        }

        # Stage 8: Press and Packing
        press_route = next((r for r in routes if r["department_id"] == 8), None)
        s8_status = 'COMPLETED' if is_godown_complete else ('IN_PROGRESS' if curr_dept_id == 8 else 'PENDING')
        s8 = {
            "stage_num": 8,
            "title": "Press and Packing",
            "title_gu": "પ્રેસ & પેકિંગ",
            "title_hi": "प्रेस व पैकिंग",
            "icon": "📦",
            "status": s8_status,
            "worker_name": (press_route.get("assigned_worker_name") if press_route else None) or "Vinod Bhai Press",
            "worker_phone": "9876500501",
            "worker_role": "Press & Packing Master",
            "days_taken": 1,
            "duration_text": "Completed in 1 Day" if s8_status == 'COMPLETED' else ("In Progress" if s8_status == 'IN_PROGRESS' else "Pending"),
            "pieces": lot.get("total_cut_pieces"),
            "details": "Ironing, tagging, and individual box packaging.",
            "details_gu": "ઇસ્ત્રી, ટેગિંગ અને બોક્સ પેકિંગ.",
            "details_hi": "इस्त्री, टैगिंग एवं बॉक्स पैकिंग।"
        }

        # Stage 9: Finished Goods – Godown
        s9_status = 'COMPLETED' if is_godown_complete else 'PENDING'
        s9 = {
            "stage_num": 9,
            "title": "Finished Goods – Godown",
            "title_gu": "તૈયાર માલ – ગોડાઉન",
            "title_hi": "तैयार माल – गोदाम",
            "icon": "🏛️",
            "status": s9_status,
            "worker_name": "Godown Inventory Master",
            "worker_phone": "9876500001",
            "worker_role": "Finished Goods Manager",
            "days_taken": 1,
            "duration_text": "Stock Finalized" if is_godown_complete else "Pending Completion",
            "pieces": lot.get("total_cut_pieces") if is_godown_complete else 0,
            "details": "Finished shirts received in godown and ready for dispatch." if is_godown_complete else "Finished shirts will be added to godown stock upon completion.",
            "details_gu": "તૈયાર શર્ટ ગોડાઉનમાં જમા થયા અને ડિસ્પેચ માટે તૈયાર છે." if is_godown_complete else "ઉત્પાદન પૂર્ણ થતાં સીધા ગોડાઉનમાં જમા થશે.",
            "details_hi": "तैयार शर्ट गोदाम में जमा हो गए और डिस्पैच के लिए तैयार हैं।" if is_godown_complete else "उत्पादन पूर्ण होते ही सीधे गोदाम में जमा होंगे।"
        }

        stages = [s1, s2, s3, s4, s5, s6, s7, s8, s9]

        # Consolidated Workers Ledger
        workers_dict = {}
        if lot.get("cutting_master_name"):
            workers_dict["cutter"] = {
                "name": lot["cutting_master_name"],
                "role": "Cutting Master", "role_gu": "કટીંગ માસ્ટર", "role_hi": "कटिंग मास्टर",
                "phone": lot.get("cutting_master_phone") or "-",
                "pieces": lot.get("total_cut_pieces"),
                "machine": "Cutting Table"
            }
        for pr in prod_records:
            wid = pr["worker_id"]
            if wid not in workers_dict:
                workers_dict[wid] = {
                    "name": pr["worker_name"],
                    "role": "Stitcher / Karigar", "role_gu": "સિલાઈ કારીગર", "role_hi": "सिलाई कारीगर",
                    "phone": pr.get("worker_phone") or "-",
                    "machine": pr.get("machine_code") or "M-01",
                    "pieces": pr["pieces_completed"],
                    "earned": pr["total_earned"],
                    "rate": pr["rate_per_piece"],
                    "speed": pr["production_speed_pcs_per_hr"]
                }
            else:
                workers_dict[wid]["pieces"] += pr["pieces_completed"]
                workers_dict[wid]["earned"] = round(workers_dict[wid].get("earned", 0) + pr["total_earned"], 2)

        # Audit Timeline from Daily Production Logs
        cursor.execute("""
            SELECT l.*,
                   w.full_name as worker_name,
                   dept.name as department_name, dept.name_gu as department_name_gu
            FROM daily_production_logs l
            LEFT JOIN workers w ON l.worker_id = w.id
            LEFT JOIN departments dept ON l.department_id = dept.id
            WHERE l.lot_id = ?
            ORDER BY l.id ASC;
        """, (lot_id,))
        timeline = []
        for r in cursor.fetchall():
            row_dict = dict(r)
            row_dict["formatted_time"] = format_datetime_display(row_dict["created_at"])
            timeline.append(row_dict)

        return {
            "lot": lot,
            "stages": stages,
            "workers_involved": list(workers_dict.values()),
            "movements": movements,
            "timeline": timeline
        }
