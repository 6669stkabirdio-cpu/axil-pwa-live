"""
AXIL Factory Management PWA - SQLite Database Engine
Configured with Foreign Key enforcement, WAL mode, and connection helpers.
"""

import sqlite3
import os
from contextlib import contextmanager
from typing import Generator

DB_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")
DB_PATH = os.path.join(DB_DIR, "axil_factory.db")

os.makedirs(DB_DIR, exist_ok=True)


def get_db_connection() -> sqlite3.Connection:
    """Creates a configured connection to SQLite database."""
    conn = sqlite3.connect(DB_PATH, timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA synchronous = NORMAL;")
    return conn


@contextmanager
def get_db() -> Generator[sqlite3.Connection, None, None]:
    """Context manager for safe database transactions."""
    conn = get_db_connection()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def init_db():
    """Initializes the complete relational schema for AXIL."""
    with get_db() as conn:
        cursor = conn.cursor()

        # 1. Departments Master
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS departments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            code TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            name_hi TEXT,
            name_gu TEXT,
            sequence_order INTEGER NOT NULL,
            is_production BOOLEAN DEFAULT 1,
            is_active BOOLEAN DEFAULT 1
        );
        """)

        # 2. Jobbers Master
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS jobbers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            phone TEXT,
            workshop_address TEXT,
            stitching_rate_default REAL DEFAULT 0.0,
            is_active BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 3. Machines Master
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS machines (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            machine_code TEXT UNIQUE NOT NULL,
            jobber_id INTEGER REFERENCES jobbers(id) ON DELETE SET NULL,
            machine_type TEXT NOT NULL,
            status TEXT DEFAULT 'ACTIVE',
            is_active BOOLEAN DEFAULT 1
        );
        """)

        # 4. Workers / Karigars Master
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS workers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            worker_code TEXT UNIQUE NOT NULL,
            full_name TEXT NOT NULL,
            phone TEXT,
            department_id INTEGER REFERENCES departments(id) ON DELETE SET NULL,
            jobber_id INTEGER REFERENCES jobbers(id) ON DELETE SET NULL,
            machine_id INTEGER REFERENCES machines(id) ON DELETE SET NULL,
            role_designation TEXT NOT NULL,
            rate_per_piece REAL DEFAULT 0.0,
            daily_wage REAL DEFAULT 0.0,
            pin_hash TEXT,
            language_preference TEXT DEFAULT 'gu',
            is_active BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 5. Users and Roles
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('OWNER', 'WORKER')),
            worker_id INTEGER REFERENCES workers(id) ON DELETE CASCADE,
            full_name TEXT NOT NULL,
            is_active BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 5b. User Sessions (Persistent device authentication)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS user_sessions (
            token TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            username TEXT NOT NULL,
            role TEXT NOT NULL,
            full_name TEXT NOT NULL,
            worker_id INTEGER,
            created_at REAL NOT NULL,
            expires_at REAL NOT NULL
        );
        """)
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_user_sessions_token ON user_sessions(token);")

        # 6. Designs Master
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS designs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            design_number TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            fabric_type TEXT NOT NULL,
            collar_style TEXT,
            sleeve_type TEXT,
            has_embroidery BOOLEAN DEFAULT 0,
            has_screen_print BOOLEAN DEFAULT 0,
            standard_cutting_rate REAL DEFAULT 0.0,
            standard_stitching_rate REAL DEFAULT 0.0,
            standard_screen_rate REAL DEFAULT 0.0,
            standard_embroidery_rate REAL DEFAULT 0.0,
            standard_washing_rate REAL DEFAULT 0.0,
            standard_gaaj_button_rate REAL DEFAULT 0.0,
            standard_press_packing_rate REAL DEFAULT 0.0,
            image_url TEXT,
            notes TEXT,
            is_active BOOLEAN DEFAULT 1,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 7. Fabric Inward
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS fabric_inward (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            inward_number TEXT UNIQUE NOT NULL,
            supplier_name TEXT NOT NULL,
            challan_number TEXT,
            fabric_type TEXT NOT NULL,
            color_shade TEXT,
            rolls_count INTEGER DEFAULT 1,
            meters_received REAL NOT NULL,
            rate_per_meter REAL DEFAULT 0.0,
            total_fabric_cost REAL DEFAULT 0.0,
            meters_used REAL DEFAULT 0.0,
            remaining_meters REAL NOT NULL,
            inward_date DATE NOT NULL,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 8. Lots Master
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS lots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            lot_number TEXT UNIQUE NOT NULL,
            design_id INTEGER NOT NULL REFERENCES designs(id),
            fabric_inward_id INTEGER REFERENCES fabric_inward(id),
            meters_consumed REAL DEFAULT 0.0,
            cutting_master_worker_id INTEGER REFERENCES workers(id),
            cutting_date DATE NOT NULL,
            total_cut_pieces INTEGER NOT NULL,
            current_department_id INTEGER NOT NULL REFERENCES departments(id),
            current_status TEXT DEFAULT 'CUTTING',
            is_delayed BOOLEAN DEFAULT 0,
            delay_reason TEXT,
            cutting_rate_per_piece REAL DEFAULT 0.0,
            cutting_total_cost REAL DEFAULT 0.0,
            target_completion_date DATE,
            completed_at TIMESTAMP,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 9. Lot Process Routes (Flexible department sequencing per lot)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS lot_process_routes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            lot_id INTEGER NOT NULL REFERENCES lots(id) ON DELETE CASCADE,
            stage_sequence INTEGER NOT NULL,
            department_id INTEGER NOT NULL REFERENCES departments(id),
            status TEXT DEFAULT 'PENDING' CHECK(status IN ('PENDING', 'IN_PROGRESS', 'COMPLETED', 'SKIPPED')),
            started_at TIMESTAMP,
            completed_at TIMESTAMP,
            UNIQUE(lot_id, stage_sequence)
        );
        """)

        # 10. Lot Movements & Handover Shortage Spotting
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS lot_movements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            movement_number TEXT UNIQUE NOT NULL,
            lot_id INTEGER NOT NULL REFERENCES lots(id),
            from_department_id INTEGER NOT NULL REFERENCES departments(id),
            to_department_id INTEGER NOT NULL REFERENCES departments(id),
            sent_by_worker_id INTEGER REFERENCES workers(id),
            sent_quantity INTEGER NOT NULL,
            sent_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            received_by_worker_id INTEGER REFERENCES workers(id),
            received_quantity INTEGER DEFAULT NULL,
            received_timestamp TIMESTAMP DEFAULT NULL,
            shortage_quantity INTEGER DEFAULT 0,
            shortage_reason TEXT,
            is_confirmed BOOLEAN DEFAULT 0,
            notes TEXT
        );
        """)

        # 11. Karigar Production Records (Piece count, start/complete time, bundles, pause, speed)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS production_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            lot_id INTEGER NOT NULL REFERENCES lots(id),
            department_id INTEGER NOT NULL REFERENCES departments(id),
            jobber_id INTEGER REFERENCES jobbers(id),
            machine_id INTEGER REFERENCES machines(id),
            worker_id INTEGER NOT NULL REFERENCES workers(id),
            pieces_assigned INTEGER NOT NULL,
            pieces_completed INTEGER DEFAULT 0,
            pieces_altered INTEGER DEFAULT 0,
            bundles_count INTEGER DEFAULT 0,
            bundle_size INTEGER DEFAULT 20,
            loose_pieces INTEGER DEFAULT 0,
            total_pause_minutes INTEGER DEFAULT 0,
            is_paused BOOLEAN DEFAULT 0,
            current_pause_start TIMESTAMP,
            current_pause_reason TEXT,
            rate_per_piece REAL DEFAULT 0.0,
            total_earned REAL DEFAULT 0.0,
            start_time TIMESTAMP,
            complete_time TIMESTAMP,
            total_duration_minutes INTEGER DEFAULT 0,
            production_speed_pcs_per_hr REAL DEFAULT 0.0,
            status TEXT DEFAULT 'ASSIGNED' CHECK(status IN ('ASSIGNED', 'IN_PROGRESS', 'COMPLETED')),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 11b. Production Breaks (Worker Pause tracking with reasons and timestamps)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS production_breaks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            production_id INTEGER NOT NULL REFERENCES production_records(id) ON DELETE CASCADE,
            worker_id INTEGER NOT NULL REFERENCES workers(id),
            break_reason TEXT NOT NULL,
            started_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
            ended_at TIMESTAMP,
            duration_minutes INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 12. Alterations Tracking
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS alterations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            lot_id INTEGER NOT NULL REFERENCES lots(id),
            department_id INTEGER NOT NULL REFERENCES departments(id),
            worker_id INTEGER NOT NULL REFERENCES workers(id),
            alteration_pieces INTEGER NOT NULL,
            defect_type TEXT NOT NULL,
            defect_description TEXT,
            status TEXT DEFAULT 'PENDING' CHECK(status IN ('PENDING', 'RECTIFIED', 'REJECTED')),
            rectified_pieces INTEGER DEFAULT 0,
            rectified_at TIMESTAMP,
            reported_by_worker_id INTEGER REFERENCES workers(id),
            reported_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            notification_sent BOOLEAN DEFAULT 1
        );
        """)

        # 13. Customers Master
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS customers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_name TEXT NOT NULL,
            shop_name TEXT,
            phone TEXT NOT NULL,
            city TEXT,
            gst_number TEXT,
            address TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 14. Orders Master
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_number TEXT UNIQUE NOT NULL,
            customer_id INTEGER NOT NULL REFERENCES customers(id),
            design_id INTEGER NOT NULL REFERENCES designs(id),
            lot_id INTEGER REFERENCES lots(id),
            total_quantity INTEGER NOT NULL,
            order_date DATE NOT NULL,
            delivery_due_date DATE NOT NULL,
            current_status TEXT DEFAULT 'RECEIVED' CHECK(current_status IN (
                'RECEIVED', 'IN_PROCESS', 'PRODUCTION_COMPLETED', 'READY_FOR_PACKING', 'PACKED', 'DISPATCHED', 'DELIVERED'
            )),
            priority TEXT DEFAULT 'NORMAL' CHECK(priority IN ('NORMAL', 'URGENT')),
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 15. Order Status History
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS order_status_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
            status TEXT NOT NULL,
            updated_by TEXT NOT NULL,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            notes TEXT
        );
        """)

        # 16. Dispatches
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS dispatches (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            order_id INTEGER NOT NULL REFERENCES orders(id),
            dispatch_number TEXT UNIQUE NOT NULL,
            dispatched_quantity INTEGER NOT NULL,
            parcel_count INTEGER DEFAULT 1,
            transport_name TEXT NOT NULL,
            tracking_lr_number TEXT,
            dispatch_date DATE NOT NULL,
            packed_by TEXT,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 17. Daily Attendance Records
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            worker_id INTEGER NOT NULL REFERENCES workers(id) ON DELETE CASCADE,
            date DATE NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('PRESENT', 'ABSENT', 'HALF_DAY', 'LEAVE')),
            overtime_hours REAL DEFAULT 0.0,
            marked_by TEXT NOT NULL,
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(worker_id, date)
        );
        """)

        # 18. Lot Cost Sheet & Expenses
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS lot_cost_sheets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            lot_id INTEGER UNIQUE NOT NULL REFERENCES lots(id) ON DELETE CASCADE,
            fabric_cost REAL DEFAULT 0.0,
            cutting_cost REAL DEFAULT 0.0,
            stitching_cost REAL DEFAULT 0.0,
            screen_printing_cost REAL DEFAULT 0.0,
            embroidery_cost REAL DEFAULT 0.0,
            washing_cost REAL DEFAULT 0.0,
            gaaj_button_cost REAL DEFAULT 0.0,
            pressing_packing_cost REAL DEFAULT 0.0,
            accessories_cost REAL DEFAULT 0.0,
            miscellaneous_cost REAL DEFAULT 0.0,
            total_lot_cost REAL DEFAULT 0.0,
            cost_per_piece REAL DEFAULT 0.0,
            calculated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 19. Worker and Jobber Payment Records (Khata)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            payee_type TEXT NOT NULL CHECK(payee_type IN ('WORKER', 'JOBBER')),
            worker_id INTEGER REFERENCES workers(id),
            jobber_id INTEGER REFERENCES jobbers(id),
            lot_id INTEGER REFERENCES lots(id),
            amount_due REAL DEFAULT 0.0,
            amount_paid REAL DEFAULT 0.0,
            payment_date DATE,
            payment_mode TEXT DEFAULT 'CASH' CHECK(payment_mode IN ('CASH', 'UPI', 'BANK_TRANSFER', 'CHEQUE')),
            notes TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 20. Finished Goods Inventory & Stock Movements
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS finished_stock (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            design_id INTEGER NOT NULL REFERENCES designs(id),
            lot_id INTEGER REFERENCES lots(id),
            available_pieces INTEGER DEFAULT 0,
            packed_boxes INTEGER DEFAULT 0,
            last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(design_id, lot_id)
        );
        """)

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS stock_movements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            design_id INTEGER NOT NULL REFERENCES designs(id),
            lot_id INTEGER REFERENCES lots(id),
            movement_type TEXT NOT NULL CHECK(movement_type IN ('INWARD_FROM_PRODUCTION', 'OUTWARD_DISPATCH', 'ADJUSTMENT')),
            quantity INTEGER NOT NULL,
            reference_order_id INTEGER REFERENCES orders(id),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 21. Real-time Notifications (Alterations, Shortages, Delays)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS notifications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            target_role TEXT NOT NULL DEFAULT 'OWNER' CHECK(target_role IN ('OWNER', 'WORKER')),
            target_worker_id INTEGER REFERENCES workers(id) ON DELETE CASCADE,
            title TEXT NOT NULL,
            message TEXT NOT NULL,
            notification_type TEXT NOT NULL CHECK(notification_type IN ('ALTERATION', 'NEW_ORDER', 'LOT_DELAY', 'SHORTAGE', 'SYSTEM')),
            reference_id INTEGER,
            is_read BOOLEAN DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 22. Audit Logs & Transaction History
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS audit_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER REFERENCES users(id),
            username TEXT,
            action TEXT NOT NULL,
            table_name TEXT NOT NULL,
            record_id INTEGER NOT NULL,
            old_values TEXT,
            new_values TEXT,
            timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # 23. App Settings
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS app_settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            description TEXT
        );
        """)

        # Indexes for query performance
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_workers_dept ON workers(department_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_workers_jobber ON workers(jobber_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_attendance_worker_date ON attendance(worker_id, date);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_status ON orders(current_status);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_lots_status ON lots(current_status);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_lots_dept ON lots(current_department_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_movements_lot ON lot_movements(lot_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_production_worker ON production_records(worker_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_alterations_worker ON alterations(worker_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_notifications_worker ON notifications(target_worker_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_breaks_prod ON production_breaks(production_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_breaks_worker ON production_breaks(worker_id);")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_breaks_time ON production_breaks(started_at);")

        # Migrate production_records columns if table already existed without them
        cursor.execute("PRAGMA table_info(production_records);")
        cols = {row["name"] for row in cursor.fetchall()}
        new_cols = [
            ("bundles_count", "INTEGER DEFAULT 0"),
            ("bundle_size", "INTEGER DEFAULT 20"),
            ("loose_pieces", "INTEGER DEFAULT 0"),
            ("total_pause_minutes", "INTEGER DEFAULT 0"),
            ("is_paused", "BOOLEAN DEFAULT 0"),
            ("current_pause_start", "TIMESTAMP"),
            ("current_pause_reason", "TEXT")
        ]
        for col_name, col_def in new_cols:
            if col_name not in cols:
                cursor.execute(f"ALTER TABLE production_records ADD COLUMN {col_name} {col_def};")

        # 24. Worker OTPs (Real-time SMS/Phone verification)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS worker_otps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            phone TEXT NOT NULL,
            otp_code TEXT NOT NULL,
            expires_at REAL NOT NULL,
            is_verified BOOLEAN DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_worker_otps_phone ON worker_otps(phone);")

        # 25. Mobile Push Notifications Subscriptions
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS push_subscriptions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            worker_id INTEGER,
            phone TEXT,
            endpoint TEXT UNIQUE NOT NULL,
            p256dh TEXT,
            auth TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # Migrate lot_process_routes for Turnaround Days & Finished Photo
        cursor.execute("PRAGMA table_info(lot_process_routes);")
        route_cols = {row["name"] for row in cursor.fetchall()}
        new_route_cols = [
            ("worker_id", "INTEGER REFERENCES workers(id)"),
            ("turnaround_days", "REAL DEFAULT 0.0"),
            ("sample_photo_url", "TEXT"),
            ("notes", "TEXT")
        ]
        for col_name, col_def in new_route_cols:
            if col_name not in route_cols:
                cursor.execute(f"ALTER TABLE lot_process_routes ADD COLUMN {col_name} {col_def};")

        # 16. Daily Production Logs Table (Floor real-time & 9 PM closing audit)
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS daily_production_logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            log_date DATE NOT NULL,
            lot_id INTEGER REFERENCES lots(id) ON DELETE CASCADE,
            department_id INTEGER REFERENCES departments(id),
            worker_id INTEGER REFERENCES workers(id),
            machine_id INTEGER REFERENCES machines(id),
            activity_type TEXT NOT NULL,
            pieces_today INTEGER DEFAULT 0,
            cumulative_pieces INTEGER DEFAULT 0,
            total_lot_pieces INTEGER DEFAULT 0,
            bundle_size INTEGER DEFAULT 20,
            bundles_count INTEGER DEFAULT 0,
            is_stage_completed BOOLEAN DEFAULT 0,
            title TEXT,
            description TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        );
        """)

        # Migrate lots for Fabric Dealer, Swatches, Remnant meters, Urgent Priority, Bundles & Colors
        cursor.execute("PRAGMA table_info(lots);")
        lot_cols = {row["name"] for row in cursor.fetchall()}
        new_lot_cols = [
            ("dealer_name", "TEXT"),
            ("color_swatches", "TEXT"),
            ("color_breakdown", "TEXT"),
            ("bundle_size", "INTEGER DEFAULT 20"),
            ("bundles_count", "INTEGER DEFAULT 0"),
            ("remnant_fabric_meters", "REAL DEFAULT 0.0"),
            ("sample_shirt_photo_url", "TEXT"),
            ("is_urgent", "BOOLEAN DEFAULT 0"),
            ("due_date", "DATE")
        ]
        for col_name, col_def in new_lot_cols:
            if col_name not in lot_cols:
                cursor.execute(f"ALTER TABLE lots ADD COLUMN {col_name} {col_def};")

        print("Database schema successfully verified and indexed.")


if __name__ == "__main__":
    init_db()
