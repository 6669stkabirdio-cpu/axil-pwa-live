"""
AXIL Factory Management PWA - Pydantic Request/Response Models
"""

from pydantic import BaseModel, Field
from typing import Optional, List
from datetime import date, datetime


# Auth Models
class LoginRequest(BaseModel):
    username: str
    password: str # Can be owner password or worker PIN


class WorkerPinLoginRequest(BaseModel):
    worker_code: str
    pin: str


class WorkerOtpRequest(BaseModel):
    phone: str


class WorkerOtpVerify(BaseModel):
    phone: str
    otp_code: str


class WorkerRegisterRequest(BaseModel):
    full_name: str
    role_designation: str
    phone: str
    password: str
    otp_code: str


class WorkerPhoneLoginRequest(BaseModel):
    phone: str
    password: str


class LotStartRequest(BaseModel):
    lot_id: int
    department_id: Optional[int] = None


class LotPhotoUploadRequest(BaseModel):
    lot_id: int
    photo_base64: str


class LotCompleteTurnaroundRequest(BaseModel):
    lot_id: int
    pieces_completed: Optional[int] = None
    notes: Optional[str] = None


class PushSubscribeRequest(BaseModel):
    endpoint: str
    p256dh: Optional[str] = None
    auth: Optional[str] = None


class LoginResponse(BaseModel):
    token: str
    user_id: int
    username: str
    role: str
    full_name: str
    worker_id: Optional[int] = None
    language_preference: str = "gu"
    role_designation: Optional[str] = None


# Attendance Models
class AttendanceMarkRequest(BaseModel):
    worker_id: int
    date: date
    status: str # PRESENT, ABSENT, HALF_DAY, LEAVE
    overtime_hours: float = 0.0
    notes: Optional[str] = None


# Order Models
class OrderCreateRequest(BaseModel):
    order_number: str
    customer_id: int
    design_id: int
    lot_id: Optional[int] = None
    total_quantity: int
    order_date: date
    delivery_due_date: date
    priority: str = "NORMAL"
    notes: Optional[str] = None


class OrderStatusUpdateRequest(BaseModel):
    status: str
    notes: Optional[str] = None


# Dispatch Models
class DispatchCreateRequest(BaseModel):
    order_id: int
    dispatch_number: str
    dispatched_quantity: int
    parcel_count: int = 1
    transport_name: str
    tracking_lr_number: Optional[str] = None
    dispatch_date: date
    packed_by: Optional[str] = None
    notes: Optional[str] = None


# Fabric Inward Model
class FabricInwardCreateRequest(BaseModel):
    inward_number: str
    supplier_name: str
    challan_number: Optional[str] = None
    fabric_type: str
    color_shade: Optional[str] = None
    rolls_count: int = 1
    meters_received: float
    rate_per_meter: float = 0.0
    inward_date: date
    notes: Optional[str] = None


# Lot Creation (Cutting Master) Model
class LotCreateRequest(BaseModel):
    lot_number: str
    design_id: int
    fabric_inward_id: Optional[int] = None
    meters_consumed: float = 0.0
    cutting_master_worker_id: Optional[int] = None
    cutting_date: date
    total_cut_pieces: int
    target_completion_date: Optional[date] = None
    cutting_rate_per_piece: float = 6.0


# Lot Movement (Department Handover) Model
class LotMovementSendRequest(BaseModel):
    lot_id: int
    from_department_id: int
    to_department_id: int
    sent_by_worker_id: Optional[int] = None
    sent_quantity: int
    notes: Optional[str] = None


class LotMovementConfirmRequest(BaseModel):
    movement_id: int
    received_by_worker_id: int
    received_quantity: int
    shortage_reason: Optional[str] = None
    notes: Optional[str] = None


# Karigar Production Tracking Model
class ProductionStartRequest(BaseModel):
    lot_id: int
    department_id: int
    worker_id: int
    jobber_id: Optional[int] = None
    machine_id: Optional[int] = None
    pieces_assigned: int
    rate_per_piece: float = 45.0


class ProductionCompleteRequest(BaseModel):
    production_id: int
    pieces_completed: int
    pieces_altered: int = 0


class ProductionPauseRequest(BaseModel):
    production_id: int
    break_reason: str


class ProductionResumeRequest(BaseModel):
    production_id: int


class BundleProgressSaveRequest(BaseModel):
    production_id: int
    bundles_count: int
    bundle_size: int = 20
    loose_pieces: int = 0
    pieces_altered: int = 0
    is_completed: bool = False


class SaveAndStopRequest(BaseModel):
    production_id: int
    bundles_count: int = 0
    bundle_size: int = 20
    loose_pieces: int = 0
    pieces_altered: int = 0


class AdvanceStageRequest(BaseModel):
    lot_id: int
    department_id: int
    worker_id: Optional[int] = None
    pieces_completed: Optional[int] = None


# Alteration Logging Model
class AlterationCreateRequest(BaseModel):
    lot_id: int
    department_id: int
    worker_id: int
    alteration_pieces: int
    defect_type: str
    defect_description: Optional[str] = None
    reported_by_worker_id: Optional[int] = None


# Payment Record Model
class PaymentCreateRequest(BaseModel):
    payee_type: str # WORKER or JOBBER
    worker_id: Optional[int] = None
    jobber_id: Optional[int] = None
    lot_id: Optional[int] = None
    amount_paid: float
    payment_date: date
    payment_mode: str = "CASH"
    notes: Optional[str] = None


# Real Factory Worker Models
class WorkerRegisterRequest(BaseModel):
    full_name: str
    role_designation: str
    phone: str
    password: str
    otp_code: Optional[str] = None


class WorkerPhoneLoginRequest(BaseModel):
    phone: str
    password: str


class WorkerOtpRequest(BaseModel):
    phone: str


class WorkerOtpVerify(BaseModel):
    phone: str
    otp_code: str


class LotStartRequest(BaseModel):
    lot_id: int


class LotPhotoUploadRequest(BaseModel):
    photo_base64: str


class LotCompleteTurnaroundRequest(BaseModel):
    pieces_completed: Optional[int] = None
    notes: Optional[str] = None


class CuttingMasterLotCreateRequest(BaseModel):
    dealer_name: str
    fabric_type: str
    meters_received: float
    design_id: int
    lot_number: str
    total_cut_pieces: int
    remnant_fabric_meters: float = 0.0
    color_swatches: Optional[str] = None
    is_urgent: bool = False
    due_date: Optional[str] = None
    target_stages: Optional[List[int]] = None  # e.g. [2, 3, 6, 7, 8]


class PushSubscribeRequest(BaseModel):
    endpoint: str
    p256dh: Optional[str] = None
    auth: Optional[str] = None
