"""
AXIL Authentication and Authorization Module
Implements secure PBKDF2-SHA256 password/PIN hashing and token session management.
Enforces role-based permissions (OWNER vs WORKER) on the backend.
"""

import hashlib
import os
import secrets
import time
from typing import Optional, Dict, Any
from fastapi import HTTPException, Security, status, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials

SECRET_KEY = os.getenv("AXIL_SECRET_KEY", "axil-factory-super-secret-key-2026-production")
SALT = b"axil_factory_secure_salt_garment_pwa"

# In-memory active session token store (token -> session_data)
# Also allows persistent verification via database
ACTIVE_SESSIONS: Dict[str, Dict[str, Any]] = {}

security_bearer = HTTPBearer(auto_error=False)


def hash_password(password: str) -> str:
    """Hashes a password or numeric PIN using PBKDF2-HMAC-SHA256."""
    hash_bytes = hashlib.pbkdf2_hmac(
        'sha256',
        password.encode('utf-8'),
        SALT,
        iterations=100000
    )
    return hash_bytes.hex()


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verifies a plain password or PIN against its PBKDF2 hash."""
    return hash_password(plain_password) == hashed_password


def ensure_sessions_table():
    """Ensures user_sessions table exists in SQLite database."""
    from database import get_db
    with get_db() as conn:
        conn.execute("""
        CREATE TABLE IF NOT EXISTS user_sessions (
            token TEXT PRIMARY KEY,
            user_id INTEGER NOT NULL,
            username TEXT NOT NULL,
            role TEXT NOT NULL,
            full_name TEXT NOT NULL,
            worker_id INTEGER,
            created_at REAL NOT NULL,
            expires_at REAL NOT NULL
        );
        """)
        conn.execute("CREATE INDEX IF NOT EXISTS idx_user_sessions_token ON user_sessions(token);")


def create_session(user_id: int, username: str, role: str, full_name: str, worker_id: Optional[int] = None) -> str:
    """Generates a secure random session token and persists user info in SQLite + memory cache."""
    token = secrets.token_urlsafe(32)
    now = time.time()
    # 365-day persistent session for factory floor workers; 30-day for owner
    duration_days = 365 if role == "WORKER" else 30
    expires = now + (86400 * duration_days)
    
    session_data = {
        "user_id": user_id,
        "username": username,
        "role": role,
        "full_name": full_name,
        "worker_id": worker_id,
        "created_at": now,
        "expires_at": expires
    }
    ACTIVE_SESSIONS[token] = session_data

    # Persist session to SQLite so server reloads/restarts never kick workers out
    try:
        from database import get_db
        ensure_sessions_table()
        with get_db() as conn:
            conn.execute("""
            INSERT OR REPLACE INTO user_sessions
            (token, user_id, username, role, full_name, worker_id, created_at, expires_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?);
            """, (token, user_id, username, role, full_name, worker_id, now, expires))
    except Exception as e:
        print(f"Warning: Failed to persist session to database: {e}")

    return token


def delete_session(token: str):
    """Deletes session from memory and SQLite database."""
    ACTIVE_SESSIONS.pop(token, None)
    try:
        from database import get_db
        with get_db() as conn:
            conn.execute("DELETE FROM user_sessions WHERE token = ?;", (token,))
    except Exception as e:
        print(f"Warning: Failed to delete session: {e}")


def get_current_user(credentials: Optional[HTTPAuthorizationCredentials] = Security(security_bearer)) -> Dict[str, Any]:
    """Extracts and validates the current session token from memory or SQLite."""
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required. Please log in.",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    token = credentials.credentials
    now = time.time()
    session = ACTIVE_SESSIONS.get(token)

    if session and session["expires_at"] >= now:
        return session

    # Check persistent SQLite store if not in memory (e.g. after server reload/restart)
    try:
        from database import get_db
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM user_sessions WHERE token = ?;", (token,))
            row = cursor.fetchone()
            if row:
                if row["expires_at"] >= now:
                    restored_session = {
                        "user_id": row["user_id"],
                        "username": row["username"],
                        "role": row["role"],
                        "full_name": row["full_name"],
                        "worker_id": row["worker_id"],
                        "created_at": row["created_at"],
                        "expires_at": row["expires_at"]
                    }
                    ACTIVE_SESSIONS[token] = restored_session
                    return restored_session
                else:
                    cursor.execute("DELETE FROM user_sessions WHERE token = ?;", (token,))
    except Exception as e:
        print(f"Warning: Session lookup from database failed: {e}")

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Session expired or invalid. Please log in again.",
        headers={"WWW-Authenticate": "Bearer"},
    )


def require_owner(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    """Enforces that only OWNER/Admin role can access sensitive financial and admin endpoints."""
    if current_user.get("role") != "OWNER":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access forbidden: Owner/Admin privileges required for this action."
        )
    return current_user


def require_worker_or_owner(current_user: Dict[str, Any] = Depends(get_current_user)) -> Dict[str, Any]:
    """Allows either worker (scoped to their own records) or owner."""
    return current_user


def get_current_user_optional(credentials: Optional[HTTPAuthorizationCredentials] = Security(security_bearer)) -> Optional[Dict[str, Any]]:
    """Returns current user session if bearer token provided, else None without raising 401."""
    if not credentials:
        return None
    try:
        return get_current_user(credentials)
    except HTTPException:
        return None
