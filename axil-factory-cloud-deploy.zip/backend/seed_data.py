"""
AXIL Factory Management PWA - Master Data Seeder
Populates initial factory data according to real wholesale shirt manufacturing operations:
- Master Lists (Cutting, Stitching, Printing, Washing, Gaaj-Button, Press-Packing, Godown)
- Jobbers & Machines
- Karigars & Master Cutters with PINs
- Owner & Worker user accounts
- Standard Designs & Fabric Inward
- Active Lots with stage routes
- Sample Orders & Dispatches
- Real-time Notifications & Initial Lot Cost Sheets
"""

import datetime
from database import get_db, init_db
from auth import hash_password


def seed_all():
    init_db()
    
    with get_db() as conn:
        cursor = conn.cursor()

        # 1. Seed Departments if empty
        cursor.execute("SELECT COUNT(*) FROM departments;")
        if cursor.fetchone()[0] == 0:
            departments = [
                ("DEPT_FABRIC", "Fabric Godown", "फैब्रिक गोडाउन", "કાપડ ગોડાઉન", 1, 0),
                ("DEPT_CUT", "Cutting Master", "कटिंग मास्टर", "કટીંગ માસ્ટર", 2, 1),
                ("DEPT_STITCH", "Stitching & Jobwork", "सिलाई (स्टिचिंग)", "સિલઇ (સ્ટીચીંગ)", 3, 1),
                ("DEPT_PRINT", "Screen Printing", "स्क्रीन प्रिंटिंग", "સ્ક્રીન પ્રિન્ટીંગ", 4, 1),
                ("DEPT_EMB", "Embroidery", "एम्ब्रॉयडरी", "એમ્બ્રોઈડરી", 5, 1),
                ("DEPT_WASH", "Washing", "वॉशिंग", "વોશિંગ", 6, 1),
                ("DEPT_GAAJ", "Gaaj-Button", "काज-बटन", "ગાજ-બટન", 7, 1),
                ("DEPT_PACK", "Press & Packing", "प्रेस एवं पैकिंग", "પ્રેસ અને પેકિંગ", 8, 1),
                ("DEPT_GODOWN", "Finished Godown", "फिनिश्ड गोडाउन", "ફિનિશ્ડ ગોડાઉન", 9, 0),
            ]
            cursor.executemany("""
                INSERT INTO departments (code, name, name_hi, name_gu, sequence_order, is_production)
                VALUES (?, ?, ?, ?, ?, ?);
            """, departments)
            print("Departments seeded.")

        # 2. Seed Jobbers safely
        jobbers = [
            ("Ramesh Bhai Jobwork", "+91 98250 11223", "Plot 42, GIDC Sachin, Surat", 45.0),
            ("Bhavani Garments Work", "+91 98980 44556", "Shed 18, Narol Textile Park, Ahmedabad", 48.0)
        ]
        for name, phone, addr, rate in jobbers:
            cursor.execute("SELECT id FROM jobbers WHERE name = ?;", (name,))
            if not cursor.fetchone():
                cursor.execute("""
                    INSERT INTO jobbers (name, phone, workshop_address, stitching_rate_default)
                    VALUES (?, ?, ?, ?);
                """, (name, phone, addr, rate))
        print("Jobbers ensured.")

        # 3. Seed Machines safely
        cursor.execute("SELECT id FROM jobbers ORDER BY id ASC LIMIT 1;")
        j1 = cursor.fetchone()
        j1_id = j1[0] if j1 else 1

        cursor.execute("SELECT COUNT(*) FROM machines;")
        if cursor.fetchone()[0] == 0:
            machines = []
            for i in range(1, 16):
                m_type = "Single Needle Juki DDL" if i <= 10 else ("Overlock 5-Thread" if i <= 13 else "Feed-Off-Arm")
                machines.append((f"M-01-{i:02d}", j1_id, m_type, "ACTIVE"))
            for i in range(1, 11):
                machines.append((f"M-02-{i:02d}", j1_id, "Single Needle Brother", "ACTIVE"))
            cursor.executemany("""
                INSERT OR IGNORE INTO machines (machine_code, jobber_id, machine_type, status)
                VALUES (?, ?, ?, ?);
            """, machines)
        print("Machines ensured.")

        # 4. Seed Workers safely
        pin_1234 = hash_password("1234")
        workers_to_ensure = [
            ("CUT-01", "Kanti Bhai Master", "9876500001", 2, None, None, "Cutting Master", 6.0, 800.0, pin_1234, "gu"),
            ("KAR-101", "Dinesh Kumar", "9876500101", 3, j1_id, 1, "Stitcher / Sewer (Karigar)", 45.0, 0.0, pin_1234, "hi"),
            ("KAR-102", "Suresh Prajapati", "9876500102", 3, j1_id, 2, "Stitcher / Sewer (Karigar)", 45.0, 0.0, pin_1234, "gu"),
            ("WSH-01", "Mukesh Bhai Washer", "9876500301", 6, None, None, "Washer", 5.0, 600.0, pin_1234, "gu"),
            ("WSH-02", "Kantilal Dhobi", "9876500302", 6, None, None, "Washer", 5.0, 600.0, pin_1234, "gu"),
            ("GAJ-01", "Ashok Bhai Gaaj", "9876500401", 7, None, None, "Gaaj-Button Operator", 4.0, 600.0, pin_1234, "gu"),
            ("PCK-01", "Vinod Bhai Press", "9876500501", 8, None, None, "Press & Packing Master", 7.0, 650.0, pin_1234, "gu"),
            ("JOB-01", "Babu Bhai Contractor", "9876500601", 3, j1_id, None, "Jobber", 45.0, 0.0, pin_1234, "gu"),
            ("PRN-01", "Irfan Bhai Printer", "9876500701", 4, None, None, "Screen Printing", 8.0, 650.0, pin_1234, "gu"),
            ("EMB-01", "Farooq Bhai Embroidery", "9876500801", 5, None, None, "Embroidery", 12.0, 700.0, pin_1234, "gu"),
        ]
        for w_code, w_name, w_phone, d_id, j_id, m_id, r_des, r_pc, d_wage, p_hash, lang in workers_to_ensure:
            cursor.execute("SELECT id FROM workers WHERE phone = ? OR worker_code = ?;", (w_phone, w_code))
            if not cursor.fetchone():
                cursor.execute("""
                    INSERT INTO workers (worker_code, full_name, phone, department_id, jobber_id, machine_id, role_designation, rate_per_piece, daily_wage, pin_hash, language_preference)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                """, (w_code, w_name, w_phone, d_id, j_id, m_id, r_des, r_pc, d_wage, p_hash, lang))
        print("Workers ensured.")

        # 5. Seed Users safely without foreign key constraint violations
        owner_pwd = hash_password("axil@2026")
        worker_pwd = hash_password("1234")
        
        cursor.execute("SELECT id FROM users WHERE username = 'admin';")
        if not cursor.fetchone():
            cursor.execute("""
                INSERT INTO users (username, password_hash, role, worker_id, full_name)
                VALUES ('admin', ?, 'OWNER', NULL, 'Factory Owner / Admin');
            """, (owner_pwd,))

        cursor.execute("SELECT id, phone, full_name FROM workers WHERE phone IS NOT NULL;")
        for w_id, w_phone, w_name in cursor.fetchall():
            clean_u = w_phone.strip().replace(" ", "").replace("-", "").replace("+91", "")
            cursor.execute("SELECT id FROM users WHERE username = ?;", (clean_u,))
            if not cursor.fetchone():
                cursor.execute("""
                    INSERT INTO users (username, password_hash, role, worker_id, full_name)
                    VALUES (?, ?, 'WORKER', ?, ?);
                """, (clean_u, worker_pwd, w_id, w_name))
        print("Users ensured safely.")

        # 6. Seed Designs
        cursor.execute("SELECT COUNT(*) FROM designs;")
        if cursor.fetchone()[0] == 0:
            designs = [
                (
                    "AX-101", "Royal Oxford Solid Formal Shirt", "100% Giza Oxford Cotton",
                    "Spread Collar", "Full Sleeve", 0, 0,
                    6.0, 45.0, 0.0, 0.0, 5.0, 4.0, 7.0,
                    "Classic executive formal shirt in premium oxford weave"
                ),
                (
                    "AX-102", "Urban Micro-Check Casual Shirt", "Cotton Twill Checks",
                    "Button-down Collar", "Half Sleeve", 0, 1,
                    6.0, 45.0, 8.0, 0.0, 5.0, 4.0, 7.0,
                    "Youth casual micro-check with contrast screen print on inner yoke"
                ),
                (
                    "AX-103", "Luxury Pure Linen Resort Shirt", "100% French Pure Linen",
                    "Mandarin Collar", "Full Sleeve", 1, 0,
                    8.0, 55.0, 0.0, 12.0, 6.0, 5.0, 8.0,
                    "High-end resort linen shirt with pocket crest embroidery"
                )
            ]
            cursor.executemany("""
                INSERT INTO designs (
                    design_number, name, fabric_type, collar_style, sleeve_type,
                    has_embroidery, has_screen_print, standard_cutting_rate,
                    standard_stitching_rate, standard_screen_rate, standard_embroidery_rate,
                    standard_washing_rate, standard_gaaj_button_rate, standard_press_packing_rate,
                    notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """, designs)
            print("Designs seeded.")

        # 7. Seed Fabric Inward
        cursor.execute("SELECT COUNT(*) FROM fabric_inward;")
        if cursor.fetchone()[0] == 0:
            fabrics = [
                (
                    "FAB-IN-001", "Arvind Mills Ltd, Ahmedabad", "CH-9941",
                    "100% Giza Oxford (White)", "Optic White", 12, 2400.0, 140.0,
                    336000.0, 1200.0, 1200.0, str(datetime.date.today() - datetime.timedelta(days=10)),
                    "First lot of premium Oxford rolls for AX-101"
                ),
                (
                    "FAB-IN-002", "Raymond Luxury Cottons, Vapi", "CH-8820",
                    "Cotton Twill (Navy Micro Check)", "Navy / Light Blue", 10, 1800.0, 165.0,
                    297000.0, 800.0, 1000.0, str(datetime.date.today() - datetime.timedelta(days=7)),
                    "Yarn dyed checks for AX-102"
                )
            ]
            cursor.executemany("""
                INSERT INTO fabric_inward (
                    inward_number, supplier_name, challan_number, fabric_type,
                    color_shade, rolls_count, meters_received, rate_per_meter,
                    total_fabric_cost, meters_used, remaining_meters, inward_date, notes
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """, fabrics)
            print("Fabric Inward seeded.")

        # 8. Seed Lots
        cursor.execute("SELECT COUNT(*) FROM lots;")
        if cursor.fetchone()[0] == 0:
            today = datetime.date.today()
            lots = [
                # Lot 1: In Stitching with Ramesh Bhai Jobwork
                (
                    "LOT-2024-001", 1, 1, 1200.0, 1, str(today - datetime.timedelta(days=5)),
                    1200, 3, "STITCHING", 0, None, 6.0, 7200.0,
                    str(today + datetime.timedelta(days=3))
                ),
                # Lot 2: In Washing
                (
                    "LOT-2024-002", 2, 2, 800.0, 1, str(today - datetime.timedelta(days=6)),
                    800, 6, "WASHING", 0, None, 6.0, 4800.0,
                    str(today + datetime.timedelta(days=2))
                ),
                # Lot 3: Press & Packing
                (
                    "LOT-2024-003", 1, 1, 600.0, 1, str(today - datetime.timedelta(days=8)),
                    600, 8, "PRESS_PACKING", 0, None, 6.0, 3600.0,
                    str(today + datetime.timedelta(days=1))
                )
            ]
            cursor.executemany("""
                INSERT INTO lots (
                    lot_number, design_id, fabric_inward_id, meters_consumed,
                    cutting_master_worker_id, cutting_date, total_cut_pieces,
                    current_department_id, current_status, is_delayed, delay_reason,
                    cutting_rate_per_piece, cutting_total_cost, target_completion_date
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """, lots)
            print("Lots seeded.")

            # Seed Process Routes for Lots
            # Lot 1: Cutting(2) -> Stitching(3) -> Washing(6) -> Gaaj(7) -> Press(8) -> Godown(9)
            route_lot1 = [
                (1, 1, 2, 'COMPLETED'),
                (1, 2, 3, 'IN_PROGRESS'),
                (1, 3, 6, 'PENDING'),
                (1, 4, 7, 'PENDING'),
                (1, 5, 8, 'PENDING'),
                (1, 6, 9, 'PENDING'),
            ]
            # Lot 2 (has Screen Print): Cutting(2) -> Stitching(3) -> Screen(4) -> Washing(6) -> Gaaj(7) -> Press(8) -> Godown(9)
            route_lot2 = [
                (2, 1, 2, 'COMPLETED'),
                (2, 2, 3, 'COMPLETED'),
                (2, 3, 4, 'COMPLETED'),
                (2, 4, 6, 'IN_PROGRESS'),
                (2, 5, 7, 'PENDING'),
                (2, 6, 8, 'PENDING'),
                (2, 7, 9, 'PENDING'),
            ]
            cursor.executemany("""
                INSERT INTO lot_process_routes (lot_id, stage_sequence, department_id, status)
                VALUES (?, ?, ?, ?);
            """, route_lot1 + route_lot2)
            print("Lot Process Routes seeded.")

        # 9. Seed Karigar Production Records (Demonstrates speed & pieces calculation)
        cursor.execute("SELECT COUNT(*) FROM production_records;")
        if cursor.fetchone()[0] == 0:
            now = datetime.datetime.now()
            start_time_dinesh = now - datetime.timedelta(hours=4)
            comp_time_dinesh = now - datetime.timedelta(minutes=30)
            
            # Dinesh did 180 pcs in 210 minutes = ~51.4 pcs/hr
            prod_records = [
                (
                    1, 3, 1, 1, 2, 200, 180, 2, 45.0, 180 * 45.0,
                    str(start_time_dinesh), str(comp_time_dinesh), 210, 51.4, "COMPLETED"
                ),
                (
                    1, 3, 1, 2, 3, 200, 160, 4, 45.0, 160 * 45.0,
                    str(start_time_dinesh), str(comp_time_dinesh), 210, 45.7, "COMPLETED"
                ),
                (
                    1, 3, 1, 3, 4, 200, 120, 1, 45.0, 120 * 45.0,
                    str(start_time_dinesh), None, 0, 0.0, "IN_PROGRESS"
                )
            ]
            cursor.executemany("""
                INSERT INTO production_records (
                    lot_id, department_id, jobber_id, machine_id, worker_id,
                    pieces_assigned, pieces_completed, pieces_altered, rate_per_piece,
                    total_earned, start_time, complete_time, total_duration_minutes,
                    production_speed_pcs_per_hr, status
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """, prod_records)
            print("Production records seeded.")

        # 10. Seed Alterations
        cursor.execute("SELECT COUNT(*) FROM alterations;")
        if cursor.fetchone()[0] == 0:
            alterations = [
                (
                    1, 3, 3, 4, "Stitching defect",
                    "Collar attachment puckering on left point - redo stitch",
                    "PENDING", 0, None, 1, 1
                ),
                (
                    1, 3, 2, 2, "Tension loose",
                    "Bottom hem stitch loose tension threads",
                    "RECTIFIED", 2, str(datetime.datetime.now()), 1, 1
                )
            ]
            cursor.executemany("""
                INSERT INTO alterations (
                    lot_id, department_id, worker_id, alteration_pieces, defect_type,
                    defect_description, status, rectified_pieces, rectified_at,
                    reported_by_worker_id, notification_sent
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """, alterations)
            print("Alterations seeded.")

        # 11. Seed Handover & Shortage Spotting safely
        cursor.execute("SELECT COUNT(*) FROM lot_movements;")
        if cursor.fetchone()[0] == 0:
            try:
                cursor.execute("SELECT id FROM lots LIMIT 2;")
                lot_rows = [r[0] for r in cursor.fetchall()]
                cursor.execute("SELECT id FROM workers LIMIT 2;")
                worker_rows = [r[0] for r in cursor.fetchall()]
                if lot_rows and worker_rows:
                    w1 = worker_rows[0]
                    w2 = worker_rows[1] if len(worker_rows) > 1 else w1
                    l1 = lot_rows[0]
                    cursor.execute("""
                        INSERT OR IGNORE INTO lot_movements (
                            movement_number, lot_id, from_department_id, to_department_id,
                            sent_by_worker_id, sent_quantity, received_by_worker_id,
                            received_quantity, shortage_quantity, shortage_reason, is_confirmed
                        ) VALUES ('MOV-0001', ?, 2, 3, ?, 500, ?, 500, 0, 'All pieces verified at intake', 1);
                    """, (l1, w1, w2))
                    print("Lot movements seeded safely.")
            except Exception as e:
                print(f"Skipping lot movements: {e}")

        # 12. Seed Lot Cost Sheet
        cursor.execute("SELECT COUNT(*) FROM lot_cost_sheets;")
        if cursor.fetchone()[0] == 0:
            # Lot 1: 1200 pcs
            # Fabric: 1200m * 140 = 168000
            # Cutting: 1200 * 6 = 7200
            # Stitching: 1200 * 45 = 54000
            # Washing: 1200 * 5 = 6000
            # Gaaj-Button: 1200 * 4 = 4800
            # Press-Pack: 1200 * 7 = 8400
            # Accessories: 1200 * 12 = 14400
            # Total: 262,800 -> Cost per piece: 219.00
            cursor.execute("""
                INSERT INTO lot_cost_sheets (
                    lot_id, fabric_cost, cutting_cost, stitching_cost,
                    screen_printing_cost, embroidery_cost, washing_cost,
                    gaaj_button_cost, pressing_packing_cost, accessories_cost,
                    miscellaneous_cost, total_lot_cost, cost_per_piece
                ) VALUES (
                    1, 168000.0, 7200.0, 54000.0, 0.0, 0.0, 6000.0,
                    4800.0, 8400.0, 14400.0, 2000.0, 264800.0, 220.67
                );
            """)
            print("Lot Cost Sheet seeded.")

        # 13. Seed Customers & Orders
        cursor.execute("SELECT COUNT(*) FROM customers;")
        if cursor.fetchone()[0] == 0:
            customers = [
                ("Metro Garments", "Metro Menswear", "+91 98200 45678", "Surat", "24AABCM1234D1Z5", "Shop 12, Millenium Market, Ring Road"),
                ("Royal Menswear", "Royal Collection", "+91 98199 87654", "Mumbai", "27AAACR9876E1Z2", "45 Dadar TT Circle, Mumbai"),
                ("Gujarat Garment Hub", "Shree Ram Textiles", "+91 94260 33445", "Ahmedabad", "24AAACG5544F1Z8", "Maskati Market, Ahmedabad")
            ]
            cursor.executemany("""
                INSERT INTO customers (customer_name, shop_name, phone, city, gst_number, address)
                VALUES (?, ?, ?, ?, ?, ?);
            """, customers)
            print("Customers seeded.")

        cursor.execute("SELECT COUNT(*) FROM orders;")
        if cursor.fetchone()[0] == 0:
            try:
                today = datetime.date.today()
                cursor.execute("SELECT id FROM lots LIMIT 1;")
                lot_row = cursor.fetchone()
                cursor.execute("SELECT id FROM customers LIMIT 1;")
                cust_row = cursor.fetchone()
                cursor.execute("SELECT id FROM designs LIMIT 1;")
                des_row = cursor.fetchone()
                if lot_row and cust_row and des_row:
                    cursor.execute("""
                        INSERT OR IGNORE INTO orders (order_number, customer_id, design_id, lot_id, total_quantity, order_date, delivery_due_date, current_status, priority, notes)
                        VALUES ('ORD-2024-001', ?, ?, ?, 600, ?, ?, 'IN_PROCESS', 'URGENT', 'Packed in 10-pc master boxes');
                    """, (cust_row[0], des_row[0], lot_row[0], str(today - datetime.timedelta(days=4)), str(today + datetime.timedelta(days=4))))
                    print("Orders seeded safely.")
            except Exception as e:
                print(f"Skipping orders seed: {e}")

        # 14. Seed Full Monthly Attendance for all Karigars
        cursor.execute("SELECT COUNT(*) FROM attendance;")
        if cursor.fetchone()[0] < 50:
            cursor.execute("SELECT id, worker_code FROM workers WHERE is_active = 1;")
            active_workers = cursor.fetchall()
            sundays = {1, 8, 15, 22}
            monthly_att = []
            
            for day in range(1, 26):
                if day in sundays:
                    continue
                date_str = f"2026-11-{day:02d}"
                for w in active_workers:
                    w_id, code = w[0], w[1]
                    status = "PRESENT"
                    ot = 0.0
                    notes = "On-time"
                    if code == "CUT-01" and day == 14:
                        status, notes = "HALF_DAY", "Left at 1:30 PM (Family function)"
                    elif code == "CUT-01" and day in (3, 9, 16, 23):
                        ot, notes = 2.0, "Evening overtime fabric cutting"
                    elif code == "KAR-101" and day == 18:
                        status, notes = "ABSENT", "Informed medical leave"
                    elif code == "KAR-101" and day == 10:
                        status, notes = "HALF_DAY", "Half day permission"
                    elif code == "KAR-101" and day in (4, 11, 17, 24, 25):
                        ot, notes = 2.0, "Lot rush stitching overtime"
                    elif code == "KAR-102" and day == 12:
                        status, notes = "ABSENT", "Personal leave"
                    elif code == "KAR-102" and day in (7, 25):
                        status, notes = "HALF_DAY", "Left at 2 PM"
                    elif code == "KAR-103" and day == 19:
                        status, notes = "ABSENT", "Sick leave"
                    elif code == "PRN-01" and day == 6:
                        status, notes = "ABSENT", "Leave"
                    elif code == "GAJ-01" and day == 17:
                        status, notes = "ABSENT", "Leave"
                    elif code == "PCK-01" and day in (3, 10, 16, 23, 25):
                        ot, notes = 2.0, "Overtime pressing packing dispatch"
                    monthly_att.append((w_id, date_str, status, ot, "Factory Owner / Admin", notes))

            cursor.executemany("""
                INSERT INTO attendance (worker_id, date, status, overtime_hours, marked_by, notes)
                VALUES (?, ?, ?, ?, ?, ?)
                ON CONFLICT(worker_id, date) DO UPDATE SET
                    status = excluded.status,
                    overtime_hours = excluded.overtime_hours,
                    notes = excluded.notes;
            """, monthly_att)
            print(f"Full Monthly Attendance seeded ({len(monthly_att)} records).")

        # 15. Seed Notifications
        cursor.execute("SELECT COUNT(*) FROM notifications;")
        if cursor.fetchone()[0] == 0:
            notifs = [
                ("WORKER", 3, "Alteration Alert: Lot LOT-2024-001", "4 pieces collar puckering defect on machine M-02. Please rectify urgently.", "ALTERATION", 1),
                ("OWNER", None, "Shortage Alert: Lot LOT-2024-002", "4 pieces short during Stitching -> Washing handover. Sent 800, received 796.", "SHORTAGE", 2),
                ("OWNER", None, "Urgent Order Alert: ORD-2024-001", "Order delivery in 4 days. Lot LOT-2024-001 is currently in stitching.", "LOT_DELAY", 1)
            ]
            cursor.executemany("""
                INSERT INTO notifications (target_role, target_worker_id, title, message, notification_type, reference_id)
                VALUES (?, ?, ?, ?, ?, ?);
            """, notifs)
            print("Notifications seeded.")

        # 16. Seed Day-by-Day Production Logs & Turnaround Tracking
        cursor.execute("SELECT COUNT(*) FROM daily_production_logs;")
        if cursor.fetchone()[0] == 0:
            today_date = datetime.date.today()
            day1_str = str(today_date - datetime.timedelta(days=2))
            day2_str = str(today_date - datetime.timedelta(days=1))
            day3_str = str(today_date)

            # Update Lot 1 and production record 1 to reflect exact 3 days turnaround
            cursor.execute("""
                UPDATE lots
                SET cutting_date = ?,
                    completed_at = ? || ' 17:30:00'
                WHERE id = 1;
            """, (day1_str, day3_str))

            cursor.execute("""
                UPDATE production_records
                SET bundles_count = 9,
                    bundle_size = 20,
                    loose_pieces = 0,
                    pieces_completed = 450,
                    status = 'COMPLETED',
                    start_time = ? || ' 09:00:00',
                    complete_time = ? || ' 17:30:00'
                WHERE worker_id = 2;
            """, (day1_str, day3_str))

            daily_logs_data = [
                # Dinesh Kumar (worker_id 2) on Lot 1: took 3 days to complete 450 pcs
                (day1_str, 1, 3, 2, 1, 'STITCHING_PROGRESS', 150, 150, 450, 20, 7, 0,
                 'Day 1 Stitching Progress: Lot LOT-2026-001',
                 'Dinesh Kumar completed 150 pcs on Day 1 (7 bundles of 20 shirts).'),
                (day2_str, 1, 3, 2, 1, 'STITCHING_PROGRESS', 180, 330, 450, 20, 9, 0,
                 'Day 2 Stitching Progress: Lot LOT-2026-001',
                 'Dinesh Kumar completed 180 pcs on Day 2 (9 bundles of 20 shirts). Total so far: 330 pcs.'),
                (day3_str, 1, 3, 2, 1, 'STITCHING_PROGRESS', 120, 450, 450, 20, 6, 1,
                 'Day 3 Final Stitching & Lot Completed: Lot LOT-2026-001',
                 'Dinesh Kumar completed final 120 pcs. Lot completed in 3 Days (Total 450 pcs)!'),

                # Suresh Prajapati (worker_id 3) on Lot 1: in progress Day 2
                (day2_str, 1, 3, 3, 2, 'STITCHING_PROGRESS', 100, 100, 200, 20, 5, 0,
                 'Day 1 Stitching: Suresh Prajapati',
                 'Suresh Prajapati completed 100 pcs on Day 1.'),
                (day3_str, 1, 3, 3, 2, 'STITCHING_PROGRESS', 60, 160, 200, 20, 3, 0,
                 'Day 2 Stitching: Suresh Prajapati',
                 'Suresh Prajapati completed 60 pcs today. In progress (160/200 pcs).')
            ]

            cursor.executemany("""
                INSERT INTO daily_production_logs (
                    log_date, lot_id, department_id, worker_id, machine_id, activity_type,
                    pieces_today, cumulative_pieces, total_lot_pieces, bundle_size, bundles_count,
                    is_stage_completed, title, description
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """, daily_logs_data)
            print("Daily production logs seeded successfully (Day-by-Day tracking).")

        print("=== Complete AXIL master database seeded successfully ===")


if __name__ == "__main__":
    seed_all()
