﻿"""
AXIL Database Backup & Disaster Recovery Utility
Creates timestamped hot-backups of the SQLite database using SQLite's native backup API.
"""

import sqlite3
import os
import shutil
import datetime

BACKUP_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "backups")
DB_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data", "axil_factory.db")

os.makedirs(BACKUP_DIR, exist_ok=True)


def create_backup() -> str:
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_file = os.path.join(BACKUP_DIR, f"axil_backup_{timestamp}.db")
    
    # Use SQLite native backup API for safe, non-blocking hot backup
    src_conn = sqlite3.connect(DB_PATH)
    dst_conn = sqlite3.connect(backup_file)
    
    with dst_conn:
        src_conn.backup(dst_conn, pages=100)
        
    src_conn.close()
    dst_conn.close()
    
    file_size_kb = os.path.getsize(backup_file) / 1024
    print(f"[OK] Database backup created: {backup_file} ({file_size_kb:.1f} KB)")
    return backup_file


if __name__ == "__main__":
    create_backup()
