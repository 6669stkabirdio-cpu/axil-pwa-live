// AXIL PWA Service Worker
const CACHE_NAME = 'axil-pwa-v4';
const ASSETS_TO_CACHE = [
  '/',
  '/index.html',
  '/worker.html',
  '/css/styles.css',
  '/js/i18n.js',
  '/js/api.js',
  '/js/app.js',
  '/js/worker.js',
  '/assets/logo.jpg',
  '/manifest.json'
];

self.addEventListener('install', (e) => {
  e.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(ASSETS_TO_CACHE).catch((err) => console.log('Cache add error', err));
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((k) => {
          if (k !== CACHE_NAME) return caches.delete(k);
        })
      );
    })
  );
  self.clients.claim();
});

self.addEventListener('fetch', (e) => {
  // Pass API requests directly to network
  if (e.request.url.includes('/api/')) {
    e.respondWith(fetch(e.request));
    return;
  }

  // Network first with cache fallback for UI
  e.respondWith(
    fetch(e.request)
      .then((response) => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(e.request, copy));
        return response;
      })
      .catch(() => caches.match(e.request))
  );
});

// WEB PUSH & LOCKSCREEN NOTIFICATIONS (LIKE WHATSAPP)
self.addEventListener('push', (event) => {
  let data = {
    title: 'AXIL Factory',
    body: 'New factory task or urgent lot assigned!',
    icon: '/assets/logo.png',
    tag: 'axil-task-alert'
  };

  if (event.data) {
    try {
      data = { ...data, ...event.data.json() };
    } catch (e) {
      data.body = event.data.text();
    }
  }

  const options = {
    body: data.body,
    icon: data.icon || '/assets/logo.png',
    badge: '/assets/logo.png',
    vibrate: [200, 100, 200, 100, 200],
    tag: data.tag || 'axil-notification',
    renotify: true,
    requireInteraction: true,
    data: data.url || '/worker.html'
  };

  event.waitUntil(
    self.registration.showNotification(data.title, options)
  );
});

self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  const targetUrl = event.notification.data || '/worker.html';

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((windowClients) => {
      for (let client of windowClients) {
        if (client.url.includes('worker.html') && 'focus' in client) {
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow(targetUrl);
      }
    })
  );
});
