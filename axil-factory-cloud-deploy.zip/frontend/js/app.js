
function getLocalizedActivityTitle(act) {
  const lotNum = act.lot_number ? `Lot ${act.lot_number}` : '';
  const pcs = act.pieces_today || act.total_lot_pieces || 0;
  const pcsStr = pcs > 0 ? (currentLanguage === 'en' ? `(${pcs} pcs)` : currentLanguage === 'hi' ? `(${pcs} पीस)` : `(${pcs} પીસ)`) : '';
  const type = act.activity_type || '';

  if (type.includes('CUTTING')) {
    if (currentLanguage === 'en') return `✂️ Cutting Completed: ${lotNum} ${pcsStr}`;
    if (currentLanguage === 'hi') return `✂️ कटिंग पूर्ण: ${lotNum} ${pcsStr}`;
    return `✂️ કટીંગ પૂર્ણ: ${lotNum} ${pcsStr}`;
  }
  if (type.includes('PHOTO')) {
    if (currentLanguage === 'en') return `📸 Sample Shirt Photo Uploaded: ${lotNum}`;
    if (currentLanguage === 'hi') return `📸 सैंपल शर्ट फोटो अपलोड: ${lotNum}`;
    return `📸 સેમ્પલ શર્ટ ફોટો અપલોડ: ${lotNum}`;
  }
  if (type.includes('STITCH')) {
    if (currentLanguage === 'en') return `🪡 Stitching Progress: ${lotNum} ${pcsStr}`;
    if (currentLanguage === 'hi') return `🪡 सिलाई प्रगति: ${lotNum} ${pcsStr}`;
    return `🪡 સિલાઈ પ્રગતિ: ${lotNum} ${pcsStr}`;
  }
  if (type.includes('WASH')) {
    if (currentLanguage === 'en') return `🧼 Washing Queue: ${lotNum} ${pcsStr}`;
    if (currentLanguage === 'hi') return `🧼 वाशिंग कतार: ${lotNum} ${pcsStr}`;
    return `🧼 વોશિંગ કતાર: ${lotNum} ${pcsStr}`;
  }
  if (type.includes('GAAJ')) {
    if (currentLanguage === 'en') return `🔘 Gaaj-Button: ${lotNum} ${pcsStr}`;
    if (currentLanguage === 'hi') return `🔘 गाज-बटन: ${lotNum} ${pcsStr}`;
    return `🔘 ગાજ-બટન: ${lotNum} ${pcsStr}`;
  }
  if (type.includes('PRESS') || type.includes('PACK')) {
    if (currentLanguage === 'en') return `📦 Press & Packing: ${lotNum} ${pcsStr}`;
    if (currentLanguage === 'hi') return `📦 प्रेस व पैकिंग: ${lotNum} ${pcsStr}`;
    return `📦 પ્રેસ & પેકિંગ: ${lotNum} ${pcsStr}`;
  }
  if (type.includes('GODOWN')) {
    if (currentLanguage === 'en') return `🏛️ Finished Godown Stock: ${lotNum} ${pcsStr}`;
    if (currentLanguage === 'hi') return `🏛️ तैयार गोदाम स्टॉक: ${lotNum} ${pcsStr}`;
    return `🏛️ તૈયાર ગોડાઉન સ્ટોક: ${lotNum} ${pcsStr}`;
  }
  if (type.includes('FABRIC')) {
    if (currentLanguage === 'en') return `🧵 Fabric Inward: ${lotNum || 'New Receipt'}`;
    if (currentLanguage === 'hi') return `🧵 कपड़ा आवक: ${lotNum || 'नई रसीद'}`;
    return `🧵 કાપડ આવક: ${lotNum || ''}`;
  }
  if (currentLanguage === 'en') {
    return act.title ? act.title.replace(/[\u0A80-\u0AFF]/g, '').trim() || 'Factory Floor Activity' : 'Factory Floor Activity';
  }
  return act.title;
}

function getLocalizedActivityDesc(act) {
  let desc = act.description || '';
  if (currentLanguage === 'en') {
    desc = desc.replace(/ડીલર:/g, 'Dealer:')
               .replace(/કાપડ:/g, 'Fabric:')
               .replace(/વધેલું:/g, 'Remnant:')
               .replace(/બંડલ/g, 'bundles')
               .replace(/શર્ટ\/બંડલ/g, 'shirts/bundle')
               .replace(/તૈયાર કરી સિલાઈ\/જોબર તરફ મોકલાયો\./g, 'prepared and routed to stitching/jobber.')
               .replace(/સેમ્પલ શર્ટ ફોટો અપડેટ કરવામાં આવ્યો\./g, 'Sample shirt photo updated.')
               .replace(/માલિક અને કારીગર પોર્ટલ પર લાઈવ થયો\./g, 'Live on Owner and Worker portals.')
               .replace(/પીસ/g, 'pcs')
               .replace(/કટીંગ/g, 'Cutting')
               .replace(/સિલાઈ/g, 'Stitching')
               .replace(/વોશિંગ/g, 'Washing')
               .replace(/ગાજ-બટન/g, 'Gaaj-Button')
               .replace(/પ્રેસ/g, 'Press')
               .replace(/ગોડાઉન/g, 'Godown');
    if (/[\u0A80-\u0AFF]/.test(desc)) {
      desc = `Lot ${act.lot_number || ''} activity logged with ${act.pieces_today || act.total_lot_pieces || 0} pieces.`;
    }
  } else if (currentLanguage === 'hi') {
    desc = desc.replace(/ડીલર:/g, 'डीलर:')
               .replace(/કાપડ પ્રકાર:/g, 'कपड़ा प्रकार:')
               .replace(/કાપડ:/g, 'कपड़ा:')
               .replace(/ચલણ:/g, 'चालान:')
               .replace(/કુલ મીટર:/g, 'कुल मीटर:')
               .replace(/વધેલું:/g, 'बचा हुआ:')
               .replace(/સિલાઈ માટે રવાના/g, 'सिलाई के लिए रवाना')
               .replace(/કારીગર/g, 'कारीगर')
               .replace(/તૈયાર/g, 'तैयार')
               .replace(/સ્પીડ/g, 'स्पीड')
               .replace(/બંડલ/g, 'बंडल')
               .replace(/શર્ટ\/બંડલ/g, 'शर्ट/बंडल')
               .replace(/તૈયાર કરી સિલાઈ\/જોબર તરફ મોકલાયો\./g, 'तैयार कर सिलाई/जॉबर की ओर भेजा गया।')
               .replace(/સેમ્પલ શર્ટ ફોટો અપડેટ કરવામાં આવ્યો\./g, 'सैंपल शर्ट फोटो अपडेट किया गया।')
               .replace(/માલિક અને કારીગર પોર્ટલ પર લાઈવ થયો\./g, 'मालिक और कारीगर पोर्टल पर लाइव हुआ।')
               .replace(/પીસ/g, 'पीस');
    return desc;
}


// Reactive Language Switching Listener
window.addEventListener('languageChanged', (e) => {
  if (typeof applyTranslations === 'function') applyTranslations();
  if (typeof loadDashboard === 'function') loadDashboard();
  if (typeof loadDailyFactoryActivity === 'function') loadDailyFactoryActivity();
  if (typeof loadStageFunnel === 'function') loadStageFunnel();
  if (typeof loadJobbersSection === 'function') loadJobbersSection();
  if (typeof filterJobberKarigarsTable === 'function') filterJobberKarigarsTable();
  if (currentJourneyLotId && typeof openLotJourneyModal === 'function') {
    openLotJourneyModal(currentJourneyLotId);
  }
});
// AXIL Factory Management PWA - Owner Command Center Controller
let currentSection = "dashboard";
let charts = {};

// Initial application load
document.addEventListener("DOMContentLoaded", async () => {
  initNavigation();
  initModals();
  initLanguage();
  initGlobalSearch();

  // Check if owner is already authenticated in this session
  const isAuth = checkOwnerAuth();
  if (isAuth) {
    loadCurrentSection();
  }

  // Real-time automatic sync for Owner Portal (every 5 seconds)
  setInterval(() => {
    if (!document.hidden && checkOwnerAuth()) {
      loadCurrentSection();
      // Background notifications check
      api.getDashboardSummary().then((summary) => {
        const notifCountBadge = document.getElementById("notif-count-badge");
        const notifContainer = document.getElementById("notif-list");
        if (summary && summary.notifications && summary.notifications.length > 0) {
          if (notifCountBadge) notifCountBadge.classList.remove("hidden");
          if (notifContainer) {
            notifContainer.innerHTML = summary.notifications.map((n) => `
              <div class="p-2 rounded hover:bg-neutral-50 border-b border-neutral-100 last:border-0">
                <div class="font-bold text-neutral-800">${n.title}</div>
                <div class="text-neutral-600 text-[11px]">${n.message}</div>
                <div class="text-[10px] text-neutral-400 mt-1">${new Date(n.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
              </div>
            `).join("");
          }
        }
      }).catch(() => null);
    }
  }, 5000);
});

// --- OWNER AUTHENTICATION SECURITY GATE ---
function checkOwnerAuth() {
  const isAuth = sessionStorage.getItem("axil_owner_authenticated");
  const token = api.ownerToken || localStorage.getItem("axil_owner_token") || localStorage.getItem("axil_token");
  const gate = document.getElementById("owner-login-gate");
  if (isAuth === "true" && token) {
    if (gate) gate.classList.add("hidden");
    return true;
  }
  if (gate) gate.classList.remove("hidden");
  return false;
}

async function handleOwnerLoginSubmit(e) {
  e.preventDefault();
  const u = document.getElementById("owner-username-input").value.trim();
  const p = document.getElementById("owner-password-input").value.trim();
  const errEl = document.getElementById("owner-login-error");
  const btn = document.getElementById("owner-login-submit-btn");

  btn.disabled = true;
  btn.innerHTML = `<span>⏳ Verifying...</span>`;
  if (errEl) errEl.classList.add("hidden");

  try {
    const res = await api.login(u, p);
    if (res.role !== "OWNER") {
      throw new Error("Access denied: Only Factory Owner can access this command center.");
    }
    api.setSession(res.token, res);
    sessionStorage.setItem("axil_owner_authenticated", "true");
    const gate = document.getElementById("owner-login-gate");
    if (gate) gate.classList.add("hidden");
    showToast("Welcome back, Factory Owner!", "success");
    loadCurrentSection();
  } catch (err) {
    if (errEl) {
      errEl.textContent = err.message || "Incorrect username or password. Please try again.";
      errEl.classList.remove("hidden");
    }
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<span>🔑 Log In to Owner Portal</span>`;
  }
}

function handleOwnerLogout() {
  sessionStorage.removeItem("axil_owner_authenticated");
  api.clearSession();
  const gate = document.getElementById("owner-login-gate");
  if (gate) gate.classList.remove("hidden");
  showToast("Logged out successfully.", "info");
}

// --- NAVIGATION & TABS ---
function initNavigation() {
  const links = document.querySelectorAll(".nav-link");
  links.forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      const section = link.getAttribute("data-section");
      switchSection(section);
      // Close mobile sidebar if open
      document.getElementById("sidebar").classList.add("-translate-x-full");
    });
  });

  // Mobile menu toggle
  const mobileBtn = document.getElementById("mobile-menu-btn");
  const closeSidebarBtn = document.getElementById("close-sidebar-btn");
  const sidebar = document.getElementById("sidebar");

  if (mobileBtn && sidebar) {
    mobileBtn.addEventListener("click", () => {
      sidebar.classList.toggle("-translate-x-full");
    });
  }
  if (closeSidebarBtn && sidebar) {
    closeSidebarBtn.addEventListener("click", () => {
      sidebar.classList.add("-translate-x-full");
    });
  }

  // Logout button
  document.getElementById("logout-btn").addEventListener("click", () => {
    handleOwnerLogout();
  });

  // Notifications dropdown
  const notifBtn = document.getElementById("notif-btn");
  const notifDropdown = document.getElementById("notif-dropdown");
  notifBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    notifDropdown.classList.toggle("hidden");
  });
  document.addEventListener("click", () => notifDropdown.classList.add("hidden"));
}

function switchSection(sectionId) {
  currentSection = sectionId;
  document.querySelectorAll(".content-section").forEach((sec) => sec.classList.add("hidden"));
  const target = document.getElementById(`section-${sectionId}`);
  if (target) target.classList.remove("hidden");

  // Update nav link styles
  document.querySelectorAll(".nav-link").forEach((link) => {
    if (link.getAttribute("data-section") === sectionId) {
      link.className = "nav-link flex items-center gap-2.5 px-3 py-2 rounded-lg text-neutral-900 bg-neutral-100 font-semibold";
    } else {
      link.className = "nav-link flex items-center gap-2.5 px-3 py-2 rounded-lg hover:bg-neutral-50 hover:text-neutral-900 transition-colors";
    }
  });

  loadCurrentSection();
}

function loadCurrentSection() {
  switch (currentSection) {
    case "dashboard": loadDashboard(); break;
    case "lots": loadLots(); break;
    case "handover": loadHandovers(); break;
    case "workers": loadWorkers(); break;
    case "jobbers": loadJobbersAndMachines(); break;
    case "costing": loadCostingAndPayments(); break;
    case "godown": loadGodownStock(); break;
    case "reports": loadReportsAndAnalytics(); break;
    case "masters": loadMasters(); break;
  }
}

// --- 1. DASHBOARD ---
async function loadDashboard() {
  try {
    loadDailyFactoryActivity();
    const summary = await api.getDashboardSummary();
    if (document.getElementById("dash-total-workers")) {
      document.getElementById("dash-total-workers").textContent = summary.total_workers || 0;
    }
    if (document.getElementById("dash-godown-stock")) {
      document.getElementById("dash-godown-stock").textContent = (summary.godown_stock || 0).toLocaleString();
    }
    if (document.getElementById("dash-active-lots-count")) {
      document.getElementById("dash-active-lots-count").textContent = summary.active_lots ? summary.active_lots.length : 0;
    }
    if (document.getElementById("dash-pending-alterations")) {
      document.getElementById("dash-pending-alterations").textContent = summary.pending_alterations ? summary.pending_alterations.length : 0;
    }

    // 1. Fabric in Factory Summary (Uncle Spec)
    if (summary.fabric_summary) {
      const remnantEl = document.getElementById("dash-fabric-remnant");
      const recvEl = document.getElementById("dash-fabric-received");
      const usedEl = document.getElementById("dash-fabric-used");
      if (remnantEl) remnantEl.textContent = `${summary.fabric_summary.remnant_fabric_meters || 0} m`;
      if (recvEl) recvEl.textContent = `${summary.fabric_summary.total_received_meters || 0} m`;
      if (usedEl) usedEl.textContent = `${summary.fabric_summary.total_used_meters || 0} m`;
    }

    // 2. Interactive Washer Assignment (Uncle Spec: Stitching finished -> ask owner which washer to assign)
    const waitingContainer = document.getElementById("dash-waiting-washers-list");
    const waitingBadge = document.getElementById("dash-waiting-washers-count");
    const waitingWashers = summary.waiting_washers || [];
    const availableWashers = summary.available_washers || [];

    if (waitingBadge) waitingBadge.textContent = `${waitingWashers.length} Pending`;

    if (waitingContainer) {
      if (waitingWashers.length === 0) {
        waitingContainer.innerHTML = `
          <div class="text-center py-4 text-amber-800 text-xs font-semibold">
            ${t("no_washer_waiting")}
          </div>
        `;
      } else {
        waitingContainer.innerHTML = waitingWashers.map((w) => `
          <div class="bg-white p-4 rounded-xl border border-amber-300 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <div class="flex items-center gap-2">
                <span class="font-black text-sm text-neutral-900">${w.lot_number}</span>
                <span class="bg-blue-100 text-blue-900 text-[10px] font-black px-2 py-0.5 rounded-md">${w.total_cut_pieces} Pieces</span>
                <span class="bg-amber-100 text-amber-900 text-[10px] font-bold px-2 py-0.5 rounded-md">Stitching Completed</span>
              </div>
              <div class="text-xs text-neutral-600 mt-1">
                Design: <strong class="text-neutral-800">${w.design_name || 'Regular'} (${w.design_number || 'AX'})</strong> • Dealer: <strong>${w.dealer_name || 'Direct'}</strong>
              </div>
            </div>

            <div class="flex items-center gap-2">
              <select id="washer-select-${w.lot_id}" class="text-xs font-bold p-2 bg-neutral-50 border border-neutral-300 rounded-lg text-neutral-900">
                <option value="">-- ${t("choose_washer_placeholder")} --</option>
                ${availableWashers.map(wash => `
                  <option value="${wash.id}">${wash.full_name} (${wash.phone || 'Washer'})</option>
                `).join("")}
              </select>
              <button onclick="confirmWasherAssignment(${w.lot_id}, '${w.lot_number}')" class="px-3.5 py-2 bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-xs rounded-lg whitespace-nowrap shadow-xs btn-tactile">
                📨 ${t("assign_and_send_btn") || "Send"}
              </button>
            </div>
          </div>
        `).join("");
      }
    }

    // 3. Stage-by-Stage Manufacturing Funnel (Uncle Spec: Counters across departments 2 to 8 + Godown)
    const funnelGrid = document.getElementById("dash-stage-funnel-grid");
    if (funnelGrid) {
      const stageIcons = {
        2: "✂️", 3: "🪡", 6: "🧼", 7: "🔘", 8: "📦"
      };
      const funnel = summary.stage_funnel || [];
      const godownPieces = summary.godown_stock || 0;

      const stageCardsHtml = [2, 3, 6, 7, 8].map((deptId) => {
        const item = funnel.find(f => f.department_id === deptId);
        const lotsCount = item ? item.lot_count : 0;
        const pcsCount = item ? item.total_pieces : 0;
        let name = `Dept ${deptId}`;
        if (item) {
          if (currentLanguage === 'en') {
            name = item.department_name;
          } else if (currentLanguage === 'hi') {
            name = item.department_name_hi || item.department_name;
          } else {
            name = item.department_name_gu || item.department_name;
          }
        }
        const icon = stageIcons[deptId] || "⚙️";

        return `
          <div class="p-3 rounded-xl border border-neutral-200 bg-neutral-50/80 hover:bg-white transition-all space-y-1">
            <div class="text-lg">${icon}</div>
            <div class="text-[11px] font-bold text-neutral-700 truncate">${name}</div>
            <div class="text-lg font-black text-neutral-900">${pcsCount.toLocaleString()} <span class="text-[10px] font-bold text-neutral-500">pcs</span></div>
            <div class="text-[10px] font-semibold text-neutral-400">${lotsCount} lots pending</div>
          </div>
        `;
      }).join("");

      const godownCardHtml = `
        <div class="p-3 rounded-xl border border-emerald-300 bg-emerald-50/60 hover:bg-emerald-50 transition-all space-y-1">
          <div class="text-lg">🏢</div>
          <div class="text-[11px] font-bold text-emerald-900 truncate">${t("finished_stock")}</div>
          <div class="text-lg font-black text-emerald-800">${godownPieces.toLocaleString()} <span class="text-[10px] font-bold text-emerald-700">pcs</span></div>
          <div class="text-[10px] font-semibold text-emerald-600">Ready to Dispatch</div>
        </div>
      `;

      funnelGrid.innerHTML = stageCardsHtml + godownCardHtml;
    }

    // 4. Cut Material & Karigar Assignment Tracker (Uncle Spec: Ketlu cutting material padyu chhe & kaya karigar pase gayu)
    const cutTbody = document.getElementById("dash-cutting-material-tbody");
    const cutSummary = document.getElementById("dash-cut-lots-summary");
    if (cutTbody) {
      const activeLots = summary.active_lots || [];
      if (cutSummary) {
        const totalCutPcs = activeLots.reduce((sum, l) => sum + (l.total_cut_pieces || 0), 0);
        cutSummary.textContent = `${activeLots.length} Active Lots • ${totalCutPcs.toLocaleString()} Cut Pieces`;
      }

      if (activeLots.length === 0) {
        cutTbody.innerHTML = `<tr><td colspan="7" class="py-4 text-center text-neutral-400">No cut material currently in factory</td></tr>`;
      } else {
        cutTbody.innerHTML = activeLots.map((l) => {
          const bSize = l.bundle_size || 20;
          const bCount = l.bundles_count || Math.ceil((l.total_cut_pieces || 1) / bSize);
          return `
          <tr class="hover:bg-neutral-50 cursor-pointer transition-colors" onclick="openLotJourneyModal(${l.id})" title="${t('click_to_view_journey')}">
            <td class="py-2.5 px-3">
              <div class="flex items-center gap-2">
                ${l.sample_shirt_photo_url ? `<img src="${l.sample_shirt_photo_url}" class="w-8 h-8 rounded-lg object-cover border border-neutral-300 shadow-2xs">` : ''}
                <div>
                  <span class="font-mono font-black text-neutral-900">${l.lot_number}</span>
                  <div class="text-[10px] text-amber-800 font-bold">📦 ${bCount} bdl (${bSize}/bdl)</div>
                </div>
              </div>
            </td>
            <td class="py-2.5 px-3">
              <div class="font-semibold text-neutral-800">${l.design_name || 'Design'} (${l.design_number || 'AX'})</div>
              ${l.color_breakdown ? `<div class="text-[10px] text-neutral-500 font-medium">${l.color_breakdown}</div>` : ''}
            </td>
            <td class="py-2.5 px-3 font-black text-blue-900">${l.total_cut_pieces} pcs</td>
            <td class="py-2.5 px-3 font-bold text-amber-700">${l.remnant_fabric_meters || 0} m</td>
            <td class="py-2.5 px-3 font-bold text-neutral-800">
              ${l.cutting_master_name || l.dealer_name || 'Floor Karigar'}
            </td>
            <td class="py-2.5 px-3 font-medium text-emerald-700">
              <span class="px-2 py-0.5 rounded bg-emerald-50 border border-emerald-200">${currentLanguage === "en" ? (l.current_department_name || l.current_dept_name) : (currentLanguage === "hi" ? (l.current_department_name_hi || l.current_department_name) : (l.current_department_name_gu || l.current_department_name))}</span>
            </td>
            <td class="py-2.5 px-3">
              <span class="px-2 py-0.5 rounded text-[10px] font-bold ${l.is_urgent ? 'bg-red-100 text-red-800 animate-pulse' : 'bg-neutral-100 text-neutral-700'}">
                ${l.is_urgent ? '🚨 URGENT' : l.current_status}
              </span>
            </td>
          </tr>
        `;
        }).join("");
      }
    }

    // 5. Live Movement & Handover Notifications Feed (Uncle Spec)
    const liveFeed = document.getElementById("dash-live-movement-feed");
    if (liveFeed) {
      const notifs = summary.notifications || [];
      if (notifs.length === 0) {
        liveFeed.innerHTML = `<div class="text-neutral-400 text-center py-3">No recent stage movement alerts</div>`;
      } else {
        liveFeed.innerHTML = notifs.map((n) => `
          <div class="p-3 rounded-xl border border-neutral-100 bg-neutral-50/60 hover:bg-white transition-all flex items-start gap-3">
            <div class="w-8 h-8 rounded-lg bg-neutral-900 text-white flex items-center justify-center font-bold text-xs shrink-0 mt-0.5">
              ${n.title.includes("Wash") ? "🧼" : (n.title.includes("Cut") ? "✂️" : (n.title.includes("Stitch") ? "🪡" : (n.title.includes("Gaaj") ? "🔘" : "📢")))}
            </div>
            <div class="flex-1 min-w-0">
              <div class="flex items-center justify-between gap-2">
                <span class="font-bold text-neutral-900 text-xs">${n.title}</span>
                <span class="text-[10px] text-neutral-400 whitespace-nowrap">${new Date(n.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
              </div>
              <p class="text-neutral-600 text-xs mt-0.5 leading-relaxed">${n.message}</p>
            </div>
          </div>
        `).join("");
      }
    }

    // Render Dashboard Charts (Daily Output Trend & Karigar Velocity)
    api.getAnalyticsReport().then((analytics) => {
      if (!analytics) return;

      // 1. Dashboard Daily Output Trend
      const ctxDashDaily = document.getElementById("dash-chart-daily-trend")?.getContext("2d");
      if (ctxDashDaily && typeof Chart !== "undefined") {
        if (charts.dashDaily) charts.dashDaily.destroy();
        const trend = analytics.daily_trend || [];
        const labels = trend.length > 0 ? trend.map(t => t.date.slice(5)) : ["11-20", "11-21", "11-22", "11-23", "11-24", "11-25"];
        const values = trend.length > 0 ? trend.map(t => t.pieces_completed) : [120, 180, 240, 210, 290, 310];

        charts.dashDaily = new Chart(ctxDashDaily, {
          type: "line",
          data: {
            labels: labels,
            datasets: [{
              label: "Pieces Stitched",
              data: values,
              borderColor: "#059669",
              backgroundColor: "rgba(5, 150, 105, 0.08)",
              fill: true,
              tension: 0.35,
              borderWidth: 2.5,
              pointRadius: 4,
              pointBackgroundColor: "#059669"
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, title: { display: true, text: "Pieces" } } }
          }
        });
      }

      // 2. Dashboard Karigar Velocity Leaderboard
      const ctxDashSpeed = document.getElementById("dash-chart-karigar-speed")?.getContext("2d");
      if (ctxDashSpeed && typeof Chart !== "undefined") {
        if (charts.dashSpeed) charts.dashSpeed.destroy();
        const perf = analytics.karigar_performance || [];
        const names = perf.map(k => k.karigar_name.split(" ")[0]);
        const speeds = perf.map(k => k.avg_speed_pcs_hr);

        charts.dashSpeed = new Chart(ctxDashSpeed, {
          type: "bar",
          data: {
            labels: names,
            datasets: [{
              label: "Speed (Pcs/Hr)",
              data: speeds,
              backgroundColor: "#18181B",
              borderRadius: 6
            }]
          },
          options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: false } },
            scales: { y: { beginAtZero: true, title: { display: true, text: "Pcs / Hr" } } }
          }
        });
      }
    }).catch((err) => console.warn("Dashboard charts load failed:", err));

    // Render department stage cards
    const deptCards = document.getElementById("dash-dept-stage-cards");
    const depts = await api.getDepartments();
    const lots = summary.active_lots;

    deptCards.innerHTML = depts.map((d) => {
      const count = lots.filter((l) => l.department_code === d.code).length;
      const pieces = lots.filter((l) => l.department_code === d.code).reduce((sum, l) => sum + l.total_cut_pieces, 0);
      return `
        <div class="p-2.5 rounded-lg border border-neutral-200 bg-neutral-50">
          <div class="text-[10px] uppercase font-bold text-neutral-400 truncate">${d.name}</div>
          <div class="text-base font-bold text-neutral-900 mt-1">${count} <span class="text-[10px] text-neutral-400 font-normal">lots</span></div>
          <div class="text-[10px] text-neutral-500 font-medium">${pieces.toLocaleString()} pcs</div>
        </div>
      `;
    }).join("");

    // Active lots table
    const lotsTbody = document.getElementById("dash-active-lots-table");
    if (lots.length === 0) {
      lotsTbody.innerHTML = `<tr><td colspan="5" class="py-4 text-center text-neutral-400">No active production lots</td></tr>`;
    } else {
      lotsTbody.innerHTML = lots.slice(0, 6).map((l) => `
        <tr class="hover:bg-neutral-50 cursor-pointer" onclick="viewLotDetails(${l.id})">
          <td class="py-2.5 font-bold text-neutral-900">${l.lot_number}</td>
          <td class="py-2.5">${l.design_number} - ${l.design_name}</td>
          <td class="py-2.5 font-semibold">${l.total_cut_pieces}</td>
          <td class="py-2.5"><span class="px-2 py-0.5 rounded bg-neutral-100 font-medium">${l.current_department_name}</span></td>
          <td class="py-2.5">
            <span class="badge-status ${l.is_delayed ? 'badge-ready-pack' : 'badge-in-process'}">
              ${l.current_status}
            </span>
          </td>
        </tr>
      `).join("");
    }

    // Shortages list
    const shortagesList = document.getElementById("dash-shortages-list");
    if (!summary.recent_shortages || summary.recent_shortages.length === 0) {
      shortagesList.innerHTML = `<div class="text-neutral-400 text-center py-2">No active shortages detected</div>`;
    } else {
      shortagesList.innerHTML = summary.recent_shortages.map((s) => `
        <div class="p-2.5 bg-red-50 border border-red-200 rounded-lg flex items-start justify-between">
          <div>
            <div class="font-bold text-red-900">${s.shortage_quantity} pieces SHORT! (Lot ${s.lot_number})</div>
            <div class="text-[11px] text-red-700">${s.from_dept_name} &rarr; ${s.to_dept_name}</div>
            <div class="text-[10px] text-red-600 mt-0.5 italic">Reason: ${s.shortage_reason || 'Under inspection'}</div>
          </div>
          <span class="text-[10px] font-bold px-1.5 py-0.5 bg-red-200 text-red-800 rounded">DEFICIT</span>
        </div>
      `).join("");
    }

    // Alterations list
    const altList = document.getElementById("dash-alterations-list");
    if (!summary.pending_alterations || summary.pending_alterations.length === 0) {
      altList.innerHTML = `<div class="text-neutral-400 text-center py-2">No pending alterations</div>`;
    } else {
      altList.innerHTML = summary.pending_alterations.map((a) => `
        <div class="p-2.5 bg-amber-50 border border-amber-200 rounded-lg flex items-center justify-between">
          <div>
            <div class="font-bold text-amber-900">${a.alteration_pieces} pcs Alteration: ${a.defect_type}</div>
            <div class="text-[11px] text-amber-800">Karigar: ${a.karigar_name} (${a.department_name})</div>
            <div class="text-[10px] text-amber-600">Lot: ${a.lot_number}</div>
          </div>
          <span class="px-2 py-1 bg-amber-200 text-amber-800 rounded font-semibold text-[10px]">PENDING</span>
        </div>
      `).join("");
    }

    // Notifications dropdown
    const notifCountBadge = document.getElementById("notif-count-badge");
    const notifContainer = document.getElementById("notif-list");
    if (summary.notifications && summary.notifications.length > 0) {
      notifCountBadge.classList.remove("hidden");
      notifContainer.innerHTML = summary.notifications.map((n) => `
        <div class="p-2 rounded hover:bg-neutral-50 border-b border-neutral-100 last:border-0">
          <div class="font-bold text-neutral-800">${n.title}</div>
          <div class="text-neutral-600 text-[11px]">${n.message}</div>
          <div class="text-[10px] text-neutral-400 mt-1">${new Date(n.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</div>
        </div>
      `).join("");
    }
  } catch (err) {
    console.error("Dashboard load failed", err);
  }
}

async function confirmWasherAssignment(lotId, lotNumber) {
  const select = document.getElementById(`washer-select-${lotId}`);
  if (!select || !select.value) {
    alert(t("select_washer_alert"));
    return;
  }
  const washerId = parseInt(select.value);
  const washerName = select.options[select.selectedIndex]?.text || "Washer";
  try {
    await api.assignWasher(lotId, washerId, `Owner assigned lot ${lotNumber} to ${washerName}`);
    showToast(t("washer_sent_toast"), "success");
    loadDashboard();
  } catch (err) {
    showToast(err.message || "Failed to assign washer.", "error");
  }
}

// Global state for Lot Journey Modal
let currentJourneyLotId = null;

function switchDailyFloorView(view) {
  const liveView = document.getElementById("dash-daily-live-view");
  const closingView = document.getElementById("dash-daily-closing-view");
  const btnLive = document.getElementById("btn-daily-stream-live");
  const btnClosing = document.getElementById("btn-daily-stream-closing");

  if (view === "closing") {
    liveView?.classList.add("hidden");
    closingView?.classList.remove("hidden");
    if (btnClosing) btnClosing.className = "px-3 py-1.5 rounded-lg bg-neutral-900 text-white shadow-xs transition-all flex items-center gap-1.5";
    if (btnLive) btnLive.className = "px-3 py-1.5 rounded-lg text-neutral-600 hover:text-neutral-900 transition-all flex items-center gap-1.5";
  } else {
    closingView?.classList.add("hidden");
    liveView?.classList.remove("hidden");
    if (btnLive) btnLive.className = "px-3 py-1.5 rounded-lg bg-neutral-900 text-white shadow-xs transition-all flex items-center gap-1.5";
    if (btnClosing) btnClosing.className = "px-3 py-1.5 rounded-lg text-neutral-600 hover:text-neutral-900 transition-all flex items-center gap-1.5";
  }
}

async function loadDailyFactoryActivity(targetDate = null) {
  const streamContainer = document.getElementById("dash-daily-stream-container");
  if (!streamContainer) return;

  try {
    const res = await api.getDailyActivity(targetDate);
    const activities = res.live_activities || [];
    const closing = res.closing_report || {};
    const metrics = closing.metrics || {};

    // 9 PM notification alert badge
    const badge9pm = document.getElementById("badge-9pm-alert");
    if (badge9pm) {
      if (res.is_after_9pm) {
        badge9pm.classList.remove("hidden");
      } else {
        badge9pm.classList.add("hidden");
      }
    }

    // 1. RENDER LIVE FLOOR ACTIVITY FEED
    if (activities.length === 0) {
      streamContainer.innerHTML = `
        <div class="bg-neutral-50 p-6 rounded-xl border border-neutral-200 text-center text-neutral-400 space-y-1.5">
          <span class="text-3xl block">🏭</span>
          <p class="text-xs font-bold text-neutral-700">${t("no_entries_yet_today")}</p>
          <p class="text-[11px] text-neutral-500">${t("no_entries_yet_sub")}</p>
        </div>
      `;
    } else {
      streamContainer.innerHTML = activities.map(act => {
        const timeStr = act.formatted_time || act.created_at || '';
        const bSize = act.lot_bundle_size || act.bundle_size || 20;
        const bCount = act.lot_bundles_count || act.bundles_count || Math.ceil((act.total_lot_pieces || 1) / bSize);

        // Department badges / icons
        const icon = act.activity_type.includes("CUT") ? "✂️" :
          (act.activity_type.includes("STITCH") ? "🪡" :
          (act.activity_type.includes("WASH") ? "🧼" :
          (act.activity_type.includes("GAAJ") ? "🔘" :
          (act.activity_type.includes("PRESS") || act.activity_type.includes("PACK") ? "📦" :
          (act.activity_type.includes("GODOWN") ? "🏢" : "📢")))));

        return `
          <div class="bg-white p-3.5 sm:p-4 rounded-xl border border-neutral-200 hover:border-neutral-900 shadow-2xs hover:shadow-xs transition-all cursor-pointer flex flex-col sm:flex-row sm:items-center justify-between gap-3"
               onclick="openLotJourneyModal(${act.lot_id})" title="${t('click_to_view_journey')}">
            
            <div class="flex items-start gap-3">
              <div class="w-10 h-10 rounded-xl bg-neutral-900 text-white flex items-center justify-center text-lg font-bold shrink-0 mt-0.5">
                ${icon}
              </div>

              <div class="space-y-1 min-w-0">
                <div class="flex items-center gap-2 flex-wrap">
                  <span class="font-black text-sm text-neutral-900">${getLocalizedActivityTitle(act)}</span>
                  ${act.lot_number ? `
                    <span class="bg-neutral-100 text-neutral-800 font-mono font-bold text-xs px-2 py-0.5 rounded-md border border-neutral-200">
                      ${act.lot_number}
                    </span>
                  ` : ''}
                  ${act.is_stage_completed ? `
                    <span class="bg-emerald-100 text-emerald-800 text-[10px] font-black px-2 py-0.5 rounded-full">
                      ${t("stage_completed_badge")}
                    </span>
                  ` : `
                    <span class="bg-blue-50 text-blue-800 text-[10px] font-bold px-2 py-0.5 rounded-full border border-blue-200">
                      ${t("stage_in_progress_badge")}
                    </span>
                  `}
                </div>

                <p class="text-xs text-neutral-600">${getLocalizedActivityDesc(act)}</p>

                <div class="flex items-center gap-3 text-[11px] text-neutral-500 flex-wrap pt-0.5">
                  <span class="font-semibold text-neutral-700">🕒 ${t("time_label")} <strong class="text-neutral-900">${timeStr}</strong></span>
                  ${act.worker_name ? `<span>👤 ${t("karigar_label")} <strong>${act.worker_name}</strong> ${act.machine_code ? `(${act.machine_code})` : ''}</span>` : ''}
                  ${act.lot_bundles_count || act.bundles_count ? `
                    <span class="text-amber-800 font-bold bg-amber-50 px-2 py-0.5 rounded border border-amber-200">
                      📦 ${bCount} ${t("bundles_count_label")} (${bSize} ${t("shirts_per_bundle_label")})
                    </span>
                  ` : ''}
                </div>
              </div>
            </div>

            <div class="flex items-center gap-2 shrink-0 self-end sm:self-center">
              ${act.sample_shirt_photo_url ? `
                <img src="${act.sample_shirt_photo_url}" class="w-10 h-10 rounded-lg object-cover border border-neutral-300 shadow-2xs">
              ` : ''}
              <button class="px-3 py-1.5 bg-neutral-100 hover:bg-neutral-900 hover:text-white text-neutral-700 text-xs font-bold rounded-lg border border-neutral-200 transition-all flex items-center gap-1">
                <span>🔍 ${t("view_journey_btn")}</span>
                <span>&rarr;</span>
              </button>
            </div>

          </div>
        `;
      }).join("");
    }

    // 2. RENDER 9 PM CLOSING FACTORY REPORT
    const dateHeader = document.getElementById("closing-report-header-date");
    if (dateHeader) {
      dateHeader.textContent = `${t("closing_report_title")} (${closing.formatted_date || closing.date || 'Today'})`;
    }

    const metricsGrid = document.getElementById("closing-metrics-grid");
    if (metricsGrid) {
      const kpis = [
        { label: t("metric_fabric_inward"), val: `${metrics.fabric_meters_inward || 0} m`, icon: "🧵", color: "text-amber-400" },
        { label: t("metric_pieces_cut"), val: `${metrics.pieces_cut || 0} pcs`, icon: "✂️", color: "text-blue-400" },
        { label: t("metric_pieces_stitched"), val: `${metrics.pieces_stitched || 0} pcs`, icon: "🪡", color: "text-indigo-400" },
        { label: t("metric_pieces_washed"), val: `${metrics.pieces_washed || 0} pcs`, icon: "🧼", color: "text-sky-400" },
        { label: t("metric_gaaj_button"), val: `${metrics.pieces_gaaj_button || 0} pcs`, icon: "🔘", color: "text-purple-400" },
        { label: t("metric_press_packing"), val: `${metrics.pieces_ironed_packed || 0} pcs`, icon: "📦", color: "text-amber-300" },
        { label: t("metric_finished_godown"), val: `${metrics.finished_to_godown || 0} pcs`, icon: "🏛️", color: "text-emerald-400" }
      ];

      metricsGrid.innerHTML = kpis.map(k => `
        <div class="bg-white/10 p-2.5 rounded-xl border border-white/10">
          <div class="text-[10px] text-neutral-300 font-bold uppercase truncate">${k.label}</div>
          <div class="text-base font-black ${k.color} mt-0.5">${k.val}</div>
        </div>
      `).join("");
    }

    // Lots today closing table
    const lotsTbody = document.getElementById("closing-lots-tbody");
    const closingLots = closing.lots || [];
    if (lotsTbody) {
      if (closingLots.length === 0) {
        lotsTbody.innerHTML = `<tr><td colspan="8" class="text-center py-4 text-neutral-400">${t("no_lots_today")}</td></tr>`;
      } else {
        lotsTbody.innerHTML = closingLots.map(l => `
          <tr class="hover:bg-neutral-50 cursor-pointer" onclick="openLotJourneyModal(${l.lot_id})">
            <td class="py-2.5 px-3">
              <div class="flex items-center gap-1.5">
                ${l.sample_shirt_photo_url ? `<img src="${l.sample_shirt_photo_url}" class="w-7 h-7 rounded object-cover border border-neutral-200">` : ''}
                <span class="font-mono font-black text-neutral-900">${l.lot_number}</span>
              </div>
            </td>
            <td class="py-2.5 px-3 font-semibold">${l.design_name} (${l.design_number})</td>
            <td class="py-2.5 px-3">
              <span class="bg-amber-100 text-amber-900 text-[10px] font-bold px-2 py-0.5 rounded">
                ${l.bundles_count} ${t("bundles_count_label")} (${l.bundle_size}/${t("shirts_per_bundle_label")})
              </span>
            </td>
            <td class="py-2.5 px-3 font-black text-blue-900">${l.pieces_today} pcs</td>
            <td class="py-2.5 px-3 font-bold text-neutral-800">${l.cumulative_pieces} / ${l.total_cut_pieces} pcs</td>
            <td class="py-2.5 px-3">
              <div class="w-24 bg-neutral-200 rounded-full h-2 overflow-hidden">
                <div class="${l.is_completed ? 'bg-emerald-600' : 'bg-blue-600'} h-2 rounded-full" style="width: ${l.progress_percent}%"></div>
              </div>
              <span class="text-[10px] font-semibold text-neutral-500">${l.progress_percent}%</span>
            </td>
            <td class="py-2.5 px-3 font-semibold text-xs">
              <span class="px-2 py-0.5 rounded text-[10px] font-bold ${l.is_completed ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}">
                ${l.status_label}
              </span>
            </td>
            <td class="py-2.5 px-3 text-right">
              <button class="px-2.5 py-1 bg-neutral-900 text-white rounded text-[11px] font-bold hover:bg-neutral-800">
                ${t("view_journey_btn")} &rarr;
              </button>
            </td>
          </tr>
        `).join("");
      }
    }

    // Workers today closing table
    const workersTbody = document.getElementById("closing-workers-tbody");
    const closingWorkers = closing.workers || [];
    if (workersTbody) {
      if (closingWorkers.length === 0) {
        workersTbody.innerHTML = `<tr><td colspan="6" class="text-center py-4 text-neutral-400">${t("no_workers_today")}</td></tr>`;
      } else {
        workersTbody.innerHTML = closingWorkers.map(w => `
          <tr class="hover:bg-neutral-50">
            <td class="py-2.5 px-3 font-bold text-neutral-900">${w.worker_name}</td>
            <td class="py-2.5 px-3 font-mono font-bold text-neutral-600">${w.machine_code || '-'}</td>
            <td class="py-2.5 px-3 text-neutral-600">${w.role}</td>
            <td class="py-2.5 px-3 font-black text-blue-900">${w.pieces_today} pcs</td>
            <td class="py-2.5 px-3 font-semibold text-emerald-700">${w.avg_speed ? `${w.avg_speed} pcs/hr` : '-'}</td>
            <td class="py-2.5 px-3 text-right font-black text-neutral-900">₹${(w.earnings_today || 0).toLocaleString()}</td>
          </tr>
        `).join("");
      }
    }

  } catch (err) {
    console.error("Failed to load daily factory activity", err);
  }
}

// LOT JOURNEY MODAL IMPLEMENTATION
async function openLotJourneyModal(lotId) {
  if (!lotId) return;
  currentJourneyLotId = lotId;
  const modal = document.getElementById("modal-lot-journey");
  if (!modal) return;
  modal.classList.remove("hidden");

  // Show loading indicators
  const lotNumEl = document.getElementById("journey-lot-number");
  if (lotNumEl) lotNumEl.textContent = `...`;
  const stagesEl = document.getElementById("journey-stages-timeline");
  if (stagesEl) stagesEl.innerHTML = `<div class="text-center py-8 text-neutral-400 text-xs">${t("loading_journey_msg")}</div>`;

  try {
    const journey = await api.getLotJourney(lotId);
    const lot = journey.lot || {};
    const stages = journey.stages || [];
    const workers = journey.workers_involved || [];
    const timeline = journey.timeline || [];

    // Header
    if (lotNumEl) lotNumEl.textContent = lot.lot_number || `LOT-${lotId}`;
    const badgeEl = document.getElementById("journey-lot-badge");
    if (badgeEl) badgeEl.textContent = `${lot.total_cut_pieces || 0} Pieces`;
    const urgentBadge = document.getElementById("journey-urgent-badge");
    if (urgentBadge) {
      if (lot.is_urgent) urgentBadge.classList.remove("hidden");
      else urgentBadge.classList.add("hidden");
    }
    const subEl = document.getElementById("journey-lot-subtitle");
    if (subEl) {
      subEl.textContent = `Design: ${lot.design_name || 'Design'} (${lot.design_number || 'AX'}) • Dealer: ${lot.dealer_name || lot.supplier_name || 'Direct'} • Fabric: ${lot.fabric_type || 'Cotton'}`;
    }
    const footEl = document.getElementById("journey-footer-lot-id");
    if (footEl) {
      footEl.textContent = `Lot ID: #${lot.id} • Cutting Date: ${lot.formatted_cutting_date || lot.cutting_date}`;
    }

    // Overview: Bundles, Colors, Photo
    const bDisp = document.getElementById("journey-bundle-display");
    if (bDisp) {
      bDisp.textContent = `${lot.bundles_count || Math.ceil(lot.total_cut_pieces / (lot.bundle_size || 20))} ${t("bundles_count_label")} (${lot.bundle_size || 20} ${t("shirts_per_bundle_label")})`;
    }
    const remEl = document.getElementById("journey-remnant-meters");
    if (remEl) remEl.textContent = `${lot.remnant_fabric_meters || 0} m`;

    // Colors chips
    const colorsCont = document.getElementById("journey-colors-container");
    if (colorsCont) {
      if (lot.color_breakdown) {
        const parts = lot.color_breakdown.split(/[,;]/);
        colorsCont.innerHTML = parts.map(p => `
          <span class="px-2.5 py-1 bg-white text-blue-900 border border-blue-300 rounded-lg text-xs font-bold shadow-2xs">
            🎨 ${p.trim()}
          </span>
        `).join("");
      } else if (lot.color_swatches) {
        colorsCont.innerHTML = `
          <span class="px-2.5 py-1 bg-white text-neutral-800 border border-neutral-300 rounded-lg text-xs font-bold shadow-2xs">
            ${lot.color_swatches}
          </span>
        `;
      } else {
        colorsCont.innerHTML = `<span class="text-xs text-neutral-400">${t("no_color_breakdown")}</span>`;
      }
    }

    // Photo Preview
    const photoCont = document.getElementById("journey-photo-container");
    const photoCaption = document.getElementById("journey-photo-caption");
    if (photoCont) {
      if (lot.sample_shirt_photo_url) {
        photoCont.innerHTML = `<img src="${lot.sample_shirt_photo_url}" class="w-full h-full object-cover">`;
        if (photoCaption) photoCaption.textContent = t("photo_live_badge");
      } else {
        photoCont.innerHTML = `<span class="text-2xl text-neutral-400">👕</span>`;
        if (photoCaption) photoCaption.textContent = t("photo_pending_badge");
      }
    }

    // Current stage tag
    const stageTag = document.getElementById("journey-current-stage-tag");
    if (stageTag) {
      stageTag.textContent = `${t("current_stage_label")} ${lot.current_dept_name || lot.current_status}`;
    }

    // 9-Stage Visual Timeline
    if (stagesEl) {
      stagesEl.innerHTML = stages.map(s => {
        let badgeColor = "bg-neutral-100 text-neutral-600 border-neutral-300";
        let statusText = t("stage_pending_badge");
        if (s.status === "COMPLETED") {
          badgeColor = "bg-emerald-100 text-emerald-800 border-emerald-300";
          statusText = t("stage_completed_badge");
        } else if (s.status === "IN_PROGRESS") {
          badgeColor = "bg-blue-100 text-blue-900 border-blue-300 animate-pulse";
          statusText = t("stage_in_progress_badge");
        } else if (s.status === "SKIPPED") {
          badgeColor = "bg-neutral-100 text-neutral-400 border-neutral-200 line-through";
          statusText = t("stage_skipped_badge");
        }

        return `
          <div class="p-3.5 rounded-xl border border-neutral-200 bg-white hover:bg-neutral-50 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div class="flex items-start gap-3">
              <div class="w-8 h-8 rounded-full bg-neutral-900 text-white font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                ${s.stage_num}
              </div>
              <div class="space-y-0.5">
                <div class="flex items-center gap-2">
                  <span class="text-base">${s.icon}</span>
                  <span class="font-bold text-xs text-neutral-900">${currentLanguage === 'en' ? (s.title || s.title_en) : (currentLanguage === 'hi' ? (s.title_hi || s.title) : (s.title_gu || s.title))}</span>
                </div>
                <p class="text-[11px] text-neutral-600">${currentLanguage === 'en' ? (s.details || s.details_en) : (currentLanguage === 'hi' ? (s.details_hi || s.details) : (s.details_gu || s.details)) || ''}</p>
                ${s.worker_name ? `<div class="text-[10px] text-neutral-500 font-semibold">${t("responsible_label")} <strong class="text-neutral-800">${s.worker_name}</strong></div>` : ''}
                ${s.bundles ? `<div class="text-[10px] text-amber-800 font-bold">📦 ${s.bundles}</div>` : ''}
              </div>
            </div>

            <div class="shrink-0 text-right">
              <span class="px-2.5 py-1 rounded-lg text-[10px] font-black border ${badgeColor}">
                ${statusText}
              </span>
              ${s.date_formatted ? `<div class="text-[10px] text-neutral-400 mt-1">${s.date_formatted}</div>` : ''}
            </div>
          </div>
        `;
      }).join("");
    }

    // Workers Audit Table
    const workersTbody = document.getElementById("journey-workers-tbody");
    if (workersTbody) {
      if (workers.length === 0) {
        workersTbody.innerHTML = `<tr><td colspan="6" class="text-center py-4 text-neutral-400">${t("no_karigar_records")}</td></tr>`;
      } else {
        workersTbody.innerHTML = workers.map(w => `
          <tr class="hover:bg-neutral-50">
            <td class="py-2 px-3 font-bold text-neutral-900">${w.name}</td>
            <td class="py-2 px-3 text-neutral-600">${w.role}</td>
            <td class="py-2 px-3 font-mono font-bold text-neutral-700">${w.machine || '-'}</td>
            <td class="py-2 px-3 font-mono text-neutral-600">${w.phone || '-'}</td>
            <td class="py-2 px-3 font-black text-blue-900">${w.pieces || 0} pcs</td>
            <td class="py-2 px-3 text-right font-black text-emerald-700">₹${(w.earned || 0).toLocaleString()}</td>
          </tr>
        `).join("");
      }
    }

    // Chronological Activity Log
    const logsCont = document.getElementById("journey-activity-logs");
    if (logsCont) {
      if (timeline.length === 0) {
        logsCont.innerHTML = `<div class="text-neutral-400 text-center py-2">${t("no_activity_history")}</div>`;
      } else {
        logsCont.innerHTML = timeline.map(ev => `
          <div class="flex items-start gap-2.5 p-2 rounded-lg bg-white border border-neutral-200">
            <span class="text-xs">🕒</span>
            <div class="flex-1 min-w-0">
              <div class="flex justify-between items-baseline gap-2">
                <span class="font-bold text-xs text-neutral-900">${ev.title}</span>
                <span class="text-[10px] font-semibold text-neutral-500 whitespace-nowrap">${ev.formatted_time || ev.created_at}</span>
              </div>
              <p class="text-[11px] text-neutral-600 mt-0.5">${ev.description}</p>
            </div>
          </div>
        `).join("");
      }
    }

  } catch (err) {
    showToast(err.message || "Failed to load lot journey.", "error");
  }
}

function closeLotJourneyModal() {
  const modal = document.getElementById("modal-lot-journey");
  if (modal) modal.classList.add("hidden");
  currentJourneyLotId = null;
}

async function uploadJourneyLotPhoto(event) {
  if (!currentJourneyLotId) return;
  const file = event.target.files && event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = async (e) => {
    const base64 = e.target.result;
    try {
      showToast("Uploading new sample shirt photo...", "info");
      await api.uploadLotPhoto(currentJourneyLotId, base64);
      showToast("✅ Sample shirt photo uploaded successfully!", "success");
      openLotJourneyModal(currentJourneyLotId);
      loadDailyFactoryActivity();
    } catch (err) {
      showToast(err.message || "Failed to upload photo.", "error");
    }
  };
  reader.readAsDataURL(file);
}

// --- 2. ATTENDANCE ---
async function loadAttendance() {
  const tbody = document.getElementById("attendance-tbody");
  const picker = document.getElementById("att-date-picker");
  if (!tbody || !picker) return;
  try {
    if (!picker.value) {
      picker.value = new Date().toISOString().split("T")[0];
    }

    const workers = await api.getWorkers();
    const selectedDate = picker.value;
    const tbody = document.getElementById("attendance-tbody");

    // Fetch month data for calendar matrix
    const currentMonth = selectedDate.substring(0, 7);
    const monthPicker = document.getElementById("att-month-picker");
    if (monthPicker) monthPicker.value = currentMonth;
    const monthlyRecords = await api.getMonthlyAttendance(currentMonth);

    // Render Daily Attendance Table
    tbody.innerHTML = workers.map((w) => {
      const todayRecord = monthlyRecords.find((r) => r.worker_id === w.id && r.date === selectedDate);
      const status = todayRecord ? todayRecord.status : "PRESENT";
      const ot = todayRecord ? (todayRecord.overtime_hours || 0) : 0;
      const notes = todayRecord ? (todayRecord.notes || "") : "";

      return `
        <tr class="hover:bg-neutral-50/80">
          <td class="py-2.5 px-4 font-mono font-bold text-neutral-700">${w.worker_code}</td>
          <td class="py-2.5 px-4 font-medium text-neutral-900">${w.full_name}</td>
          <td class="py-2.5 px-4 text-neutral-500">${w.department_name || '-'}</td>
          <td class="py-2.5 px-4">
            <div class="flex items-center gap-1">
              <button onclick="setWorkerAttendance(${w.id}, 'PRESENT', '${selectedDate}')" class="px-2.5 py-1 rounded text-[11px] font-semibold ${status === 'PRESENT' ? 'bg-emerald-600 text-white' : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'}">P</button>
              <button onclick="setWorkerAttendance(${w.id}, 'ABSENT', '${selectedDate}')" class="px-2.5 py-1 rounded text-[11px] font-semibold ${status === 'ABSENT' ? 'bg-red-600 text-white' : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'}">A</button>
              <button onclick="setWorkerAttendance(${w.id}, 'HALF_DAY', '${selectedDate}')" class="px-2.5 py-1 rounded text-[11px] font-semibold ${status === 'HALF_DAY' ? 'bg-amber-600 text-white' : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'}">HD</button>
            </div>
          </td>
          <td class="py-2.5 px-4">
            <input type="number" step="0.5" min="0" value="${ot}" id="ot-input-${w.id}" class="w-16 px-2 py-1 bg-neutral-50 border border-neutral-200 rounded text-xs text-center" onchange="saveWorkerAttendance(${w.id}, '${selectedDate}')">
          </td>
          <td class="py-2.5 px-4">
            <input type="text" placeholder="Note" value="${notes}" id="note-input-${w.id}" class="w-32 px-2 py-1 bg-neutral-50 border border-neutral-200 rounded text-xs" onchange="saveWorkerAttendance(${w.id}, '${selectedDate}')">
          </td>
          <td class="py-2.5 px-4 text-right">
            <button onclick="saveWorkerAttendance(${w.id}, '${selectedDate}')" class="px-2.5 py-1 bg-neutral-900 text-white rounded text-[11px] hover:bg-neutral-800">Save</button>
          </td>
        </tr>
      `;
    }).join("");

    renderMonthlyAttendanceCalendar(workers, monthlyRecords, currentMonth);

    picker.onchange = () => loadAttendance();
    if (monthPicker) monthPicker.onchange = () => loadAttendance();
  } catch (err) {
    console.error("Attendance load failed:", err);
    const tbody = document.getElementById("attendance-tbody");
    if (tbody) {
      tbody.innerHTML = `<tr><td colspan="7" class="py-6 text-center text-red-500">Failed to load attendance: ${err.message}</td></tr>`;
    }
  }
}

async function setWorkerAttendance(workerId, status, date) {
  const ot = parseFloat(document.getElementById(`ot-input-${workerId}`)?.value || 0);
  const notes = document.getElementById(`note-input-${workerId}`)?.value || "";
  await api.markAttendance({ worker_id: workerId, date, status, overtime_hours: ot, notes });
  showToast("Attendance updated");
  loadAttendance();
}

async function saveWorkerAttendance(workerId, date) {
  const ot = parseFloat(document.getElementById(`ot-input-${workerId}`)?.value || 0);
  const notes = document.getElementById(`note-input-${workerId}`)?.value || "";
  await api.markAttendance({ worker_id: workerId, date, status: "PRESENT", overtime_hours: ot, notes });
  showToast("Saved attendance details");
}

function renderMonthlyAttendanceCalendar(workers, records, monthStr) {
  const container = document.getElementById("attendance-calendar-matrix");
  const daysInMonth = new Date(parseInt(monthStr.split("-")[0]), parseInt(monthStr.split("-")[1]), 0).getDate();

  let headerHtml = `<div class="grid grid-cols-[140px_repeat(${daysInMonth},_26px)] font-bold border-b pb-1 text-[10px] text-neutral-400"><div>Karigar</div>`;
  for (let i = 1; i <= daysInMonth; i++) {
    headerHtml += `<div class="text-center">${i}</div>`;
  }
  headerHtml += `</div>`;

  let rowsHtml = workers.map((w) => {
    let row = `<div class="grid grid-cols-[140px_repeat(${daysInMonth},_26px)] items-center py-1 border-b border-neutral-100 hover:bg-neutral-50/50">
      <div class="truncate font-medium text-neutral-900 pr-2">${w.full_name}</div>`;
    for (let d = 1; d <= daysInMonth; d++) {
      const dayStr = `${monthStr}-${String(d).padStart(2, '0')}`;
      const rec = records.find((r) => r.worker_id === w.id && r.date === dayStr);
      let cellClass = "bg-neutral-100 text-neutral-300";
      let text = "-";
      if (rec) {
        if (rec.status === "PRESENT") { cellClass = "att-pill-present font-bold"; text = "P"; }
        else if (rec.status === "ABSENT") { cellClass = "att-pill-absent font-bold"; text = "A"; }
        else if (rec.status === "HALF_DAY") { cellClass = "att-pill-halfday font-bold"; text = "HD"; }
      }
      row += `<div class="h-6 flex items-center justify-center rounded text-[10px] ${cellClass}">${text}</div>`;
    }
    row += `</div>`;
    return row;
  }).join("");

  container.innerHTML = headerHtml + rowsHtml;
}

// Mark All Present
document.getElementById("mark-all-present-btn")?.addEventListener("click", async () => {
  const picker = document.getElementById("att-date-picker");
  const workers = await api.getWorkers();
  for (const w of workers) {
    await api.markAttendance({ worker_id: w.id, date: picker.value, status: "PRESENT", overtime_hours: 0 });
  }
  showToast(`All ${workers.length} workers marked Present for today`);
  loadAttendance();
});

// --- 3. ORDERS & DISPATCH ---
async function loadOrders(statusFilter = "") {
  const tbody = document.getElementById("orders-tbody");
  if (!tbody) return;
  const orders = await api.getOrders(statusFilter);

  if (orders.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" class="py-6 text-center text-neutral-400">No orders found</td></tr>`;
    return;
  }

  tbody.innerHTML = orders.map((o) => {
    const isDispatched = o.current_status === 'DISPATCHED';
    const isDelivered = o.current_status === 'DELIVERED';
    
    let logisticsInfo = '';
    if (isDispatched || isDelivered) {
      logisticsInfo = `
        <div class="text-[10px] text-neutral-500 mt-1 font-mono flex items-center gap-1.5 flex-wrap">
          <span class="font-bold text-neutral-800">🚚 ${o.transport_name || 'Road Transport'}</span>
          <span>•</span>
          <span>LR: <strong class="text-blue-700 font-bold">${o.tracking_lr_number || 'N/A'}</strong></span>
          <span>(${o.parcel_count || 1} pkgs)</span>
          ${o.dispatch_date ? `<span>• ${o.dispatch_date}</span>` : ''}
        </div>
      `;
    }

    return `
      <tr class="hover:bg-neutral-50">
        <td class="py-2.5 px-4 font-bold text-neutral-900">${o.order_number}</td>
        <td class="py-2.5 px-4 font-medium">
          <div>${o.customer_name} <span class="text-neutral-400 font-normal">(${o.customer_city || ''})</span></div>
          ${logisticsInfo}
        </td>
        <td class="py-2.5 px-4">${o.design_number} - ${o.design_name}</td>
        <td class="py-2.5 px-4 font-bold">${o.total_quantity.toLocaleString()} pcs</td>
        <td class="py-2.5 px-4">${o.delivery_due_date}</td>
        <td class="py-2.5 px-4">
          <select onchange="updateOrderStatus(${o.id}, this.value)" class="text-xs font-semibold px-2 py-1 rounded border border-neutral-200 bg-white">
            <option value="RECEIVED" ${o.current_status === 'RECEIVED' ? 'selected' : ''}>Received</option>
            <option value="IN_PROCESS" ${o.current_status === 'IN_PROCESS' ? 'selected' : ''}>In Process</option>
            <option value="PRODUCTION_COMPLETED" ${o.current_status === 'PRODUCTION_COMPLETED' ? 'selected' : ''}>Production Completed</option>
            <option value="READY_FOR_PACKING" ${o.current_status === 'READY_FOR_PACKING' ? 'selected' : ''}>Ready for Packing</option>
            <option value="PACKED" ${o.current_status === 'PACKED' ? 'selected' : ''}>Packed</option>
            <option value="DISPATCHED" ${isDispatched ? 'selected' : ''}>Dispatched (In Transit)</option>
            <option value="DELIVERED" ${isDelivered ? 'selected' : ''}>Delivered</option>
          </select>
        </td>
        <td class="py-2.5 px-4 text-right space-x-1">
          ${!isDispatched && !isDelivered ? `
            <button onclick="openDispatchModal(${o.id})" class="px-2.5 py-1 bg-neutral-900 text-white text-[11px] font-semibold rounded hover:bg-neutral-800 btn-tactile">Dispatch</button>
          ` : (isDispatched ? `
            <button onclick="updateOrderStatus(${o.id}, 'DELIVERED')" class="px-2.5 py-1 bg-emerald-600 text-white text-[11px] font-semibold rounded hover:bg-emerald-700 btn-tactile">Mark Delivered</button>
            <button onclick="shareDispatchWhatsApp('${o.order_number}', '${o.customer_name}', '${o.customer_phone || ''}', '${o.total_quantity}', '${o.transport_name || ''}', '${o.tracking_lr_number || ''}', ${o.parcel_count || 1})" class="px-2 py-1 bg-neutral-100 text-emerald-800 text-[11px] font-semibold rounded hover:bg-neutral-200">WhatsApp LR</button>
          ` : `
            <button onclick="shareDispatchWhatsApp('${o.order_number}', '${o.customer_name}', '${o.customer_phone || ''}', '${o.total_quantity}', '${o.transport_name || ''}', '${o.tracking_lr_number || ''}', ${o.parcel_count || 1})" class="px-2.5 py-1 bg-neutral-100 text-emerald-800 text-[11px] font-semibold rounded hover:bg-neutral-200">Slip</button>
          `)}
        </td>
      </tr>
    `;
  }).join("");
}

// Order Status Tabs
document.getElementById("order-status-tabs")?.querySelectorAll("button").forEach((btn) => {
  btn.addEventListener("click", () => {
    document.querySelectorAll("#order-status-tabs button").forEach((b) => {
      b.className = "px-3 py-1 bg-neutral-100 text-neutral-600 rounded-md font-medium hover:bg-neutral-200";
    });
    btn.className = "px-3 py-1 bg-neutral-900 text-white rounded-md font-medium";
    loadOrders(btn.getAttribute("data-filter"));
  });
});

async function updateOrderStatus(orderId, status) {
  await api.updateOrderStatus(orderId, status);
  showToast(`Order status updated to ${status}`);
  loadOrders();
}

function openDispatchModal(orderId) {
  document.getElementById("dispatch-order-id").value = orderId;
  document.getElementById("modal-dispatch").classList.remove("hidden");
}

function shareDispatchWhatsApp(orderNum, customerName, phone, qty, transport, lr, parcels) {
  const text = encodeURIComponent(
    `*AXIL FACTORY DISPATCH RECEIPT*\n\n` +
    `Dear ${customerName},\n` +
    `Your wholesale shirt order *${orderNum}* (${qty} pcs) has been dispatched.\n\n` +
    `📦 *Parcels*: ${parcels} Boxes/Bales\n` +
    `🚚 *Transport Agency*: ${transport || 'Direct Road Transport'}\n` +
    `📄 *LR / Bilty Number*: ${lr || 'Pending'}\n` +
    `📍 *Status*: In Transit\n\n` +
    `Please present this LR copy at your local transport delivery branch to collect the parcels.\n` +
    `Thank you for choosing AXIL Shirts!`
  );
  const cleanPhone = (phone || '').replace(/[^0-9]/g, '');
  window.open(`https://wa.me/${cleanPhone}?text=${text}`, '_blank');
}

// --- 4. MANUFACTURING & LOTS ---
async function loadLots() {
  const lots = await api.getLots();
  const tbody = document.getElementById("lots-tbody");

  if (lots.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" class="py-6 text-center text-neutral-400">No production lots found</td></tr>`;
    return;
  }

  tbody.innerHTML = lots.map((l) => `
    <tr class="hover:bg-neutral-50 cursor-pointer" onclick="viewLotDetails(${l.id})">
      <td class="py-2.5 px-4 font-bold text-neutral-900">${l.lot_number}</td>
      <td class="py-2.5 px-4 font-medium">${l.design_number} - ${l.design_name}</td>
      <td class="py-2.5 px-4 font-bold">${l.total_cut_pieces.toLocaleString()}</td>
      <td class="py-2.5 px-4 text-neutral-500">${l.meters_consumed || 0} m</td>
      <td class="py-2.5 px-4 text-neutral-600">${l.cutting_master_name || '-'}</td>
      <td class="py-2.5 px-4 font-medium"><span class="px-2 py-0.5 rounded bg-neutral-100">${l.current_department_name}</span></td>
      <td class="py-2.5 px-4">
        <span class="badge-status ${l.is_delayed ? 'badge-ready-pack' : 'badge-in-process'}">
          ${l.current_status}
        </span>
      </td>
      <td class="py-2.5 px-4 text-right space-x-1" onclick="event.stopPropagation()">
        <button onclick="openJobSlipModal(${l.id})" class="px-2 py-1 bg-neutral-100 text-neutral-800 rounded text-[11px] font-semibold hover:bg-neutral-200">🏷️ Slip</button>
        <button onclick="viewLotDetails(${l.id})" class="px-2 py-1 bg-neutral-900 text-white rounded text-[11px] font-semibold hover:bg-neutral-800">Inspect &rarr;</button>
      </td>
    </tr>
  `).join("");
}

async function viewLotDetails(lotId) {
  try {
    const details = await api.getLotDetails(lotId);
    if (!details) {
      alert("Could not load details for Lot #" + lotId);
      return;
    }

    const titleEl = document.getElementById("lot-modal-title");
    const subTitleEl = document.getElementById("lot-modal-subtitle");
    const content = document.getElementById("lot-modal-content");
    const modal = document.getElementById("modal-lot-details");

    if (titleEl) titleEl.textContent = `Lot #${details.lot_number || lotId}`;
    if (subTitleEl) subTitleEl.textContent = `${details.design_number || ''} - ${details.design_name || 'Design'} (${(details.total_cut_pieces || 0).toLocaleString()} Cut Pieces)`;

    const cost = details.cost_sheet;
    const routes = details.routes || [];
    const productions = details.productions || [];

    if (content) {
      content.innerHTML = `
        <!-- Top Actions Ribbon -->
        <div class="flex items-center justify-between bg-neutral-100 p-2.5 rounded-lg text-xs">
          <span class="font-bold text-neutral-700">Quick Lot Actions:</span>
          <div class="flex items-center gap-2">
            <button onclick="quickMoveLot(${details.id}, ${details.current_department_id || 1})" class="px-3 py-1.5 bg-neutral-900 text-white rounded-lg font-bold hover:bg-neutral-800 btn-tactile flex items-center gap-1 shadow-xs">
              <span>+</span> Move to Next Dept
            </button>
            <button onclick="openJobSlipModal(${details.id})" class="px-3 py-1.5 bg-white border border-neutral-300 text-neutral-800 rounded-lg font-bold hover:bg-neutral-50 btn-tactile flex items-center gap-1 shadow-xs">
              <span>🏷️</span> Print Travel Slip
            </button>
          </div>
        </div>

        <!-- Process Routes Visualizer -->
        <div class="bg-neutral-50 p-3 rounded-lg border border-neutral-200">
          <div class="font-bold text-neutral-800 mb-2 uppercase text-[10px] tracking-wider">Production Route Progress</div>
          <div class="flex items-center gap-1 overflow-x-auto pb-1 text-center">
            ${routes.length === 0 ? '<div class="text-neutral-400 text-xs italic py-1">No custom routes assigned</div>' : routes.map((r, i) => `
              <div class="shrink-0 p-2 rounded border ${r.status === 'COMPLETED' ? 'bg-emerald-50 border-emerald-300 text-emerald-800' : (r.status === 'IN_PROGRESS' ? 'bg-blue-50 border-blue-400 text-blue-800 font-bold' : 'bg-white border-neutral-200 text-neutral-400')} text-[10px]">
                <div>${r.department_name || 'Dept'}</div>
                <div class="text-[9px] uppercase font-semibold">${r.status || 'PENDING'}</div>
              </div>
              ${i < routes.length - 1 ? '<span class="text-neutral-300 font-bold">&rarr;</span>' : ''}
            `).join("")}
          </div>
        </div>

        <!-- Karigar Speed & Piece Entries -->
        <div class="bg-white p-3 rounded-lg border border-neutral-200">
          <div class="font-bold text-neutral-800 mb-2 uppercase text-[10px] tracking-wider">Karigar Time & Speed Tracking</div>
          ${productions.length === 0 ? '<div class="text-neutral-400 text-center py-2">No karigar production entries yet</div>' : `
            <table class="w-full text-left text-xs">
              <thead class="text-neutral-400 border-b">
                <tr>
                  <th class="pb-1 font-medium">Karigar</th>
                  <th class="pb-1 font-medium">Machine</th>
                  <th class="pb-1 font-medium">Pieces</th>
                  <th class="pb-1 font-medium">Duration</th>
                  <th class="pb-1 font-medium">Speed</th>
                  <th class="pb-1 font-medium">Earned</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-neutral-100">
                ${productions.map((p) => `
                  <tr>
                    <td class="py-1.5 font-medium">${p.worker_name || '-'}</td>
                    <td class="py-1.5">${p.machine_code || '-'}</td>
                    <td class="py-1.5 font-bold">${p.pieces_completed || 0} / ${p.pieces_assigned || 0}</td>
                    <td class="py-1.5">${p.total_duration_minutes || 0} min</td>
                    <td class="py-1.5 font-bold text-blue-600">${p.production_speed_pcs_per_hr || 0} pcs/hr</td>
                    <td class="py-1.5 font-semibold text-emerald-700">₹${Number(p.total_earned || 0).toFixed(2)}</td>
                  </tr>
                `).join("")}
              </tbody>
            </table>
          `}
        </div>

        <!-- Lot Cost Sheet Breakdown -->
        ${cost ? `
          <div class="bg-amber-50/50 p-4 rounded-xl border border-amber-200">
            <div class="flex items-center justify-between mb-2">
              <span class="font-bold text-neutral-900 text-xs uppercase tracking-wider">Lot Cost Sheet Summary</span>
              <span class="font-bold text-sm text-neutral-900">Total: ₹${Number(cost.total_lot_cost || 0).toLocaleString()} (₹${Number(cost.cost_per_piece || 0).toFixed(2)} / piece)</span>
            </div>
            <div class="grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs pt-2 border-t border-amber-200/60">
              <div><span class="text-neutral-400">Fabric:</span> <span class="font-semibold">₹${cost.fabric_cost || 0}</span></div>
              <div><span class="text-neutral-400">Cutting:</span> <span class="font-semibold">₹${cost.cutting_cost || 0}</span></div>
              <div><span class="text-neutral-400">Stitching:</span> <span class="font-semibold">₹${cost.stitching_cost || 0}</span></div>
              <div><span class="text-neutral-400">Washing:</span> <span class="font-semibold">₹${cost.washing_cost || 0}</span></div>
              <div><span class="text-neutral-400">Gaaj-Button:</span> <span class="font-semibold">₹${cost.gaaj_button_cost || 0}</span></div>
              <div><span class="text-neutral-400">Press & Pack:</span> <span class="font-semibold">₹${cost.pressing_packing_cost || 0}</span></div>
              <div><span class="text-neutral-400">Accessories:</span> <span class="font-semibold">₹${cost.accessories_cost || 0}</span></div>
            </div>
          </div>
        ` : ''}
      `;
    }

    if (modal) {
      modal.classList.remove("hidden");
    }
  } catch (err) {
    console.error("Error viewing lot details:", err);
    alert("Failed to load Lot #" + lotId + " details: " + err.message);
  }
}

async function quickMoveLot(lotId, currentDeptId) {
  try {
    const modalLotDetails = document.getElementById("modal-lot-details");
    if (modalLotDetails) modalLotDetails.classList.add("hidden");

    const lots = await api.getLots();
    const depts = await api.getDepartments();

    const lotSelect = document.getElementById("movement-lot-select");
    if (lotSelect) {
      lotSelect.innerHTML = lots.map((l) => `<option value="${l.id}" ${l.id === lotId ? 'selected' : ''}>${l.lot_number} (${l.total_cut_pieces} pcs in ${l.current_department_name})</option>`).join("");
    }

    const fromDeptSelect = document.getElementById("movement-from-dept-select");
    if (fromDeptSelect) {
      fromDeptSelect.innerHTML = depts.map((d) => `<option value="${d.id}" ${d.id === currentDeptId ? 'selected' : ''}>${d.name}</option>`).join("");
    }
    
    const currentIdx = depts.findIndex(d => d.id === currentDeptId);
    const nextDept = (currentIdx >= 0 && currentIdx < depts.length - 1) ? depts[currentIdx + 1] : depts[0];
    const toDeptSelect = document.getElementById("movement-to-dept-select");
    if (toDeptSelect && nextDept) {
      toDeptSelect.innerHTML = depts.map((d) => `<option value="${d.id}" ${d.id === nextDept.id ? 'selected' : ''}>${d.name}</option>`).join("");
    }

    const lot = lots.find(l => l.id === lotId);
    if (lot) {
      const sentQtyInput = document.getElementById("movement-sent-qty-input");
      if (sentQtyInput) sentQtyInput.value = lot.total_cut_pieces;
    }
    const modalMovement = document.getElementById("modal-send-movement");
    if (modalMovement) modalMovement.classList.remove("hidden");
  } catch (err) {
    console.error("quickMoveLot error:", err);
  }
}

async function openJobSlipModal(lotId) {
  try {
    const details = await api.getLotDetails(lotId);
    if (!details) return;

    const elLotNum = document.getElementById("slip-lot-number");
    const elDate = document.getElementById("slip-cutting-date");
    const elDesign = document.getElementById("slip-design-name");
    const elPieces = document.getElementById("slip-cut-pieces");
    const elFabric = document.getElementById("slip-fabric-consumed");
    const elMaster = document.getElementById("slip-cutting-master");
    const elBarcode = document.getElementById("slip-barcode-text");

    if (elLotNum) elLotNum.textContent = details.lot_number || '';
    if (elDate) elDate.textContent = `DATE: ${details.cutting_date || new Date().toISOString().split("T")[0]}`;
    if (elDesign) elDesign.textContent = `${details.design_number || ''} - ${details.design_name || ''}`;
    if (elPieces) elPieces.textContent = `${(details.total_cut_pieces || 0).toLocaleString()} PCS`;
    if (elFabric) elFabric.textContent = `${details.meters_consumed || 0} Meters`;
    if (elMaster) elMaster.textContent = details.cutting_master_name || "Cutting Master";
    if (elBarcode) elBarcode.textContent = `*${(details.lot_number || '').replace(/[^A-Z0-9]/gi, '')}*`;

    const routesContainer = document.getElementById("slip-routes-list");
    if (routesContainer) {
      const routes = details.routes || [];
      routesContainer.innerHTML = routes.map((r, i) => `
        <div class="flex items-center justify-between p-1.5 border-b border-neutral-200">
          <span class="flex items-center gap-1.5 font-bold">
            <span>[ ${r.status === 'COMPLETED' ? '✓' : ' '} ]</span>
            <span>${i + 1}. ${r.department_name}</span>
          </span>
          <span class="text-[10px] text-neutral-500 uppercase">${r.status}</span>
        </div>
      `).join("");
    }

    const modalSlip = document.getElementById("modal-job-slip");
    if (modalSlip) modalSlip.classList.remove("hidden");
  } catch (err) {
    console.error("openJobSlipModal error:", err);
  }
}

// Bind to window object for bulletproof global accessibility
window.viewLotDetails = viewLotDetails;
window.quickMoveLot = quickMoveLot;
window.openJobSlipModal = openJobSlipModal;

// --- 5. DEPARTMENT HANDOVER & SHORTAGES ---
async function loadHandovers() {
  const lots = await api.getLots();
  const summary = await api.getDashboardSummary();
  const list = document.getElementById("pending-handovers-list");

  // Get active movements from all lots
  let pendingMovements = [];
  for (const l of lots.slice(0, 5)) {
    const details = await api.getLotDetails(l.id);
    if (details && details.movements) {
      pendingMovements = pendingMovements.concat(details.movements.filter((m) => !m.is_confirmed));
    }
  }

  if (pendingMovements.length === 0) {
    list.innerHTML = `<div class="text-neutral-400 text-center py-4">No incoming handovers pending confirmation</div>`;
  } else {
    list.innerHTML = pendingMovements.map((m) => `
      <div class="p-3 bg-neutral-50 rounded-lg border border-neutral-200 flex items-center justify-between">
        <div>
          <div class="font-bold text-neutral-900">${m.movement_number} (Lot ${m.lot_id})</div>
          <div class="text-neutral-500 text-[11px]">${m.from_dept_name} &rarr; ${m.to_dept_name}</div>
          <div class="font-semibold text-neutral-800 text-xs mt-1">Dispatched: ${m.sent_quantity} pieces</div>
        </div>
        <button onclick="openConfirmMovementModal(${m.id}, '${m.movement_number}', ${m.sent_quantity})" class="px-3 py-1.5 bg-emerald-600 text-white rounded font-semibold text-xs hover:bg-emerald-700 btn-tactile">
          Count & Confirm
        </button>
      </div>
    `).join("");
  }

  // Shortages list
  const recordedList = document.getElementById("recorded-shortages-list");
  if (!summary.recent_shortages || summary.recent_shortages.length === 0) {
    recordedList.innerHTML = `<div class="text-neutral-400 text-center py-4">No shortages logged</div>`;
  } else {
    recordedList.innerHTML = summary.recent_shortages.map((s) => `
      <div class="p-3 bg-red-50/60 rounded-lg border border-red-200">
        <div class="flex items-center justify-between">
          <span class="font-bold text-red-900 text-xs">${s.shortage_quantity} Pieces Shortage!</span>
          <span class="text-[10px] text-red-600 font-medium">Lot: ${s.lot_number}</span>
        </div>
        <div class="text-[11px] text-neutral-600 mt-0.5">Dispatched: ${s.sent_quantity} pcs | Received: ${s.received_quantity} pcs</div>
        <div class="text-[11px] text-red-800 italic mt-1">Reason: ${s.shortage_reason || 'Not specified'}</div>
      </div>
    `).join("");
  }
}

function openConfirmMovementModal(movementId, movNumber, sentQty) {
  document.getElementById("confirm-movement-id").value = movementId;
  document.getElementById("confirm-lot-num").textContent = movNumber;
  document.getElementById("confirm-sent-qty").textContent = `${sentQty} pieces`;
  document.getElementById("confirm-received-qty-input").value = sentQty;
  document.getElementById("modal-confirm-movement").classList.remove("hidden");
}

// --- 6. WORKERS & DEEP INSPECTOR ---
async function loadWorkers() {
  const workers = await api.getWorkers();
  const tbody = document.getElementById("workers-tbody");
  if (tbody) {
    if (!workers || workers.length === 0) {
      tbody.innerHTML = `<tr><td colspan="9" class="py-6 text-center text-neutral-400">No workers registered</td></tr>`;
    } else {
      tbody.innerHTML = workers.map((w) => {
        const rate = w.rate_per_piece || w.daily_wage || 0;
        const pieces = w.total_pieces_completed || 0;
        const totalSalary = w.total_salary_earned !== undefined ? w.total_salary_earned : (pieces * rate);
        const totalPaid = w.total_paid || 0;
        const pendingDue = w.pending_salary !== undefined ? w.pending_salary : (totalSalary - totalPaid);

        return `
          <tr class="hover:bg-neutral-50 cursor-pointer" onclick="selectWorkerForInspection(${w.id})">
            <td class="py-2.5 px-4 font-mono font-bold text-neutral-800">${w.worker_code}</td>
            <td class="py-2.5 px-4 font-bold text-neutral-900">${w.full_name}</td>
            <td class="py-2.5 px-4 text-neutral-600 font-medium">${w.role_designation || w.department_name || '-'}</td>
            <td class="py-2.5 px-4 font-bold text-neutral-800">₹${rate}</td>
            <td class="py-2.5 px-4 font-bold text-blue-900">${pieces.toLocaleString()} pcs</td>
            <td class="py-2.5 px-4 font-black text-emerald-800">₹${totalSalary.toLocaleString()}</td>
            <td class="py-2.5 px-4 font-bold text-neutral-700">₹${totalPaid.toLocaleString()}</td>
            <td class="py-2.5 px-4 font-black ${pendingDue > 0 ? 'text-amber-800' : 'text-emerald-700'}">₹${pendingDue.toLocaleString()}</td>
            <td class="py-2.5 px-4 text-right">
              <button onclick="event.stopPropagation(); openRecordPaymentModalForWorker(${w.id}, '${w.full_name.replace(/'/g, "\\'")}', ${pendingDue > 0 ? pendingDue : 0})" class="px-2.5 py-1 bg-neutral-900 text-white rounded text-[11px] font-bold hover:bg-neutral-800 whitespace-nowrap btn-tactile">
                + Pay
              </button>
            </td>
          </tr>
        `;
      }).join("");
    }
  }

  // Populate Employee Inspector Select
  const inspSelect = document.getElementById("inspector-worker-select");
  const datePicker = document.getElementById("inspector-date-picker");

  if (inspSelect && (!inspSelect.children.length || inspSelect.children.length === 0)) {
    inspSelect.innerHTML = workers.map((w) => `
      <option value="${w.id}">${w.full_name} (${w.worker_code} - ${w.department_name || w.role_designation})</option>
    `).join("");

    // Auto-select Dinesh Kumar (worker_id 2) or first worker
    const dinesh = workers.find((w) => w.id === 2);
    if (dinesh) {
      inspSelect.value = 2;
    }

    if (datePicker && !datePicker.value) {
      datePicker.value = new Date().toISOString().split("T")[0];
    }

    inspSelect.onchange = () => loadInspectorData();
    datePicker.onchange = () => loadInspectorData();
  }

  // Load initial inspector data
  loadInspectorData();
}

async function openRecordPaymentModalForWorker(workerId, workerName, pendingAmount) {
  const modal = document.getElementById("modal-record-payment");
  if (!modal) return;
  const workers = await api.getWorkers();
  const select = document.getElementById("payment-worker-select");
  if (select) {
    select.innerHTML = workers.map(w => `<option value="${w.id}" ${w.id === workerId ? 'selected' : ''}>${w.full_name} (${w.worker_code})</option>`).join("");
  }
  const typeSelect = document.getElementById("payee-type-select");
  if (typeSelect) {
    typeSelect.value = "WORKER";
    document.getElementById("payee-worker-group")?.classList.remove("hidden");
    document.getElementById("payee-jobber-group")?.classList.add("hidden");
  }
  const amountInput = document.getElementById("payment-amount-input");
  if (amountInput) {
    amountInput.value = pendingAmount > 0 ? pendingAmount : "";
  }
  const dateInput = document.getElementById("payment-date-input");
  if (dateInput && !dateInput.value) {
    dateInput.value = new Date().toISOString().split("T")[0];
  }
  const notesInput = document.getElementById("payment-notes-input");
  if (notesInput) {
    notesInput.value = `Khata settlement for ${workerName}`;
  }
  modal.classList.remove("hidden");
}

function selectWorkerForInspection(workerId) {
  const inspSelect = document.getElementById("inspector-worker-select");
  if (inspSelect) {
    inspSelect.value = workerId;
    loadInspectorData();
    inspSelect.scrollIntoView({ behavior: "smooth", block: "center" });
  }
}

async function loadInspectorData() {
  const workerSelect = document.getElementById("inspector-worker-select");
  const datePicker = document.getElementById("inspector-date-picker");
  if (!workerSelect || !workerSelect.value) return;

  const workerId = parseInt(workerSelect.value);
  const selectedDate = datePicker && datePicker.value ? datePicker.value : new Date().toISOString().split("T")[0];

  try {
    const res = await api.getWorkerDeepAnalytics(workerId, selectedDate);
    renderInspectorDetails(res);
  } catch (err) {
    console.error("Inspector load failed", err);
    showToast(err.message || "Failed to load worker analytics", "error");
  }
}

function renderInspectorDetails(res) {
  const w = res.worker;
  const avg = res.lifetime_averages;
  const sum = res.date_summary;

  // 1. Lifetime KPI Cards
  document.getElementById("insp-kpi-speed").textContent = `${avg.avg_speed_pcs_hr} pcs/hr`;
  document.getElementById("insp-kpi-pieces").textContent = `${avg.total_pieces.toLocaleString()} pcs`;
  document.getElementById("insp-kpi-jobs").textContent = `${avg.total_jobs}`;
  document.getElementById("insp-kpi-defect").textContent = `${avg.defect_rate_percent}%`;
  document.getElementById("insp-kpi-altered-pcs").textContent = `${avg.altered_pieces}`;
  document.getElementById("insp-kpi-earnings").textContent = `₹${avg.total_earned.toLocaleString()}`;
  document.getElementById("insp-kpi-attendance").textContent = `${avg.punctuality_percent}%`;
  document.getElementById("insp-kpi-present-days").textContent = `${avg.attendance_present_days}`;

  // 2. Selected Date Summary Ribbon
  document.getElementById("insp-display-date").textContent = res.selected_date;
  document.getElementById("insp-day-work-time").textContent = sum.net_work_hours_display;
  document.getElementById("insp-day-break-time").textContent = `${sum.total_pause_minutes} min`;
  document.getElementById("insp-day-breaks-count").textContent = sum.breaks_count;
  document.getElementById("insp-day-speed").textContent = `${sum.day_speed_pcs_hr} pcs/hr`;

  // Badges
  const breaksBadge = document.getElementById("insp-breaks-badge");
  if (breaksBadge) breaksBadge.textContent = `${sum.breaks_count} Breaks (${sum.total_pause_minutes}m)`;

  const jobsBadge = document.getElementById("insp-jobs-badge");
  if (jobsBadge) jobsBadge.textContent = `${sum.jobs_count} Lots (${sum.day_pieces} Pcs)`;

  // 3. Breaks Timeline List
  const breaksContainer = document.getElementById("insp-breaks-timeline");
  if (!res.date_breaks || res.date_breaks.length === 0) {
    breaksContainer.innerHTML = `<div class="text-neutral-400 text-center py-6 bg-white rounded-lg border border-neutral-100">No breaks taken on this date. Worker operated continuously.</div>`;
  } else {
    breaksContainer.innerHTML = res.date_breaks.map((b) => {
      const startTime = b.started_at ? new Date(b.started_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '--';
      const endTime = b.ended_at ? new Date(b.ended_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : 'Ongoing';
      
      let badgeColor = "bg-amber-100 text-amber-900 border-amber-200";
      let icon = "⏸";
      if (b.break_reason.includes("Machine") || b.break_reason.includes("Thread")) {
        badgeColor = "bg-rose-100 text-rose-900 border-rose-200";
        icon = "⚙️";
      } else if (b.break_reason.includes("Lunch") || b.break_reason.includes("ભોજન")) {
        badgeColor = "bg-amber-100 text-amber-900 border-amber-200";
        icon = "🍲";
      } else if (b.break_reason.includes("Tea") || b.break_reason.includes("ચા")) {
        badgeColor = "bg-orange-100 text-orange-900 border-orange-200";
        icon = "☕";
      } else if (b.break_reason.includes("Material") || b.break_reason.includes("માલ")) {
        badgeColor = "bg-blue-100 text-blue-900 border-blue-200";
        icon = "📦";
      }

      return `
        <div class="p-3 bg-white rounded-xl border border-neutral-200 shadow-2xs space-y-1">
          <div class="flex items-center justify-between">
            <span class="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[11px] font-bold border ${badgeColor}">
              <span>${icon}</span>
              <span>${b.break_reason}</span>
            </span>
            <span class="font-bold text-neutral-900 text-xs">${b.duration_minutes} Minutes</span>
          </div>
          <div class="flex items-center justify-between text-[11px] text-neutral-500 pt-1">
            <span>Interval: <strong class="text-neutral-800">${startTime} &rarr; ${endTime}</strong></span>
            <span>${b.lot_number ? `Lot: <strong>${b.lot_number}</strong>` : ''}</span>
          </div>
        </div>
      `;
    }).join("");
  }

  // 4. Jobs & Bundles Stitched List
  const jobsContainer = document.getElementById("insp-jobs-timeline");
  if (!res.date_jobs || res.date_jobs.length === 0) {
    jobsContainer.innerHTML = `<div class="text-neutral-400 text-center py-6 bg-white rounded-lg border border-neutral-100">No production jobs logged for this date.</div>`;
  } else {
    jobsContainer.innerHTML = res.date_jobs.map((j) => {
      const isComp = j.status === "COMPLETED";
      const statusPill = isComp
        ? `<span class="px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 text-[10px] font-bold">COMPLETED</span>`
        : `<span class="px-2 py-0.5 rounded bg-amber-100 text-amber-800 text-[10px] font-bold">IN PROGRESS</span>`;

      const startTime = j.start_time ? new Date(j.start_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '--';
      const completeTime = j.complete_time ? new Date(j.complete_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : (isComp ? '--' : 'Active');

      const bundlesDisplay = (j.bundles_count > 0 || j.loose_pieces > 0)
        ? `<div class="text-[11px] font-semibold text-neutral-700 mt-1">📦 Bundles: <span class="text-blue-900 font-bold">${j.bundles_count} Bundles</span> × ${j.bundle_size || 20} + <span class="text-blue-900 font-bold">${j.loose_pieces} Loose</span> = <span class="font-black text-neutral-900">${j.pieces_completed} Pcs</span></div>`
        : `<div class="text-[11px] text-neutral-600 mt-1">${j.pieces_completed} of ${j.pieces_assigned} pieces stitched</div>`;

      return `
        <div class="p-3 bg-white rounded-xl border border-neutral-200 shadow-2xs space-y-1.5">
          <div class="flex items-center justify-between">
            <span class="font-bold text-neutral-900 text-xs">${j.lot_number} — ${j.design_name}</span>
            ${statusPill}
          </div>
          ${bundlesDisplay}
          <div class="flex items-center justify-between text-[11px] text-neutral-500 pt-1 border-t border-neutral-100">
            <span>Time: <strong>${startTime} - ${completeTime}</strong> (${j.total_duration_minutes || 0}m net)</span>
            <div class="flex items-center gap-2">
              <span class="font-bold text-blue-700">${j.production_speed_pcs_per_hr || 0.0} pcs/hr</span>
              <span class="text-neutral-300">|</span>
              <span class="font-bold text-emerald-700">₹${(j.total_earned || 0).toFixed(2)}</span>
            </div>
          </div>
        </div>
      `;
    }).join("");
  }
}

// --- 7. JOBBERS & MACHINES ---
let cachedDetailedJobbers = [];

async function loadJobbersAndMachines() {
  try {
    const detailedJobbers = await api.getDetailedJobbers();
    const machines = await api.getMachines();
    cachedDetailedJobbers = detailedJobbers || [];

    // 1. Top 4 Summary Cards
    const totalJobbers = cachedDetailedJobbers.length;
    const totalMachines = machines.length;
    let allKarigars = [];
    let allLots = [];
    let totalMarginSum = 0;

    cachedDetailedJobbers.forEach((j) => {
      totalMarginSum += (j.jobber_margin_per_piece || 0);
      if (j.karigars) {
        j.karigars.forEach((k) => allKarigars.push({ ...k, jobber_name: j.name, jobber_id: j.id }));
      }
      if (j.active_lots) {
        j.active_lots.forEach((l) => allLots.push({ ...l, jobber_name: j.name, jobber_id: j.id }));
      }
    });

    const avgMargin = totalJobbers > 0 ? (totalMarginSum / totalJobbers).toFixed(2) : "0.00";

    const countEl = document.getElementById("jobber-summary-count");
    const machEl = document.getElementById("jobber-summary-machines");
    const karEl = document.getElementById("jobber-summary-karigars");
    const margEl = document.getElementById("jobber-summary-margin");

    if (countEl) countEl.textContent = totalJobbers;
    if (machEl) machEl.textContent = totalMachines;
    if (karEl) karEl.textContent = allKarigars.length;
    if (margEl) margEl.textContent = `₹${avgMargin} /pc`;

    // 2. Jobber Rate & Margin Cards (#jobbers-detailed-cards)
    const cardsContainer = document.getElementById("jobbers-detailed-cards");
    if (cardsContainer) {
      if (cachedDetailedJobbers.length === 0) {
        cardsContainer.innerHTML = `<div class="col-span-2 py-6 text-center text-neutral-400">${t("no_jobbers_found")}</div>`;
      } else {
        cardsContainer.innerHTML = cachedDetailedJobbers.map((j) => `
          <div class="p-4 rounded-xl border border-neutral-200 bg-neutral-50/60 hover:bg-white transition-all space-y-3">
            <div class="flex items-start justify-between">
              <div>
                <div class="font-black text-sm text-neutral-900 flex items-center gap-2">
                  <span>${j.name}</span>
                  <span class="px-2 py-0.5 rounded text-[10px] font-bold bg-neutral-200 text-neutral-800">${j.machine_count || 0} Machines</span>
                </div>
                <div class="text-xs text-neutral-500 mt-0.5">${j.phone || 'No phone'} • ${j.workshop_address || 'In-house'}</div>
              </div>
              <div class="text-right">
                <span class="text-[10px] font-bold uppercase text-neutral-400">Total Net Profit</span>
                <div class="text-base font-black text-emerald-700">₹${(j.jobber_net_profit || 0).toLocaleString()}</div>
              </div>
            </div>

            <div class="grid grid-cols-3 gap-2 bg-white p-2.5 rounded-lg border border-neutral-200 text-center">
              <div>
                <div class="text-[10px] font-bold text-neutral-400 uppercase">Factory Rate</div>
                <div class="text-sm font-black text-neutral-800">₹${j.stitching_rate_default || 48}/pc</div>
              </div>
              <div>
                <div class="text-[10px] font-bold text-neutral-400 uppercase">Avg Karigar Rate</div>
                <div class="text-sm font-black text-blue-800">₹${j.avg_karigar_rate || 32}/pc</div>
              </div>
              <div>
                <div class="text-[10px] font-bold text-neutral-400 uppercase">Jobber Margin</div>
                <div class="text-sm font-black text-amber-700">₹${j.jobber_margin_per_piece || 16}/pc</div>
              </div>
            </div>

            <div class="flex items-center justify-between text-xs text-neutral-600 pt-1 border-t border-neutral-200">
              <span>Active Lots: <strong>${j.active_lots ? j.active_lots.length : 0}</strong></span>
              <span>Karigars: <strong>${j.karigars ? j.karigars.length : 0}</strong></span>
              <span>Pieces Done: <strong>${(j.total_pieces_completed || 0).toLocaleString()}</strong></span>
            </div>
          </div>
        `).join("");
      }
    }

    // 3. Populate Jobber Filter Select
    const filterSelect = document.getElementById("filter-jobber-karigar-select");
    if (filterSelect) {
      filterSelect.innerHTML = `<option value="ALL">${t("all_jobbers_opt")}</option>` +
        cachedDetailedJobbers.map(j => `<option value="${j.id}">${j.name}</option>`).join("");
    }

    // 4. Render Deep Karigar Speed & Earnings Table
    renderJobberKarigarsTable(allKarigars);

    // 5. Render Active Lots in Jobbers Table
    const lotsTbody = document.getElementById("jobber-lots-active-tbody");
    if (lotsTbody) {
      if (allLots.length === 0) {
        lotsTbody.innerHTML = `<tr><td colspan="6" class="py-6 text-center text-neutral-400">${t("no_active_stitching_lots")}</td></tr>`;
      } else {
        lotsTbody.innerHTML = allLots.map((l) => {
          const totalPieces = l.total_cut_pieces || 1;
          const donePieces = l.pieces_completed || 0;
          const assignedPieces = l.pieces_assigned || totalPieces;
          const pct = Math.min(100, Math.round((donePieces / totalPieces) * 100));

          return `
            <tr class="hover:bg-neutral-50">
              <td class="py-2.5 px-3 font-mono font-bold text-neutral-900">${l.lot_number}</td>
              <td class="py-2.5 px-3 font-semibold">${l.design_name || 'Design'} (${l.design_number || 'AX'})</td>
              <td class="py-2.5 px-3 font-black text-blue-900">${totalPieces.toLocaleString()} pcs</td>
              <td class="py-2.5 px-3 font-bold text-neutral-800">${assignedPieces.toLocaleString()} pcs</td>
              <td class="py-2.5 px-3 font-bold text-emerald-700">${donePieces.toLocaleString()} pcs</td>
              <td class="py-2.5 px-3">
                <div class="flex items-center gap-2">
                  <div class="w-20 bg-neutral-200 h-2 rounded-full overflow-hidden">
                    <div class="bg-emerald-600 h-full rounded-full" style="width: ${pct}%"></div>
                  </div>
                  <span class="text-[10px] font-bold text-neutral-700">${pct}%</span>
                </div>
              </td>
            </tr>
          `;
        }).join("");
      }
    }

    // 6. Render Machines Grid
    const mGrid = document.getElementById("machines-grid");
    if (mGrid) {
      mGrid.innerHTML = machines.map((m) => `
        <div class="p-2.5 rounded-lg border border-neutral-200 bg-white flex flex-col justify-between hover:border-neutral-400 transition-all">
          <div class="flex items-center justify-between">
            <span class="font-black text-neutral-900">${m.machine_code}</span>
            <span class="w-2 h-2 rounded-full ${m.is_active ? 'bg-emerald-500' : 'bg-red-400'}"></span>
          </div>
          <div class="text-[10px] text-neutral-500 truncate mt-1">${m.machine_type}</div>
          <div class="text-[10px] font-bold text-neutral-700 mt-1">${m.jobber_name || 'In-House'}</div>
        </div>
      `).join("");
    }
  } catch (err) {
    console.error("Jobbers load failed:", err);
  }
}

function filterJobberKarigarsTable() {
  const filterSelectEl = document.getElementById("filter-jobber-karigar-select");
  if (filterSelectEl && filterSelectEl.options && filterSelectEl.options.length > 0) {
    filterSelectEl.options[0].text = t('all_jobbers_opt');
  }
  const filterSelect = document.getElementById("filter-jobber-karigar-select");
  const selectedVal = filterSelect ? filterSelect.value : "ALL";

  let list = [];
  cachedDetailedJobbers.forEach((j) => {
    if (selectedVal === "ALL" || j.id.toString() === selectedVal) {
      if (j.karigars) {
        j.karigars.forEach((k) => list.push({ ...k, jobber_name: j.name, jobber_id: j.id }));
      }
    }
  });

  renderJobberKarigarsTable(list);
}

function renderJobberKarigarsTable(karigars) {
  const tbody = document.getElementById("jobber-karigars-deep-tbody");
  if (!tbody) return;

  if (karigars.length === 0) {
    tbody.innerHTML = `<tr><td colspan="8" class="py-6 text-center text-neutral-400">${t("no_karigar_records")}</td></tr>`;
    return;
  }

  tbody.innerHTML = karigars.map((k) => {
    const speed = k.avg_speed_pcs_hr || 0;
    let badgeClass = "bg-neutral-100 text-neutral-700";
    let speedIcon = "⏱️";
    if (speed >= 12) {
      badgeClass = "bg-emerald-100 text-emerald-900 border border-emerald-300";
      speedIcon = "⚡ Fast";
    } else if (speed >= 7) {
      badgeClass = "bg-blue-100 text-blue-900 border border-blue-200";
      speedIcon = "👍 Normal";
    } else if (speed > 0) {
      badgeClass = "bg-amber-100 text-amber-900 border border-amber-200";
      speedIcon = "⚠️ Slow";
    }

    return `
      <tr class="hover:bg-neutral-50">
        <td class="py-2.5 px-3 font-mono font-bold text-neutral-800">${k.worker_code}</td>
        <td class="py-2.5 px-3 font-bold text-neutral-900">${k.full_name}</td>
        <td class="py-2.5 px-3 font-semibold text-neutral-700">${k.jobber_name || 'Direct'}</td>
        <td class="py-2.5 px-3 font-mono font-bold text-neutral-600">${k.machine_code || 'M-??'}</td>
        <td class="py-2.5 px-3 font-bold text-emerald-800">₹${k.rate_paid_by_jobber || 32}/pc</td>
        <td class="py-2.5 px-3 font-bold text-neutral-900">${(k.pieces_completed || 0).toLocaleString()} pcs</td>
        <td class="py-2.5 px-3">
          <span class="px-2 py-0.5 rounded text-[11px] font-black inline-flex items-center gap-1 ${badgeClass}">
            <span>${speed > 0 ? speed.toFixed(1) : '0.0'} pcs/hr</span>
            <span class="text-[9px] font-normal opacity-80">(${speedIcon})</span>
          </span>
        </td>
        <td class="py-2.5 px-3 font-black text-emerald-700">₹${(k.total_earned || 0).toLocaleString()}</td>
      </tr>
    `;
  }).join("");
}

// --- 8. COSTING & PAYMENTS ---
async function loadCostingAndPayments() {
  const lots = await api.getLots();
  const payments = await api.getPayments();

  // Load Lot Cost Sheets
  const costTbody = document.getElementById("cost-sheets-tbody");
  const costRows = [];
  for (const l of lots) {
    const sheet = await api.getLotCostSheet(l.id).catch(() => null);
    if (sheet) {
      costRows.push(`
        <tr class="hover:bg-neutral-50">
          <td class="py-2.5 px-4 font-bold text-neutral-900">${sheet.lot_number}</td>
          <td class="py-2.5 px-4 font-semibold">${sheet.total_cut_pieces}</td>
          <td class="py-2.5 px-4">₹${sheet.fabric_cost.toFixed(2)}</td>
          <td class="py-2.5 px-4">₹${sheet.cutting_cost.toFixed(2)}</td>
          <td class="py-2.5 px-4">₹${sheet.stitching_cost.toFixed(2)}</td>
          <td class="py-2.5 px-4">₹${(sheet.washing_cost + sheet.gaaj_button_cost + sheet.pressing_packing_cost).toFixed(2)}</td>
          <td class="py-2.5 px-4 font-bold">₹${sheet.total_lot_cost.toFixed(2)}</td>
          <td class="py-2.5 px-4 font-bold text-emerald-700">₹${sheet.cost_per_piece.toFixed(2)}</td>
        </tr>
      `);
    }
  }
  costTbody.innerHTML = costRows.length > 0 ? costRows.join("") : `<tr><td colspan="8" class="py-4 text-center text-neutral-400">No cost sheets available</td></tr>`;

  // Load Payments
  const payTbody = document.getElementById("payments-tbody");
  payTbody.innerHTML = payments.length > 0 ? payments.map((p) => `
    <tr class="hover:bg-neutral-50">
      <td class="py-2.5 px-4">${p.payment_date}</td>
      <td class="py-2.5 px-4 font-medium">${p.worker_name || p.jobber_name}</td>
      <td class="py-2.5 px-4 text-neutral-500">${p.payee_type}</td>
      <td class="py-2.5 px-4 font-bold text-neutral-900">₹${p.amount_paid.toFixed(2)}</td>
      <td class="py-2.5 px-4"><span class="px-2 py-0.5 rounded bg-neutral-100 text-[10px] font-semibold">${p.payment_mode}</span></td>
      <td class="py-2.5 px-4 text-neutral-500">${p.notes || '-'}</td>
    </tr>
  `).join("") : `<tr><td colspan="6" class="py-4 text-center text-neutral-400">No payments recorded</td></tr>`;
}

// --- 9. GODOWN & STOCK ---
async function loadGodownStock() {
  const stock = await api.getFinishedStock();
  const tbody = document.getElementById("stock-tbody");

  if (stock.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" class="py-6 text-center text-neutral-400">No finished goods in godown yet</td></tr>`;
    return;
  }

  tbody.innerHTML = stock.map((s) => `
    <tr class="hover:bg-neutral-50">
      <td class="py-2.5 px-4 font-bold text-neutral-900">${s.design_number}</td>
      <td class="py-2.5 px-4 font-medium">${s.design_name}</td>
      <td class="py-2.5 px-4 text-neutral-500">${s.fabric_type || '-'}</td>
      <td class="py-2.5 px-4">${s.lot_number || '-'}</td>
      <td class="py-2.5 px-4 font-bold text-emerald-700 text-sm">${s.available_pieces.toLocaleString()} pcs</td>
      <td class="py-2.5 px-4 font-semibold text-neutral-800">${s.packed_boxes} boxes</td>
      <td class="py-2.5 px-4 text-neutral-400 text-[11px]">${new Date(s.last_updated).toLocaleDateString()}</td>
    </tr>
  `).join("");
}

// --- 10. REPORTS & ANALYTICS (EXECUTIVE TIME-FILTERED HUB) ---
let currentAnalyticsScope = "this_month";
let customAnalyticsStartDate = null;
let customAnalyticsEndDate = null;
let currentAnalyticsData = null;

function setAnalyticsPeriod(period) {
  currentAnalyticsScope = period;
  customAnalyticsStartDate = null;
  customAnalyticsEndDate = null;

  document.querySelectorAll("#analytics-period-pills button").forEach((btn) => {
    if (btn.getAttribute("data-period") === period) {
      btn.className = "period-btn px-3 py-1.5 rounded-lg bg-white text-neutral-900 shadow-xs font-bold";
    } else {
      btn.className = "period-btn px-3 py-1.5 rounded-lg text-neutral-600 hover:text-neutral-900";
    }
  });

  const scopeLabels = {
    today: "Today",
    this_week: "This Week",
    this_month: "This Month",
    last_month: "Last Month",
    this_year: "FY 2026",
    all: "All Time"
  };
  const labelEl = document.getElementById("analytics-scope-label");
  if (labelEl) labelEl.textContent = scopeLabels[period] || period;

  loadReportsAndAnalytics();
}

function applyCustomAnalyticsDate() {
  const start = document.getElementById("analytics-start-date")?.value;
  const end = document.getElementById("analytics-end-date")?.value;
  if (!start || !end) {
    showToast("Please select both From and To dates", "warning");
    return;
  }
  currentAnalyticsScope = "custom";
  customAnalyticsStartDate = start;
  customAnalyticsEndDate = end;

  document.querySelectorAll("#analytics-period-pills button").forEach((btn) => {
    btn.className = "period-btn px-3 py-1.5 rounded-lg text-neutral-600 hover:text-neutral-900";
  });

  const labelEl = document.getElementById("analytics-scope-label");
  if (labelEl) labelEl.textContent = `${start} to ${end}`;
  loadReportsAndAnalytics();
}

function getAnalyticsDateRange(scope) {
  const now = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  const formatDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;

  if (scope === "custom" && customAnalyticsStartDate && customAnalyticsEndDate) {
    return { startDate: customAnalyticsStartDate, endDate: customAnalyticsEndDate };
  }

  if (scope === "today") {
    const todayStr = formatDate(now);
    return { startDate: todayStr, endDate: todayStr };
  } else if (scope === "this_week") {
    const day = now.getDay() || 7;
    const monday = new Date(now);
    monday.setDate(now.getDate() - day + 1);
    return { startDate: formatDate(monday), endDate: formatDate(now) };
  } else if (scope === "this_month") {
    const firstDay = new Date(now.getFullYear(), now.getMonth(), 1);
    return { startDate: formatDate(firstDay), endDate: formatDate(now) };
  } else if (scope === "last_month") {
    const firstDay = new Date(now.getFullYear(), now.getMonth() - 1, 1);
    const lastDay = new Date(now.getFullYear(), now.getMonth(), 0);
    return { startDate: formatDate(firstDay), endDate: formatDate(lastDay) };
  } else if (scope === "this_year") {
    return { startDate: `${now.getFullYear()}-01-01`, endDate: `${now.getFullYear()}-12-31` };
  }
  return { startDate: null, endDate: null };
}

async function loadReportsAndAnalytics() {
  const { startDate, endDate } = getAnalyticsDateRange(currentAnalyticsScope);
  const data = await api.getAnalyticsReport(startDate, endDate);
  currentAnalyticsData = data;

  // 1. Update KPI ribbon
  const kpis = data.summary_kpis || {};
  const kpiPieces = document.getElementById("kpi-prod-pieces");
  if (kpiPieces) kpiPieces.textContent = (kpis.total_pieces_produced || 0).toLocaleString();
  
  const kpiSpeed = document.getElementById("kpi-avg-speed");
  if (kpiSpeed) kpiSpeed.textContent = `${kpis.overall_avg_speed || 0.0} pcs/hr`;
  
  const kpiKarigars = document.getElementById("kpi-active-karigars");
  if (kpiKarigars) kpiKarigars.textContent = kpis.active_workers_count || 0;
  
  const kpiWages = document.getElementById("kpi-wages-earned");
  if (kpiWages) kpiWages.textContent = `₹${(kpis.total_wages_earned || 0).toLocaleString()}`;
  
  const kpiDefect = document.getElementById("kpi-defect-rate");
  if (kpiDefect) kpiDefect.textContent = `${kpis.defect_rate_percent || 0.0}%`;
  
  const kpiAltered = document.getElementById("kpi-altered-pieces");
  if (kpiAltered) kpiAltered.textContent = kpis.total_altered_pieces || 0;
  
  const kpiGodown = document.getElementById("kpi-finished-stock");
  if (kpiGodown) {
    const totalStock = (data.stock_by_design || []).reduce((acc, s) => acc + (s.available_pieces || 0), 0);
    kpiGodown.textContent = totalStock.toLocaleString();
  }

  // 2. Chart 1: Daily Production Output Trend
  const ctxDaily = document.getElementById("chart-daily-trend")?.getContext("2d");
  if (ctxDaily) {
    if (charts.daily) charts.daily.destroy();
    const trendLabels = (data.daily_trend && data.daily_trend.length > 0)
      ? data.daily_trend.map(t => t.date.slice(5))
      : ["2026-11-20", "2026-11-21", "2026-11-22", "2026-11-23", "2026-11-24", "2026-11-25"].map(d => d.slice(5));
    const trendData = (data.daily_trend && data.daily_trend.length > 0)
      ? data.daily_trend.map(t => t.pieces_completed)
      : [0, 0, 0, 0, 0, 0];

    charts.daily = new Chart(ctxDaily, {
      type: "line",
      data: {
        labels: trendLabels,
        datasets: [{
          label: "Shirts Stitched",
          data: trendData,
          borderColor: "#18181B",
          backgroundColor: "rgba(24, 24, 27, 0.08)",
          fill: true,
          tension: 0.35,
          borderWidth: 2.5,
          pointRadius: 4,
          pointBackgroundColor: "#18181B"
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, title: { display: true, text: "Pieces Completed" } } }
      }
    });
  }

  // 3. Chart 2: Karigar Production Speed Leaderboard
  const ctxSpeed = document.getElementById("chart-karigar-speed")?.getContext("2d");
  if (ctxSpeed) {
    if (charts.speed) charts.speed.destroy();
    charts.speed = new Chart(ctxSpeed, {
      type: "bar",
      data: {
        labels: data.karigar_performance.map((k) => k.karigar_name),
        datasets: [{
          label: "Avg Speed (Pcs / Hour)",
          data: data.karigar_performance.map((k) => k.avg_speed_pcs_hr),
          backgroundColor: "#18181B",
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, title: { display: true, text: "Pieces / Hour" } } }
      }
    });
  }

  // 4. Chart 3: Defects & Alteration Analysis
  const ctxDefect = document.getElementById("chart-defect-analysis")?.getContext("2d");
  if (ctxDefect) {
    if (charts.defects) charts.defects.destroy();
    const defectLabels = (data.alterations_by_defect && data.alterations_by_defect.length > 0)
      ? data.alterations_by_defect.map(d => d.defect_type)
      : ["STITCHING", "SIZING", "FABRIC_DEFECT", "WASH_FINISH"];
    const defectCounts = (data.alterations_by_defect && data.alterations_by_defect.length > 0)
      ? data.alterations_by_defect.map(d => d.total_pieces)
      : [0, 0, 0, 0];

    charts.defects = new Chart(ctxDefect, {
      type: "doughnut",
      data: {
        labels: defectLabels,
        datasets: [{
          data: defectCounts,
          backgroundColor: ["#EF4444", "#F59E0B", "#3B82F6", "#8B5CF6", "#10B981"]
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { position: "right" } }
      }
    });
  }

  // 5. Chart 4: Department Pieces Distribution
  const ctxDept = document.getElementById("chart-dept-distribution")?.getContext("2d");
  if (ctxDept) {
    if (charts.dept) charts.dept.destroy();
    charts.dept = new Chart(ctxDept, {
      type: "bar",
      data: {
        labels: data.lots_by_dept.map((d) => d.department_name),
        datasets: [{
          label: "Pieces in Department",
          data: data.lots_by_dept.map((d) => d.total_pieces_in_dept),
          backgroundColor: "#C59A6F",
          borderRadius: 6
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: { legend: { display: false } }
      }
    });
  }
}

// Multi-Report Targeted CSV Exporters
function exportSpecializedCSV(reportType) {
  if (!currentAnalyticsData) {
    showToast("Please wait for analytics data to load", "warning");
    return;
  }
  const dateStamp = new Date().toISOString().split("T")[0];

  if (reportType === "production") {
    const rows = currentAnalyticsData.production_logs || [];
    let csv = "Job ID,Work Date,Lot Number,Design Style,Department,Worker Name,Worker Code,Machine,Pieces Assigned,Pieces Done,Altered,Duration (Min),Speed (Pcs/Hr),Wages Earned (INR),Status\n";
    rows.forEach(r => {
      csv += `"${r.id}","${r.work_date || ''}","${r.lot_number}","${r.design_name}","${r.department_name}","${r.worker_name}","${r.worker_code}","${r.machine_code || '-'}","${r.pieces_assigned}","${r.pieces_completed}","${r.pieces_altered}","${r.total_duration_minutes || 0}","${r.production_speed_pcs_per_hr || 0}","${r.total_earned || 0}","${r.status}"\n`;
    });
    downloadCSV(csv, `AXIL_Production_Log_${dateStamp}.csv`);
    showToast("Production log exported successfully");
  } else if (reportType === "orders") {
    const rows = currentAnalyticsData.orders_logs || [];
    let csv = "Order Number,Customer Name,City,Design Style,Order Quantity,Order Date,Delivery Due Date,Status,Priority,Transport Name,LR Number,Parcels Count,Dispatch Date\n";
    rows.forEach(r => {
      csv += `"${r.order_number}","${r.customer_name}","${r.customer_city || ''}","${r.design_name}","${r.total_quantity}","${r.order_date}","${r.delivery_due_date}","${r.current_status}","${r.priority}","${r.transport_name || ''}","${r.tracking_lr_number || ''}","${r.parcel_count || ''}","${r.dispatch_date || ''}"\n`;
    });
    downloadCSV(csv, `AXIL_Orders_Dispatches_${dateStamp}.csv`);
    showToast("Orders & dispatches report exported successfully");
  } else if (reportType === "payroll") {
    const rows = currentAnalyticsData.workers_khata_logs || [];
    let csv = "Worker Code,Full Name,Department,Days Present,Overtime Hours,Total Pieces Done,Piece Rate (INR),Daily Wage (INR),Gross Earnings (INR),Advances Deducted (INR),Net Payable (INR)\n";
    rows.forEach(r => {
      csv += `"${r.worker_code}","${r.full_name}","${r.department_name || '-'}","${r.days_present}","${r.total_ot_hours}","${r.total_pieces}","${r.rate_per_piece || 0}","${r.daily_wage || 0}","${r.gross_earned}","${r.total_advances_paid}","${r.net_payable}"\n`;
    });
    downloadCSV(csv, `AXIL_Worker_Payroll_Khata_${dateStamp}.csv`);
    showToast("Payroll ledger exported successfully");
  } else if (reportType === "costing") {
    const rows = currentAnalyticsData.cost_breakdowns || [];
    let csv = "Lot Number,Design Name,Total Cut Pieces,Fabric Cost (INR),Cutting Cost (INR),Stitching Cost (INR),Washing Cost (INR),Gaaj Button Cost (INR),Pressing Packing Cost (INR),Accessories (INR),Total Lot Cost (INR),Cost Per Piece (INR)\n";
    rows.forEach(r => {
      csv += `"${r.lot_number}","${r.design_name}","${r.total_cut_pieces}","${r.fabric_cost}","${r.cutting_cost}","${r.stitching_cost}","${r.washing_cost}","${r.gaaj_button_cost}","${r.pressing_packing_cost}","${r.accessories_cost}","${r.total_lot_cost}","${r.cost_per_piece}"\n`;
    });
    downloadCSV(csv, `AXIL_Cost_Sheets_Margins_${dateStamp}.csv`);
    showToast("Cost sheets exported successfully");
  }
}

function downloadCSV(csvContent, fileName) {
  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = fileName;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

function exportReportsCSV() {
  exportSpecializedCSV('production');
}

// --- 11. FACTORY SETUP & MASTERS ---
async function loadMasters() {
  const designs = await api.getDesigns();
  const fabrics = await api.getFabricInward();
  const customers = await api.getCustomers();

  document.getElementById("masters-designs-list").innerHTML = designs.map((d) => `
    <div class="p-2.5 bg-neutral-50 rounded border border-neutral-200">
      <div class="font-bold text-neutral-900">${d.design_number} - ${d.name}</div>
      <div class="text-neutral-500">${d.fabric_type} | Cut: ₹${d.standard_cutting_rate} | Stitch: ₹${d.standard_stitching_rate}</div>
    </div>
  `).join("");

  document.getElementById("masters-fabric-list").innerHTML = fabrics.map((f) => `
    <div class="p-2.5 bg-neutral-50 rounded border border-neutral-200">
      <div class="font-bold text-neutral-900">${f.inward_number} - ${f.fabric_type}</div>
      <div class="text-neutral-500">${f.meters_received}m received | ₹${f.rate_per_meter}/m</div>
    </div>
  `).join("");

  document.getElementById("masters-customers-list").innerHTML = customers.map((c) => `
    <div class="p-2.5 bg-neutral-50 rounded border border-neutral-200">
      <div class="font-bold text-neutral-900">${c.customer_name} (${c.city || ''})</div>
      <div class="text-neutral-500">${c.phone} | ${c.shop_name || ''}</div>
    </div>
  `).join("");
}

// --- MODALS CONTROLLER & POPULATORS (ALL AUDITED & FULLY FUNCTIONAL) ---
function initModals() {
  document.querySelectorAll(".modal-close-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll("#modals-container > div, [id^='modal-']").forEach((m) => m.classList.add("hidden"));
    });
  });

  // Close modals on clicking the dark backdrop
  document.querySelectorAll("[id^='modal-']").forEach((modal) => {
    modal.addEventListener("click", (e) => {
      if (e.target === modal) {
        modal.classList.add("hidden");
      }
    });
  });



  // 3. Open New Lot Modal
  document.getElementById("open-new-lot-modal-btn")?.addEventListener("click", async () => {
    const designs = await api.getDesigns();
    const fabrics = await api.getFabricInward();
    const workers = await api.getWorkers();

    document.getElementById("lot-design-select").innerHTML = designs.map((d) => `<option value="${d.id}">${d.design_number} - ${d.name}</option>`).join("");
    document.getElementById("lot-fabric-select").innerHTML = fabrics.map((f) => `<option value="${f.id}">${f.inward_number} (${f.remaining_meters}m available)</option>`).join("");
    document.getElementById("lot-cutter-select").innerHTML = workers.map((w) => `<option value="${w.id}">${w.full_name} (${w.role_designation})</option>`).join("");
    document.getElementById("lot-number-input").value = `LOT-${new Date().getFullYear()}-${Date.now().toString().slice(-4)}`;
    document.getElementById("modal-new-lot").classList.remove("hidden");
  });

  // Submit New Lot
  document.getElementById("form-new-lot")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    await api.createLot({
      lot_number: document.getElementById("lot-number-input").value,
      design_id: parseInt(document.getElementById("lot-design-select").value),
      fabric_inward_id: parseInt(document.getElementById("lot-fabric-select").value),
      total_cut_pieces: parseInt(document.getElementById("lot-cut-pieces-input").value),
      meters_consumed: parseFloat(document.getElementById("lot-meters-input").value || 0),
      cutting_master_worker_id: parseInt(document.getElementById("lot-cutter-select").value),
      cutting_date: new Date().toISOString().split("T")[0]
    });
    showToast("Lot created and process route built");
    document.getElementById("modal-new-lot").classList.add("hidden");
    loadLots();
  });

  // 4. Open Send Movement Modal
  document.getElementById("open-send-movement-modal-btn")?.addEventListener("click", async () => {
    const lots = await api.getLots();
    const depts = await api.getDepartments();

    document.getElementById("movement-lot-select").innerHTML = lots.map((l) => `<option value="${l.id}">${l.lot_number} (${l.total_cut_pieces} pcs in ${l.current_department_name})</option>`).join("");
    document.getElementById("movement-from-dept-select").innerHTML = depts.map((d) => `<option value="${d.id}">${d.name}</option>`).join("");
    document.getElementById("movement-to-dept-select").innerHTML = depts.map((d) => `<option value="${d.id}">${d.name}</option>`).join("");
    document.getElementById("modal-send-movement").classList.remove("hidden");
  });

  // Submit Send Movement
  document.getElementById("form-send-movement")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    try {
      await api.sendMovement({
        lot_id: parseInt(document.getElementById("movement-lot-select").value),
        from_department_id: parseInt(document.getElementById("movement-from-dept-select").value),
        to_department_id: parseInt(document.getElementById("movement-to-dept-select").value),
        sent_quantity: parseInt(document.getElementById("movement-sent-qty-input").value)
      });
      showToast("Pieces dispatched to next department");
      document.getElementById("modal-send-movement").classList.add("hidden");
      loadHandovers();
    } catch (err) {
      showToast(err.message, "error");
    }
  });

  // 5. Submit Confirm Movement Handover
  document.getElementById("form-confirm-movement")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const movId = parseInt(document.getElementById("confirm-movement-id").value);
    const qty = parseInt(document.getElementById("confirm-received-qty-input").value);
    const reason = document.getElementById("confirm-shortage-reason-input").value;

    await api.confirmMovement({
      movement_id: movId,
      received_by_worker_id: 1,
      received_quantity: qty,
      shortage_reason: reason
    });
    showToast("Handover counted and confirmed");
    document.getElementById("modal-confirm-movement").classList.add("hidden");
    loadHandovers();
  });

  // 6. Open Record Payment Modal (AUDITED & WIRED)
  document.getElementById("open-record-payment-modal-btn")?.addEventListener("click", async () => {
    const workers = await api.getWorkers();
    const jobbers = await api.getJobbers();

    document.getElementById("payment-worker-select").innerHTML = workers.map(w => `<option value="${w.id}">${w.full_name} (${w.worker_code} - ${w.department_name || 'Worker'})</option>`).join("");
    document.getElementById("payment-jobber-select").innerHTML = jobbers.map(j => `<option value="${j.id}">${j.name} (${j.workshop_address || 'Jobber'})</option>`).join("");
    document.getElementById("payment-date-input").value = new Date().toISOString().split("T")[0];
    document.getElementById("modal-record-payment").classList.remove("hidden");
  });

  // Payee Type Change Handler
  document.getElementById("payee-type-select")?.addEventListener("change", (e) => {
    const isJobber = e.target.value === "JOBBER";
    document.getElementById("payee-worker-group").classList.toggle("hidden", isJobber);
    document.getElementById("payee-jobber-group").classList.toggle("hidden", !isJobber);
  });

  // Submit Payment Record
  document.getElementById("form-record-payment")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const payeeType = document.getElementById("payee-type-select").value;
    const workerId = payeeType === "WORKER" ? parseInt(document.getElementById("payment-worker-select").value) : null;
    const jobberId = payeeType === "JOBBER" ? parseInt(document.getElementById("payment-jobber-select").value) : null;
    const amount = parseFloat(document.getElementById("payment-amount-input").value);
    const mode = document.getElementById("payment-mode-select").value;
    const payDate = document.getElementById("payment-date-input").value;
    const notes = document.getElementById("payment-notes-input").value;

    await api.recordPayment({
      payee_type: payeeType,
      worker_id: workerId,
      jobber_id: jobberId,
      amount_paid: amount,
      payment_mode: mode,
      payment_date: payDate,
      notes: notes
    });
    showToast(`Payment of ₹${amount} recorded in Khata`);
    document.getElementById("modal-record-payment").classList.add("hidden");
    loadCostingAndPayments();
    if (currentSection === "workers") loadWorkers();
  });

  // 7. Open Stock Inward Modal (AUDITED & WIRED)
  document.getElementById("open-stock-inward-modal-btn")?.addEventListener("click", async () => {
    const designs = await api.getDesigns();
    const lots = await api.getLots();

    document.getElementById("stock-design-select").innerHTML = designs.map(d => `<option value="${d.id}">${d.design_number} - ${d.name}</option>`).join("");
    document.getElementById("stock-lot-select").innerHTML = lots.map(l => `<option value="${l.id}">${l.lot_number} (${l.total_cut_pieces} pcs)</option>`).join("");
    document.getElementById("modal-stock-inward").classList.remove("hidden");
  });

  // Submit Stock Inward
  document.getElementById("form-stock-inward")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const designId = parseInt(document.getElementById("stock-design-select").value);
    const lotId = parseInt(document.getElementById("stock-lot-select").value);
    const pieces = parseInt(document.getElementById("stock-pieces-input").value);
    const boxes = parseInt(document.getElementById("stock-boxes-input").value);

    await api.inwardFinishedStock({
      design_id: designId,
      lot_id: lotId,
      available_pieces: pieces,
      packed_boxes: boxes
    });
    showToast(`${pieces} finished shirts inwarded to Godown inventory`);
    document.getElementById("modal-stock-inward").classList.add("hidden");
    loadGodownStock();
  });

  // 8. Open New Worker Modal (AUDITED & WIRED)
  document.getElementById("open-new-worker-modal-btn")?.addEventListener("click", async () => {
    const depts = await api.getDepartments();
    const jobbers = await api.getJobbers();
    const machines = await api.getMachines();

    document.getElementById("worker-dept-select").innerHTML = depts.map(d => `<option value="${d.id}">${d.name}</option>`).join("");
    document.getElementById("worker-jobber-select").innerHTML = `<option value="">None (In-House)</option>` + jobbers.map(j => `<option value="${j.id}">${j.name}</option>`).join("");
    document.getElementById("worker-machine-select").innerHTML = `<option value="">None / Float</option>` + machines.map(m => `<option value="${m.id}">${m.machine_code} (${m.machine_type})</option>`).join("");
    document.getElementById("worker-code-input").value = `W-${Math.floor(100 + Math.random() * 900)}`;
    document.getElementById("modal-new-worker").classList.remove("hidden");
  });

  // Submit New Worker
  document.getElementById("form-new-worker")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    const jobberVal = document.getElementById("worker-jobber-select").value;
    const machineVal = document.getElementById("worker-machine-select").value;

    await api.createWorker({
      worker_code: document.getElementById("worker-code-input").value,
      full_name: document.getElementById("worker-name-input").value,
      department_id: parseInt(document.getElementById("worker-dept-select").value),
      role_designation: document.getElementById("worker-role-input").value,
      jobber_id: jobberVal ? parseInt(jobberVal) : null,
      machine_id: machineVal ? parseInt(machineVal) : null,
      rate_per_piece: parseFloat(document.getElementById("worker-piece-rate-input").value || 0),
      daily_wage: parseFloat(document.getElementById("worker-daily-wage-input").value || 0),
      pin: document.getElementById("worker-pin-input").value || "1234",
      phone: document.getElementById("worker-phone-input").value,
      language_preference: document.getElementById("worker-lang-select").value
    });
    showToast("Worker registered with touch screen PIN");
    document.getElementById("modal-new-worker").classList.add("hidden");
    loadWorkers();
  });

  // 9. Open New Design Modal (AUDITED & WIRED)
  document.getElementById("open-new-design-modal-btn")?.addEventListener("click", () => {
    document.getElementById("design-code-input").value = `AX-${Math.floor(200 + Math.random() * 800)}`;
    document.getElementById("modal-new-design").classList.remove("hidden");
  });

  // Submit New Design
  document.getElementById("form-new-design")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    await api.createDesign({
      design_number: document.getElementById("design-code-input").value,
      name: document.getElementById("design-name-input").value,
      fabric_type: document.getElementById("design-fabric-type-input").value,
      collar_style: document.getElementById("design-collar-input").value,
      sleeve_type: document.getElementById("design-sleeve-input").value,
      standard_cutting_rate: parseFloat(document.getElementById("design-cutting-rate-input").value || 6),
      standard_stitching_rate: parseFloat(document.getElementById("design-stitching-rate-input").value || 45)
    });
    showToast("New design created successfully");
    document.getElementById("modal-new-design").classList.add("hidden");
    loadMasters();
  });

  // 10. Open New Fabric Modal (AUDITED & WIRED)
  document.getElementById("open-new-fabric-modal-btn")?.addEventListener("click", () => {
    document.getElementById("fabric-inward-num-input").value = `FAB-${new Date().getFullYear()}-${Math.floor(100 + Math.random() * 900)}`;
    document.getElementById("fabric-date-input").value = new Date().toISOString().split("T")[0];
    document.getElementById("modal-new-fabric").classList.remove("hidden");
  });

  // Submit New Fabric
  document.getElementById("form-new-fabric")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    await api.createFabricInward({
      inward_number: document.getElementById("fabric-inward-num-input").value,
      supplier_name: document.getElementById("fabric-supplier-input").value,
      fabric_type: document.getElementById("fabric-quality-input").value,
      color_shade: document.getElementById("fabric-color-input").value,
      rolls_count: parseInt(document.getElementById("fabric-rolls-input").value || 1),
      meters_received: parseFloat(document.getElementById("fabric-meters-input").value),
      rate_per_meter: parseFloat(document.getElementById("fabric-rate-input").value || 0),
      inward_date: document.getElementById("fabric-date-input").value
    });
    showToast("Fabric inward recorded into inventory");
    document.getElementById("modal-new-fabric").classList.add("hidden");
    loadMasters();
  });

  // 11. Open New Customer Modal (AUDITED & WIRED)
  document.getElementById("open-new-customer-modal-btn")?.addEventListener("click", () => {
    document.getElementById("modal-new-customer").classList.remove("hidden");
  });

  // Submit New Customer
  document.getElementById("form-new-customer")?.addEventListener("submit", async (e) => {
    e.preventDefault();
    await api.createCustomer({
      customer_name: document.getElementById("customer-name-input").value,
      shop_name: document.getElementById("customer-shop-input").value,
      city: document.getElementById("customer-city-input").value,
      phone: document.getElementById("customer-phone-input").value,
      gst_number: document.getElementById("customer-gst-input").value,
      address: document.getElementById("customer-address-input").value
    });
    showToast("New buyer added to Customer Master");
    document.getElementById("modal-new-customer").classList.add("hidden");
    loadMasters();
  });
}

// Global search filter
function initGlobalSearch() {
  const input = document.getElementById("global-search-input");
  input?.addEventListener("input", (e) => {
    const q = e.target.value.toLowerCase();
    if (!q) return;

    // Filter current table rows
    const rows = document.querySelectorAll("tbody tr");
    rows.forEach((r) => {
      const match = r.textContent.toLowerCase().includes(q);
      r.style.display = match ? "" : "none";
    });
  });
}

function initLanguage() {
  applyTranslations();
  updateLangButtonStyles();
}

function updateLangButtonStyles() {
  ["en", "hi", "gu"].forEach((l) => {
    const btn = document.getElementById(`lang-${l}`);
    if (btn) {
      if (l === currentLanguage) {
        btn.className = "px-2 py-1 rounded lang-btn bg-white shadow-xs font-bold text-neutral-900";
      } else {
        btn.className = "px-2 py-1 rounded lang-btn text-neutral-500 hover:text-neutral-800";
      }
    }
  });
}
