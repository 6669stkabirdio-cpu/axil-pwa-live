// AXIL Factory Management PWA - AI Poster Studio & WhatsApp Broadcast Controller
// Client-side high-definition canvas graphic engine for instant, realistic, zero-cost posters

let currentPosterImage = null;
let currentPosterTheme = "luxury"; // luxury, wholesale, minimalist, festive
let currentPosterRatio = "1:1"; // 1:1 (Square), 9:16 (Story)
let currentMarketingLang = "en"; // en, hi, gu

const POSTER_PRESETS = {
  "ax-101": {
    title: "AXIL Royal Oxford Formal Shirt",
    fabric: "100% Super-Combed Cotton | Wrinkle Resistant",
    price: 480,
    moq: 30,
    sizes: ["M", "L", "XL", "XXL"],
    colors: "Navy, Sky Blue, White, Charcoal",
    ribbon: "READY STOCK FOR DISPATCH",
    contact: "Surat, Gujarat | WhatsApp: +91 98765 43210"
  },
  "ax-205": {
    title: "AXIL Printed Micro-Design Casual",
    fabric: "Soft Twill Cotton | Bio-Washed | Spread Collar",
    price: 420,
    moq: 40,
    sizes: ["M", "L", "XL"],
    colors: "Indigo Print, Olive Geo, Wine Floral",
    ribbon: "FESTIVE COLLECTION 2026",
    contact: "Surat, Gujarat | WhatsApp: +91 98765 43210"
  },
  "ax-301": {
    title: "AXIL Pure Linen Blend Relaxed Shirt",
    fabric: "Linen-Cotton Breathe Weave | Premium Wooden Buttons",
    price: 550,
    moq: 25,
    sizes: ["M", "L", "XL", "XXL", "3XL"],
    colors: "Beige, Mint Green, Peach, Crisp White",
    ribbon: "DIRECT FACTORY WHOLESALE",
    contact: "Surat, Gujarat | WhatsApp: +91 98765 43210"
  }
};

// Initialize AI Marketing Studio
function initMarketingStudio() {
  const canvas = document.getElementById("poster-canvas");
  if (!canvas) return;

  // Bind file inputs
  setupPosterImageInputs();

  // Bind preset selector
  document.getElementById("poster-preset-select")?.addEventListener("change", (e) => {
    applyPosterPreset(e.target.value);
  });

  // Bind inputs for live re-render
  const inputs = [
    "poster-title-input", "poster-fabric-input", "poster-price-input",
    "poster-moq-input", "poster-ribbon-input", "poster-contact-input",
    "poster-colors-input"
  ];
  inputs.forEach(id => {
    document.getElementById(id)?.addEventListener("input", () => {
      renderPosterCanvas();
      updateWhatsAppMarketingCopy();
    });
  });

  // Bind size pills
  document.querySelectorAll(".poster-size-pill").forEach(pill => {
    pill.addEventListener("click", () => {
      pill.classList.toggle("bg-neutral-900");
      pill.classList.toggle("text-white");
      pill.classList.toggle("bg-neutral-100");
      pill.classList.toggle("text-neutral-700");
      renderPosterCanvas();
      updateWhatsAppMarketingCopy();
    });
  });

  // Bind theme selector
  document.querySelectorAll(".poster-theme-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".poster-theme-btn").forEach(b => {
        b.classList.remove("ring-2", "ring-neutral-900", "shadow-md");
      });
      btn.classList.add("ring-2", "ring-neutral-900", "shadow-md");
      currentPosterTheme = btn.getAttribute("data-theme") || "luxury";
      renderPosterCanvas();
    });
  });

  // Bind aspect ratio buttons
  document.querySelectorAll(".poster-ratio-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".poster-ratio-btn").forEach(b => {
        b.classList.remove("bg-white", "text-neutral-900", "shadow-xs");
        b.classList.add("text-neutral-600");
      });
      btn.classList.add("bg-white", "text-neutral-900", "shadow-xs");
      btn.classList.remove("text-neutral-600");
      currentPosterRatio = btn.getAttribute("data-ratio") || "1:1";
      renderPosterCanvas();
    });
  });

  // Bind WhatsApp language buttons
  document.querySelectorAll(".wa-lang-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".wa-lang-btn").forEach(b => {
        b.classList.remove("bg-emerald-600", "text-white");
        b.classList.add("bg-neutral-100", "text-neutral-700");
      });
      btn.classList.add("bg-emerald-600", "text-white");
      btn.classList.remove("bg-neutral-100", "text-neutral-700");
      currentMarketingLang = btn.getAttribute("data-lang") || "en";
      updateWhatsAppMarketingCopy();
    });
  });

  // Set default initial state if needed
  if (!currentPosterImage) {
    loadDefaultShirtIllustration();
  } else {
    renderPosterCanvas();
    updateWhatsAppMarketingCopy();
  }
}

// Setup Gallery and Camera Uploads
function setupPosterImageInputs() {
  const galleryInput = document.getElementById("poster-gallery-input");
  const cameraInput = document.getElementById("poster-camera-input");

  const handleFile = (file) => {
    if (!file || !file.type.startsWith("image/")) {
      if (typeof showToast === "function") showToast("Please select a valid image file", "warning");
      return;
    }
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = new Image();
      img.onload = () => {
        currentPosterImage = img;
        const thumb = document.getElementById("poster-img-preview");
        if (thumb) {
          thumb.src = e.target.result;
          thumb.classList.remove("hidden");
        }
        document.getElementById("poster-img-placeholder")?.classList.add("hidden");
        renderPosterCanvas();
        if (typeof showToast === "function") showToast("Shirt photo loaded successfully!", "success");
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  };

  galleryInput?.addEventListener("change", (e) => {
    if (e.target.files && e.target.files[0]) handleFile(e.target.files[0]);
  });

  cameraInput?.addEventListener("change", (e) => {
    if (e.target.files && e.target.files[0]) handleFile(e.target.files[0]);
  });

  // Drag & drop support
  const dropZone = document.getElementById("poster-drop-zone");
  if (dropZone) {
    ["dragenter", "dragover"].forEach(name => {
      dropZone.addEventListener(name, (e) => {
        e.preventDefault();
        dropZone.classList.add("border-neutral-900", "bg-neutral-100");
      });
    });
    ["dragleave", "drop"].forEach(name => {
      dropZone.addEventListener(name, (e) => {
        e.preventDefault();
        dropZone.classList.remove("border-neutral-900", "bg-neutral-100");
      });
    });
    dropZone.addEventListener("drop", (e) => {
      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]) {
        handleFile(e.dataTransfer.files[0]);
      }
    });
  }
}

function applyPosterPreset(presetKey) {
  const p = POSTER_PRESETS[presetKey] || POSTER_PRESETS["ax-101"];
  const setVal = (id, val) => {
    const el = document.getElementById(id);
    if (el) el.value = val;
  };

  setVal("poster-title-input", p.title);
  setVal("poster-fabric-input", p.fabric);
  setVal("poster-price-input", p.price);
  setVal("poster-moq-input", p.moq);
  setVal("poster-colors-input", p.colors);
  setVal("poster-ribbon-input", p.ribbon);
  setVal("poster-contact-input", p.contact);

  document.querySelectorAll(".poster-size-pill").forEach(pill => {
    const sz = pill.getAttribute("data-size");
    if (p.sizes.includes(sz)) {
      pill.className = "poster-size-pill px-2.5 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer bg-neutral-900 text-white";
    } else {
      pill.className = "poster-size-pill px-2.5 py-1 rounded-lg text-xs font-bold border transition-all cursor-pointer bg-neutral-100 text-neutral-700";
    }
  });

  loadDefaultShirtIllustration(presetKey);
}

// Generate realistic shirt illustration if user hasn't uploaded a photo yet
function loadDefaultShirtIllustration(presetKey = "ax-101") {
  const tempCanvas = document.createElement("canvas");
  tempCanvas.width = 800;
  tempCanvas.height = 800;
  const ctx = tempCanvas.getContext("2d");

  let shirtColor = "#4A90E2";
  let collarColor = "#357ABD";
  let patternType = "oxford";

  if (presetKey === "ax-205") {
    shirtColor = "#2C3E50";
    collarColor = "#1A252F";
    patternType = "printed";
  } else if (presetKey === "ax-301") {
    shirtColor = "#E6D7C3";
    collarColor = "#D4C2AB";
    patternType = "linen";
  }

  // Draw garment backdrop shadow
  ctx.save();
  ctx.shadowColor = "rgba(0, 0, 0, 0.35)";
  ctx.shadowBlur = 30;
  ctx.shadowOffsetY = 20;

  // Shirt Body Outline
  ctx.fillStyle = shirtColor;
  ctx.beginPath();
  ctx.moveTo(250, 150);
  ctx.lineTo(120, 240);
  ctx.lineTo(140, 480);
  ctx.lineTo(220, 440);
  ctx.lineTo(210, 720);
  ctx.lineTo(590, 720);
  ctx.lineTo(580, 440);
  ctx.lineTo(660, 480);
  ctx.lineTo(680, 240);
  ctx.lineTo(550, 150);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // Pattern / Texture
  if (patternType === "oxford") {
    ctx.strokeStyle = "rgba(255, 255, 255, 0.12)";
    ctx.lineWidth = 2;
    for (let x = 150; x < 650; x += 12) {
      ctx.beginPath();
      ctx.moveTo(x, 180);
      ctx.lineTo(x, 720);
      ctx.stroke();
    }
  } else if (patternType === "printed") {
    ctx.fillStyle = "rgba(255, 255, 255, 0.18)";
    for (let y = 200; y < 700; y += 30) {
      for (let x = 220; x < 580; x += 30) {
        ctx.beginPath();
        ctx.arc(x, y, 2.5, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }

  // Front Placket
  ctx.fillStyle = collarColor;
  ctx.fillRect(380, 180, 40, 540);

  // Buttons
  ctx.fillStyle = "#FFFFFF";
  ctx.strokeStyle = "#888888";
  ctx.lineWidth = 1.5;
  [240, 320, 400, 480, 560, 640].forEach(y => {
    ctx.beginPath();
    ctx.arc(400, y, 7, 0, Math.PI * 2);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = "#555555";
    ctx.fillRect(397, y - 3, 2, 2);
    ctx.fillRect(401, y - 3, 2, 2);
    ctx.fillRect(397, y + 1, 2, 2);
    ctx.fillRect(401, y + 1, 2, 2);
    ctx.fillStyle = "#FFFFFF";
  });

  // Stiff Formal Collar
  ctx.fillStyle = collarColor;
  ctx.beginPath();
  ctx.moveTo(250, 150);
  ctx.lineTo(400, 240);
  ctx.lineTo(340, 140);
  ctx.closePath();
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(550, 150);
  ctx.lineTo(400, 240);
  ctx.lineTo(460, 140);
  ctx.closePath();
  ctx.fill();

  ctx.strokeStyle = "rgba(0, 0, 0, 0.25)";
  ctx.lineWidth = 3;
  ctx.stroke();

  // Pocket on left chest
  ctx.fillStyle = collarColor;
  ctx.fillRect(250, 310, 85, 100);
  ctx.strokeStyle = "rgba(255, 255, 255, 0.2)";
  ctx.lineWidth = 2;
  ctx.strokeRect(250, 310, 85, 100);

  const img = new Image();
  img.onload = () => {
    currentPosterImage = img;
    renderPosterCanvas();
    updateWhatsAppMarketingCopy();
  };
  img.src = tempCanvas.toDataURL("image/png");
}

// MAIN POSTER COMPOSITOR & RENDERER
function renderPosterCanvas() {
  const canvas = document.getElementById("poster-canvas");
  if (!canvas) return;

  const ctx = canvas.getContext("2d");
  const isStory = currentPosterRatio === "9:16";

  const W = 1080;
  const H = isStory ? 1920 : 1080;
  canvas.width = W;
  canvas.height = H;

  // Retrieve user inputs
  const title = document.getElementById("poster-title-input")?.value || "AXIL Premium Garments";
  const fabric = document.getElementById("poster-fabric-input")?.value || "100% Super-Combed Cotton";
  const price = document.getElementById("poster-price-input")?.value || "480";
  const moq = document.getElementById("poster-moq-input")?.value || "30";
  const ribbonText = document.getElementById("poster-ribbon-input")?.value || "DIRECT FACTORY WHOLESALE";
  const contactText = document.getElementById("poster-contact-input")?.value || "Surat, Gujarat | WhatsApp: +91 98765 43210";
  const colorsText = document.getElementById("poster-colors-input")?.value || "4 Running Colors";

  const activeSizes = [];
  document.querySelectorAll(".poster-size-pill").forEach(p => {
    if (p.classList.contains("bg-neutral-900")) {
      activeSizes.push(p.getAttribute("data-size"));
    }
  });

  drawThemeBackground(ctx, W, H, currentPosterTheme);
  drawBrandHeader(ctx, W, H, currentPosterTheme);
  drawShirtImage(ctx, W, H, currentPosterImage, isStory);
  drawPromoRibbon(ctx, W, H, ribbonText, currentPosterTheme, isStory);
  drawPosterTypography(ctx, W, H, {
    title, fabric, price, moq, colors: colorsText,
    sizes: activeSizes.length > 0 ? activeSizes : ["M", "L", "XL", "XXL"],
    contact: contactText
  }, currentPosterTheme, isStory);
}

function drawThemeBackground(ctx, W, H, theme) {
  if (theme === "luxury") {
    const bgGrad = ctx.createRadialGradient(W / 2, H * 0.45, 100, W / 2, H * 0.45, W * 0.85);
    bgGrad.addColorStop(0, "#27272A");
    bgGrad.addColorStop(0.65, "#18181B");
    bgGrad.addColorStop(1, "#09090B");
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, W, H);

    ctx.strokeStyle = "rgba(212, 175, 55, 0.45)";
    ctx.lineWidth = 3;
    ctx.strokeRect(30, 30, W - 60, H - 60);
    ctx.strokeStyle = "rgba(212, 175, 55, 0.2)";
    ctx.lineWidth = 1;
    ctx.strokeRect(40, 40, W - 80, H - 80);

    drawCornerAccent(ctx, 30, 30, "#D4AF37");
    drawCornerAccent(ctx, W - 30, 30, "#D4AF37", 1);
    drawCornerAccent(ctx, 30, H - 30, "#D4AF37", 2);
    drawCornerAccent(ctx, W - 30, H - 30, "#D4AF37", 3);

  } else if (theme === "wholesale") {
    ctx.fillStyle = "#111827";
    ctx.fillRect(0, 0, W, H);

    const topGrad = ctx.createLinearGradient(0, 0, W, 0);
    topGrad.addColorStop(0, "#F59E0B");
    topGrad.addColorStop(1, "#D97706");
    ctx.fillStyle = topGrad;
    ctx.fillRect(0, 0, W, 24);

    const floorGrad = ctx.createLinearGradient(0, H * 0.65, 0, H);
    floorGrad.addColorStop(0, "#1F2937");
    floorGrad.addColorStop(1, "#030712");
    ctx.fillStyle = floorGrad;
    ctx.fillRect(0, H * 0.65, W, H * 0.35);

  } else if (theme === "minimalist") {
    const bgGrad = ctx.createLinearGradient(0, 0, W, H);
    bgGrad.addColorStop(0, "#F9F8F6");
    bgGrad.addColorStop(1, "#EFECE6");
    ctx.fillStyle = bgGrad;
    ctx.fillRect(0, 0, W, H);

    ctx.strokeStyle = "rgba(24, 24, 27, 0.12)";
    ctx.lineWidth = 2;
    ctx.strokeRect(40, 40, W - 80, H - 80);

  } else if (theme === "festive") {
    const festGrad = ctx.createRadialGradient(W / 2, H * 0.4, 50, W / 2, H * 0.4, W * 0.9);
    festGrad.addColorStop(0, "#881337");
    festGrad.addColorStop(0.5, "#4C0519");
    festGrad.addColorStop(1, "#1F0208");
    ctx.fillStyle = festGrad;
    ctx.fillRect(0, 0, W, H);

    ctx.strokeStyle = "rgba(251, 191, 36, 0.35)";
    ctx.lineWidth = 3;
    ctx.strokeRect(32, 32, W - 64, H - 64);
  }
}

function drawCornerAccent(ctx, x, y, color, rot = 0) {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate((rot * 90 * Math.PI) / 180);
  ctx.strokeStyle = color;
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(0, 30);
  ctx.lineTo(0, 0);
  ctx.lineTo(30, 0);
  ctx.stroke();
  ctx.restore();
}

function drawBrandHeader(ctx, W, H, theme) {
  ctx.save();
  ctx.textAlign = "center";

  const brandColor = theme === "minimalist" ? "#18181B" : (theme === "luxury" ? "#E4D4A5" : (theme === "festive" ? "#FDE68A" : "#FFFFFF"));

  ctx.fillStyle = brandColor;
  ctx.font = "900 48px 'Inter', sans-serif";
  ctx.letterSpacing = "10px";
  ctx.fillText("AXIL", W / 2, 95);

  ctx.fillStyle = theme === "minimalist" ? "#71717A" : "#A1A1AA";
  ctx.font = "bold 15px 'Inter', sans-serif";
  ctx.letterSpacing = "6px";
  ctx.fillText("PREMIUM GARMENT APPARELS • DIRECT FACTORY", W / 2, 125);

  ctx.restore();
}

function drawShirtImage(ctx, W, H, img, isStory) {
  if (!img) return;

  ctx.save();
  const imgY = isStory ? H * 0.22 : H * 0.18;
  const maxW = isStory ? W * 0.82 : W * 0.72;
  const maxH = isStory ? H * 0.48 : H * 0.52;

  ctx.shadowColor = "rgba(0, 0, 0, 0.45)";
  ctx.shadowBlur = 45;
  ctx.shadowOffsetY = 25;

  const ratio = Math.min(maxW / img.width, maxH / img.height);
  const drawW = img.width * ratio;
  const drawH = img.height * ratio;
  const drawX = (W - drawW) / 2;
  const drawY = imgY + (maxH - drawH) / 2;

  ctx.drawImage(img, drawX, drawY, drawW, drawH);
  ctx.restore();
}

function drawPromoRibbon(ctx, W, H, ribbonText, theme, isStory) {
  if (!ribbonText) return;

  ctx.save();
  ctx.textAlign = "center";

  const ribbonY = isStory ? H * 0.16 : H * 0.15;

  let bgFill = "#E11D48";
  let textFill = "#FFFFFF";

  if (theme === "luxury") {
    bgFill = "rgba(212, 175, 55, 0.95)";
    textFill = "#18181B";
  } else if (theme === "wholesale") {
    bgFill = "#F59E0B";
    textFill = "#111827";
  } else if (theme === "minimalist") {
    bgFill = "#18181B";
    textFill = "#FFFFFF";
  }

  ctx.fillStyle = bgFill;
  ctx.font = "800 16px 'Inter', sans-serif";
  const metrics = ctx.measureText(ribbonText);
  const pillW = metrics.width + 48;
  const pillH = 36;
  const pillX = (W - pillW) / 2;

  ctx.beginPath();
  ctx.roundRect(pillX, ribbonY - pillH / 2, pillW, pillH, 18);
  ctx.fill();

  ctx.fillStyle = textFill;
  ctx.letterSpacing = "1.5px";
  ctx.fillText(ribbonText.toUpperCase(), W / 2, ribbonY + 6);
  ctx.restore();
}

function drawPosterTypography(ctx, W, H, data, theme, isStory) {
  ctx.save();

  const isDark = theme !== "minimalist";
  const textColor = isDark ? "#FFFFFF" : "#18181B";
  const subColor = isDark ? "#D4D4D8" : "#52525B";

  const startY = isStory ? H * 0.72 : H * 0.71;

  // 1. Shirt Title
  ctx.textAlign = "center";
  ctx.fillStyle = textColor;
  ctx.font = "900 36px 'Inter', sans-serif";
  ctx.letterSpacing = "0.5px";
  ctx.fillText(data.title, W / 2, startY);

  // 2. Fabric & Specifications
  ctx.fillStyle = subColor;
  ctx.font = "600 20px 'Inter', sans-serif";
  ctx.fillText(data.fabric, W / 2, startY + 38);

  // 3. Colors Available
  if (data.colors) {
    ctx.fillStyle = isDark ? "#A1A1AA" : "#71717A";
    ctx.font = "500 17px 'Inter', sans-serif";
    ctx.fillText(`Available Colors: ${data.colors}`, W / 2, startY + 72);
  }

  // 4. Sizing Chips
  const sizesY = startY + 115;
  const chipSize = 42;
  const chipGap = 12;
  const totalSizesW = data.sizes.length * chipSize + (data.sizes.length - 1) * chipGap;
  let currX = (W - totalSizesW) / 2;

  data.sizes.forEach(sz => {
    ctx.fillStyle = isDark ? "#27272A" : "#E4E4E7";
    ctx.strokeStyle = isDark ? "#3F3F46" : "#D4D4D8";
    ctx.lineWidth = 1.5;

    ctx.beginPath();
    ctx.roundRect(currX, sizesY - chipSize / 2, chipSize, chipSize, 8);
    ctx.fill();
    ctx.stroke();

    ctx.fillStyle = isDark ? "#FFFFFF" : "#18181B";
    ctx.font = "800 17px 'Inter', sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(sz, currX + chipSize / 2, sizesY + 6);

    currX += chipSize + chipGap;
  });

  // 5. Price & MOQ Highlight Badge
  const priceY = sizesY + 72;
  const priceBadgeW = 440;
  const priceBadgeH = 58;
  const priceBadgeX = (W - priceBadgeW) / 2;

  ctx.fillStyle = theme === "luxury" ? "#D4AF37" : (theme === "wholesale" ? "#F59E0B" : (theme === "festive" ? "#BE123C" : "#18181B"));
  ctx.beginPath();
  ctx.roundRect(priceBadgeX, priceY - priceBadgeH / 2, priceBadgeW, priceBadgeH, 29);
  ctx.fill();

  ctx.fillStyle = (theme === "luxury" || theme === "wholesale") ? "#18181B" : "#FFFFFF";
  ctx.font = "900 28px 'Inter', sans-serif";
  ctx.textAlign = "center";
  ctx.fillText(`₹${data.price} / Pc  •  MOQ: ${data.moq} Pcs`, W / 2, priceY + 9);

  // 6. Contact & Factory Footer
  const footerY = H - 52;
  ctx.fillStyle = isDark ? "rgba(255, 255, 255, 0.75)" : "rgba(24, 24, 27, 0.75)";
  ctx.font = "bold 17px 'Inter', sans-serif";
  ctx.fillText(data.contact, W / 2, footerY);

  ctx.restore();
}

// WHATSAPP MARKETING COPYWRITER
function updateWhatsAppMarketingCopy() {
  const title = document.getElementById("poster-title-input")?.value || "AXIL Royal Oxford Formal Shirt";
  const fabric = document.getElementById("poster-fabric-input")?.value || "100% Super-Combed Cotton";
  const price = document.getElementById("poster-price-input")?.value || "480";
  const moq = document.getElementById("poster-moq-input")?.value || "30";
  const colors = document.getElementById("poster-colors-input")?.value || "Navy, Sky Blue, White";
  const contact = document.getElementById("poster-contact-input")?.value || "+91 98765 43210";

  const activeSizes = [];
  document.querySelectorAll(".poster-size-pill").forEach(p => {
    if (p.classList.contains("bg-neutral-900")) activeSizes.push(p.getAttribute("data-size"));
  });
  const sizesStr = activeSizes.join(", ") || "M, L, XL, XXL";

  let copy = "";

  if (currentMarketingLang === "gu") {
    copy = `*${title.toUpperCase()}* \n` +
           `*સીધા ફેક્ટરી ભાવે રેડી સ્ટોક ડિસ્પેચ!* (AXIL Garments)\n\n` +
           `*કાપડ (Fabric):* ${fabric}\n` +
           `*કલર્સ (Colors):* ${colors}\n` +
           `*સાઇઝ (Sizes):* ${sizesStr}\n` +
           `*હોલસેલ રેટ:* ₹${price} / પીસ\n` +
           `*ઓછામાં ઓછો ઓર્ડર (MOQ):* ${moq} પીસ (સેટ વાઈઝ)\n\n` +
           `*ઓલ ઈન્ડિયા ટ્રાન્સપોર્ટ ડિલિવરી ઉપલબ્ધ.*\n` +
           `ઓર્ડર બુકિંગ માટે સીધો મેસેજ કરો: ${contact}\n` +
           `_AXIL Factory Management System_`;
  } else if (currentMarketingLang === "hi") {
    copy = `*${title.toUpperCase()}* \n` +
           `*सीधे फैक्ट्री से थोक माल उपलब्ध!* (AXIL Garments)\n\n` +
           `*कपड़ा (Fabric):* ${fabric}\n` +
           `*रंग (Colors):* ${colors}\n` +
           `*साइज (Sizes):* ${sizesStr}\n` +
           `*थोक मूल्य (Wholesale Price):* ₹${price} / पीस\n` +
           `*न्यूनतम आर्डर (MOQ):* ${moq} पीस (सेट टू सेट)\n\n` +
           `*पूरे भारत में सुरक्षित ट्रांसपोर्ट सुविधा.*\n` +
           `आर्डर व बुकिंग के लिए तुरंत संपर्क करें: ${contact}\n` +
           `_AXIL Garment Manufacturing_`;
  } else {
    copy = `*${title.toUpperCase()}* \n` +
           `*Direct Factory Ready Stock for Immediate Dispatch!* (AXIL)\n\n` +
           `*Fabric:* ${fabric}\n` +
           `*Colors:* ${colors}\n` +
           `*Available Sizes:* ${sizesStr}\n` +
           `*Wholesale Price:* ₹${price} / pc\n` +
           `*MOQ:* ${moq} pcs (Ratio packed)\n\n` +
           `*Pan-India Transport & Courier Service Available.*\n` +
           `For catalog & immediate order booking, contact: ${contact}\n` +
           `_AXIL Garment Manufacturing ERP_`;
  }

  const copyArea = document.getElementById("poster-wa-copy");
  if (copyArea) copyArea.value = copy;
}

// 1-TAP BROADCAST TO WHATSAPP
function broadcastPosterToWhatsApp() {
  const text = document.getElementById("poster-wa-copy")?.value || "";
  const encoded = encodeURIComponent(text);
  const waUrl = `https://api.whatsapp.com/send?text=${encoded}`;
  window.open(waUrl, "_blank");
  if (typeof showToast === "function") showToast("Opening WhatsApp... Select any contact, group or community to broadcast!", "success");
}

// DOWNLOAD HIGH-RES POSTER PNG
function downloadPosterHD() {
  const canvas = document.getElementById("poster-canvas");
  if (!canvas) return;

  const title = (document.getElementById("poster-title-input")?.value || "AXIL_Shirt")
    .replace(/[^a-zA-Z0-9]/g, "_").toLowerCase();
  
  const link = document.createElement("a");
  link.download = `${title}_poster_${currentPosterRatio.replace(":", "x")}.png`;
  link.href = canvas.toDataURL("image/png", 1.0);
  link.click();
  if (typeof showToast === "function") showToast("High-Definition Poster downloaded! Ready to share on WhatsApp & Instagram.", "success");
}

// COPY WHATSAPP TEXT
function copyWhatsAppCopy() {
  const text = document.getElementById("poster-wa-copy")?.value;
  if (!text) return;
  navigator.clipboard.writeText(text).then(() => {
    if (typeof showToast === "function") showToast("WhatsApp broadcast copy copied to clipboard! ", "success");
  }).catch(() => {
    if (typeof showToast === "function") showToast("Copied to clipboard", "success");
  });
}

// Global window bindings
window.initMarketingStudio = initMarketingStudio;
window.applyPosterPreset = applyPosterPreset;
window.renderPosterCanvas = renderPosterCanvas;
window.broadcastPosterToWhatsApp = broadcastPosterToWhatsApp;
window.downloadPosterHD = downloadPosterHD;
window.copyWhatsAppCopy = copyWhatsAppCopy;
