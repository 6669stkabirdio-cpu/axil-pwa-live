// AXIL PWA - Core API & Session Client
const API_BASE = "";

const api = {
  // Owner session (kept completely isolated from worker session)
  ownerToken: localStorage.getItem("axil_owner_token") || localStorage.getItem("axil_token") || null,
  ownerUser: JSON.parse(localStorage.getItem("axil_owner_user") || localStorage.getItem("axil_user") || "null"),

  // Worker session (for Karigar touchscreen PWA)
  workerToken: localStorage.getItem("axil_worker_token") || null,
  workerSession: JSON.parse(localStorage.getItem("axil_worker_session") || "null"),

  // Backward-compatibility accessors
  get token() {
    return this.getActiveToken();
  },
  set token(val) {
    this.ownerToken = val;
  },
  get user() {
    const isWorker = window.location.pathname.includes("worker") || !!document.getElementById("worker-dashboard-view");
    return isWorker ? this.workerSession : this.ownerUser;
  },
  set user(val) {
    this.ownerUser = val;
  },

  setSession(token, user) {
    this.ownerToken = token;
    this.ownerUser = user;
    localStorage.setItem("axil_owner_token", token);
    localStorage.setItem("axil_owner_user", JSON.stringify(user));
    localStorage.setItem("axil_token", token);
    localStorage.setItem("axil_user", JSON.stringify(user));
  },

  clearSession() {
    this.ownerToken = null;
    this.ownerUser = null;
    localStorage.removeItem("axil_owner_token");
    localStorage.removeItem("axil_owner_user");
    localStorage.removeItem("axil_token");
    localStorage.removeItem("axil_user");
  },

  setWorkerSession(token, user, credentials = null) {
    this.workerToken = token;
    this.workerSession = user;
    localStorage.setItem("axil_worker_token", token);
    localStorage.setItem("axil_worker_session", JSON.stringify(user));
    if (credentials) {
      localStorage.setItem("axil_worker_credentials", JSON.stringify(credentials));
    }
    // NEVER overwrite owner session!
  },

  clearWorkerSession() {
    this.workerToken = null;
    this.workerSession = null;
    localStorage.removeItem("axil_worker_token");
    localStorage.removeItem("axil_worker_session");
    localStorage.removeItem("axil_worker_credentials");
  },

  getWorkerCredentials() {
    try {
      return JSON.parse(localStorage.getItem("axil_worker_credentials") || "null");
    } catch (e) {
      return null;
    }
  },

  getActiveToken() {
    const isWorkerContext = window.location.pathname.includes("worker") || !!document.getElementById("worker-dashboard-view");
    if (isWorkerContext) {
      return this.workerToken || localStorage.getItem("axil_worker_token");
    }
    return this.ownerToken || localStorage.getItem("axil_owner_token") || localStorage.getItem("axil_token");
  },

  async request(endpoint, options = {}) {
    const headers = {
      "Content-Type": "application/json",
      ...(options.headers || {})
    };

    const authToken = this.getActiveToken();
    if (authToken) {
      headers["Authorization"] = `Bearer ${authToken}`;
    }

    try {
      const res = await fetch(`${API_BASE}${endpoint}`, {
        ...options,
        headers
      });

      const isWorkerContext = window.location.pathname.includes("worker") || !!document.getElementById("worker-dashboard-view");

      // Handle 401 (Unauthorized) or 403 (Forbidden) with automatic seamless re-authentication
      if ((res.status === 401 || res.status === 403) && !options._isRetry) {
        if (isWorkerContext) {
          // Transparent background re-authentication for worker device setup
          const creds = this.getWorkerCredentials();
          if (creds && creds.worker_code && creds.pin) {
            try {
              const reloginRes = await fetch(`${API_BASE}/api/auth/worker-pin-login`, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({ worker_code: creds.worker_code, pin: creds.pin })
              });
              if (reloginRes.ok) {
                const newAuth = await reloginRes.json();
                this.setWorkerSession(newAuth.token, newAuth, creds);
                return await this.request(endpoint, {
                  ...options,
                  _isRetry: true,
                  headers: {
                    ...(options.headers || {}),
                    "Authorization": `Bearer ${newAuth.token}`
                  }
                });
              }
            } catch (reErr) {
              console.warn("Worker transparent re-auth failed:", reErr);
            }
          }
        } else {
          // Transparent background re-authentication for Owner Portal with admin credentials
          try {
            const reloginRes = await fetch(`${API_BASE}/api/auth/login`, {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ username: "admin", password: "axil@2026" })
            });
            if (reloginRes.ok) {
              const newAuth = await reloginRes.json();
              this.setSession(newAuth.token, newAuth);
              return await this.request(endpoint, {
                ...options,
                _isRetry: true,
                headers: {
                  ...(options.headers || {}),
                  "Authorization": `Bearer ${newAuth.token}`
                }
              });
            }
          } catch (reErr) {
            console.warn("Owner transparent re-auth failed:", reErr);
          }
        }
      }

      const data = await res.json().catch(() => null);

      if (!res.ok) {
        const errorMsg = (data && data.detail) || "Server error occurred";
        throw new Error(errorMsg);
      }

      return data;
    } catch (err) {
      console.error(`API Error [${endpoint}]:`, err);
      throw err;
    }
  },

  // Auth
  login(username, password) {
    return this.request("/api/auth/login", {
      method: "POST",
      body: JSON.stringify({ username, password })
    });
  },

  workerPinLogin(worker_code, pin) {
    return this.request("/api/auth/worker-pin-login", {
      method: "POST",
      body: JSON.stringify({ worker_code, pin })
    });
  },

  getCurrentUser() {
    return this.request("/api/auth/me");
  },

  // Dashboard
  getDashboardSummary() {
    return this.request("/api/dashboard/summary");
  },

  // Workers & Attendance
  getWorkers(department_id = null) {
    const q = department_id ? `?department_id=${department_id}` : "";
    return this.request(`/api/workers${q}`);
  },

  markAttendance(data) {
    return this.request("/api/attendance/mark", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  getMonthlyAttendance(month) {
    return this.request(`/api/attendance/monthly?month=${month}`);
  },

  // Orders
  getOrders(status = null) {
    const q = status ? `?status_filter=${status}` : "";
    return this.request(`/api/orders${q}`);
  },

  createOrder(data) {
    return this.request("/api/orders", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  updateOrderStatus(orderId, status, notes = "") {
    return this.request(`/api/orders/${orderId}/status`, {
      method: "PUT",
      body: JSON.stringify({ status, notes })
    });
  },

  createDispatch(data) {
    return this.request("/api/dispatches", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  // Lots & Manufacturing
  getLots() {
    return this.request("/api/lots");
  },

  getLotDetails(lotId) {
    return this.request(`/api/lots/${lotId}`);
  },

  createLot(data) {
    return this.request("/api/lots", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  getLotCostSheet(lotId) {
    return this.request(`/api/lots/${lotId}/cost-sheet`);
  },

  // Handover & Shortages
  sendMovement(data) {
    return this.request("/api/movements/send", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  confirmMovement(data) {
    return this.request("/api/movements/confirm", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  // Karigar Production
  startProduction(data) {
    return this.request("/api/production/start", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  completeProduction(data) {
    return this.request("/api/production/complete", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  pauseProduction(production_id, break_reason) {
    return this.request("/api/production/pause", {
      method: "POST",
      body: JSON.stringify({ production_id, break_reason })
    });
  },

  resumeProduction(production_id) {
    return this.request("/api/production/resume", {
      method: "POST",
      body: JSON.stringify({ production_id })
    });
  },

  saveBundleProgress(data) {
    return this.request("/api/production/save-progress", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  saveAndStopProduction(data) {
    return this.request("/api/production/save-and-stop", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  advanceLotStage(data) {
    return this.request("/api/production/advance-stage", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  getPendingProductionOrders() {
    return this.request("/api/orders/pending-for-production");
  },

  getWorkerAttendanceCalendar(workerId, month = null) {
    const q = month ? `?month=${encodeURIComponent(month)}` : "";
    return this.request(`/api/workers/${workerId}/attendance-calendar${q}`);
  },

  getWorkerProduction(workerId) {
    return this.request(`/api/production/worker/${workerId}`);
  },

  getWorkerDeepAnalytics(workerId, date = null) {
    const q = date ? `?date=${encodeURIComponent(date)}` : "";
    return this.request(`/api/workers/${workerId}/deep-analytics${q}`);
  },

  // Alterations
  reportAlteration(data) {
    return this.request("/api/alterations", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  getWorkerAlterations(workerId) {
    return this.request(`/api/alterations/worker/${workerId}`);
  },

  rectifyAlteration(altId) {
    return this.request(`/api/alterations/${altId}/rectify`, {
      method: "PUT"
    });
  },

  // Fabric, Stock & Payments
  getFabricInward() {
    return this.request("/api/fabric-inward");
  },

  createFabricInward(data) {
    return this.request("/api/fabric-inward", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  getFinishedStock() {
    return this.request("/api/stock/finished");
  },

  inwardFinishedStock(data) {
    return this.request("/api/stock/inward", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  getPayments() {
    return this.request("/api/payments");
  },

  recordPayment(data) {
    return this.request("/api/payments", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  // Analytics
  getAnalyticsReport(startDate = null, endDate = null) {
    const params = new URLSearchParams();
    if (startDate) params.append("start_date", startDate);
    if (endDate) params.append("end_date", endDate);
    const q = params.toString() ? `?${params.toString()}` : "";
    return this.request(`/api/analytics/report${q}`);
  },

  // Masters
  getDepartments() {
    return this.request("/api/masters/departments");
  },

  getJobbers() {
    return this.request("/api/masters/jobbers");
  },

  getMachines() {
    return this.request("/api/masters/machines");
  },

  getDesigns() {
    return this.request("/api/masters/designs");
  },

  createDesign(data) {
    return this.request("/api/masters/designs", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  getCustomers() {
    return this.request("/api/masters/customers");
  },

  createCustomer(data) {
    return this.request("/api/masters/customers", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  createWorker(data) {
    return this.request("/api/masters/workers", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  // Real Factory Worker Portal Methods
  registerWorkerSelf(fullName, roleDesignation, phone, password, otpCode = null) {
    return this.request("/api/auth/worker/register", {
      method: "POST",
      body: JSON.stringify({
        full_name: fullName,
        role_designation: roleDesignation,
        phone: phone,
        password: password,
        otp_code: otpCode
      })
    });
  },

  loginWorkerPhone(phone, password) {
    return this.request("/api/auth/worker/login", {
      method: "POST",
      body: JSON.stringify({
        phone: phone,
        password: password
      })
    });
  },

  getWorkerQueue() {
    return this.request("/api/worker/my-queue");
  },

  workerStartLot(lotId) {
    return this.request(`/api/worker/lots/${lotId}/start`, {
      method: "POST"
    });
  },

  workerUploadPhoto(lotId, photoBase64) {
    return this.request(`/api/worker/lots/${lotId}/upload-photo`, {
      method: "POST",
      body: JSON.stringify({ photo_base64: photoBase64 })
    });
  },

  workerCompleteTurnaround(lotId, piecesCompleted = null, notes = null) {
    return this.request(`/api/worker/lots/${lotId}/complete`, {
      method: "POST",
      body: JSON.stringify({
        pieces_completed: piecesCompleted,
        notes: notes
      })
    });
  },

  cuttingMasterCreateLot(data) {
    return this.request("/api/worker/cutting/create-lot", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  subscribePush(subData) {
    return this.request("/api/notifications/subscribe", {
      method: "POST",
      body: JSON.stringify(subData)
    });
  },

  assignWasher(lotId, washerWorkerId, notes = null) {
    return this.request(`/api/production/lots/${lotId}/assign-washer`, {
      method: "POST",
      body: JSON.stringify({
        washer_worker_id: washerWorkerId,
        notes: notes
      })
    });
  },

  // Jobber Operations & Floor Hub
  getJobberHubData() {
    return this.request("/api/jobber/hub-data");
  },

  jobberAssignWork(data) {
    return this.request("/api/jobber/assign-work", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  jobberUpdateProgress(data) {
    return this.request("/api/jobber/update-progress", {
      method: "POST",
      body: JSON.stringify(data)
    });
  },

  jobberSendLotAhead(lotId, totalPieces, notes = null) {
    return this.request(`/api/jobber/lots/${lotId}/send-ahead`, {
      method: "POST",
      body: JSON.stringify({
        total_completed_pieces: totalPieces,
        notes: notes
      })
    });
  },

  getDetailedJobbers() {
    return this.request("/api/masters/jobbers/detailed");
  },

  getDailyActivity(date = null) {
    const q = date ? `?date=${encodeURIComponent(date)}` : '';
    return this.request(`/api/dashboard/daily-activity${q}`);
  },

  getLotJourney(lotId) {
    return this.request(`/api/lots/${lotId}/journey`);
  },

  uploadLotPhoto(lotId, photoBase64) {
    return this.request(`/api/lots/${lotId}/photo`, {
      method: "POST",
      body: JSON.stringify({ photo_base64: photoBase64 })
    });
  }
};

// UI Notification / Toast Helper
function showToast(message, type = "success") {
  let container = document.getElementById("toast-container");
  if (!container) {
    container = document.createElement("div");
    container.id = "toast-container";
    container.className = "fixed bottom-5 right-5 z-50 flex flex-col gap-2 max-w-sm";
    document.body.appendChild(container);
  }

  const toast = document.createElement("div");
  const bg = type === "error" ? "bg-red-800 text-white" : (type === "warning" ? "bg-amber-600 text-white" : "bg-neutral-900 text-white");
  toast.className = `${bg} px-4 py-3 rounded-lg shadow-lg flex items-center justify-between text-sm transition-all duration-300 transform translate-y-2 opacity-0`;
  toast.innerHTML = `
    <span>${message}</span>
    <button class="ml-3 text-neutral-300 hover:text-white">&times;</button>
  `;

  toast.querySelector("button").onclick = () => toast.remove();
  container.appendChild(toast);

  // Trigger animation
  setTimeout(() => {
    toast.classList.remove("translate-y-2", "opacity-0");
  }, 10);

  setTimeout(() => {
    toast.classList.add("opacity-0", "translate-y-2");
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}
