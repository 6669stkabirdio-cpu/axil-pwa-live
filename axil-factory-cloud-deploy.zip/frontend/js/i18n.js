// AXIL PWA - Tri-Lingual Localization Engine (English, Hindi, Gujarati)
const TRANSLATIONS = {
  en: {
    app_title: "AXIL Factory Management",
    welcome: "Welcome",
    dashboard: "Dashboard",
    manufacturing: "Manufacturing Pipeline",
    lot_tracking: "Lot Tracking",
    department_handover: "Handover Alerts",
    workers: "Karigars & Payroll",
    jobbers_machines: "Jobbers & Machines",
    costing_payments: "Costing & Payments",
    active_lots: "Lots In Production",
    pending_alterations: "Pending Alterations",
    godown: "Godown Inventory",
    reports: "Reports & Defect Audit",
    settings: "Settings",
    logout: "Log Out",
    worker_portal: "Karigar Floor Touch Screen",
    owner_login_title: "👑 Factory Owner Login",
    owner_login_sub: "Enter factory owner credentials to access the management dashboard",
    username: "Username",
    password: "Password",
    login_owner_btn: "Log In to Owner Portal",
    
    // Dashboard KPIs & Stage Funnel
    fabric_in_stock: "Fabric in Stock (Meters)",
    fabric_meters_unit: "Meters",
    remnant_fabric: "Remnant Fabric Left",
    total_fabric_received: "Total Inward Fabric",
    cutting_pending: "1. Cutting In Progress",
    stitching_pending: "2. Stitching Pending",
    washing_pending: "3. Washing Queue",
    gaaj_button_pending: "4. Gaaj-Button Pending",
    press_packing_pending: "5. Press & Packing",
    finished_stock: "6. Finished Godown Stock",
    pieces_unit: "Pieces",
    lots_unit: "Lots",
    
    // Washer Decision Workflow
    assign_washer_title: "🧼 Assign Washer for Completed Stitching",
    assign_washer_sub: "Stitching is finished for this lot. Which washer/laundry should process it?",
    choose_washer_placeholder: "-- Choose Washer --",
    assign_and_send_btn: "Confirm & Send to Washer",
    
    // Worker Portal & Roles
    worker_login_title: "AXIL Karigar Floor Portal",
    worker_login_sub: "Real-time production and turnaround tracking",
    new_registration_tab: "✨ New Registration",
    phone_login_tab: "🔑 Mobile Login",
    select_role_label: "Select Your Role:",
    role_cutting: "✂️ Cutting Master",
    role_stitcher: "🪡 Stitcher / Karigar",
    role_jobber: "🏢 Jobber / Floor Manager",
    role_washer: "🧼 Washer",
    role_gaaj: "🔘 Gaaj-Button Operator",
    role_packing: "📦 Press & Packing",
    full_name_label: "Full Name:",
    full_name_placeholder: "e.g. Ramesh Makwana",
    mobile_label: "Mobile Number (10 digits):",
    mobile_placeholder: "10-digit mobile number",
    set_password_label: "Password / PIN:",
    set_password_placeholder: "Enter your password",
    register_and_start_btn: "🚀 Register & Start Work",
    login_btn: "🔑 Log In",
    logout_btn: "Log Out",
    enable_notifications_title: "Enable Lockscreen Alerts",
    enable_notifications_sub: "Receive new work and urgent lot alerts like WhatsApp",
    enable_notifications_btn: "Enable Alerts",
    
    // Cutting Master Form
    cutting_master_title: "✂️ Fabric Inward & Cutting Lot Entry",
    cutting_master_sub: "Log fabric from dealer, cut pieces, and remnant meters. Notifies owner and routes to next stage.",
    new_lot_tab: "✂️ New Cutting Lot",
    lot_history_tab: "📋 Cut Lots History",
    dealer_name_label: "Dealer / Supplier Name: *",
    dealer_name_placeholder: "e.g. Arvind Mills / Raymond",
    fabric_type_label: "Fabric Type: *",
    fabric_type_placeholder: "e.g. Pure Cotton / Linen / Twill",
    meters_received_label: "Fabric Received (Meters): *",
    design_select_label: "Design Number: *",
    lot_number_label: "Lot Number: *",
    cut_pieces_label: "Total Cut Pieces: *",
    remnant_meters_label: "Remnant Fabric Left in Factory: *",
    colors_swatches_label: "Colors / Swatches (Sample Shades):",
    colors_swatches_placeholder: "e.g. Sky Blue, Navy, White",
    is_urgent_label: "🚨 Is this Lot URGENT?",
    due_date_label: "Target Completion Date (Due Date):",
    stages_checklist_label: "Which stages will this lot visit?",
    submit_lot_btn: "🚀 Save Lot & Send to Next Stage",
    
    // Karigar Queue & Actions
    stitching_queue_title: "🪡 Assigned Stitching Queue",
    refresh_btn: "🔄 Refresh",
    accept_start_lot_btn: "✅ Accept & Start Lot",
    take_photo_btn: "📸 Take Sample Shirt Photo",
    change_photo_btn: "📸 Retake Photo",
    complete_turnaround_btn: "🏁 Complete Turnaround",
    photo_modal_title: "📸 Capture Finished Sample Shirt Photo",
    camera_trigger_btn: "📸 Open Camera (Take Photo)",
    save_photo_btn: "💾 Save Photo",
    complete_modal_title: "🏁 Mark Lot Complete",
    pieces_completed_label: "Completed Pieces:",
    notes_label: "Notes (Optional):",
    confirm_complete_btn: "✅ Confirm Complete & Advance",
    
    // Workers Table & Payroll
    worker_code: "Code",
    worker_name: "Karigar Name",
    worker_role: "Role / Department",
    worker_phone: "Mobile",
    rate_per_piece: "Rate / Pc",
    pieces_completed_col: "Pieces Done",
    total_salary_earned: "Total Salary Earned",
    paid_so_far: "Paid So Far",
    pending_salary: "Pending Due",
    pay_action_btn: "Pay / Khata Entry",
    dept_washing_title: "🧼 Washing Work Queue",
    dept_gaaj_title: "🔘 Gaaj-Button Work Queue",
    dept_press_title: "📦 Press & Packing Queue",
    start_date_label: "Start Date",
    turnaround_time_label: "Turnaround Time",
    days_unit: "days in progress",
    photo_saved_title: "Sample Shirt Photo Saved",
    photo_saved_sub: "Photo sent to Factory Owner portal.",
    normal_priority: "NORMAL",
    dealer_label: "Dealer",
    jobber_command_center: "Jobber Command Center",
    assign_pieces_to_karigar_btn: "Assign Work to Karigar",
    send_lot_to_washing_btn: "Send Lot to Washing",
    pieces_assigned_label: "Pieces Assigned",
    rate_paid_by_jobber_label: "Rate Paid by Jobber (₹/pc)",
    select_karigar_label: "Select Karigar",
    select_machine_label: "Select Machine",
    karigar_speed_col: "Speed (Pcs/Hr)",
    jobber_karigars_tab: "Karigars & Pay",
    jobber_lots_tab: "Active Lots",
    jobber_log_tab: "Allocations Log"
  },

  gu: {
    app_title: "AXIL ફેક્ટરી મેનેજમેન્ટ",
    welcome: "સ્વાગત છે",
    dashboard: "ડેશબોર્ડ (Dashboard)",
    manufacturing: "ઉત્પાદન પાઇપલાઇન",
    lot_tracking: "લોટ ટ્રેકિંગ",
    department_handover: "હેન્ડઓવર એલર્ટ્સ",
    workers: "કારીગરો & પગાર ખાતું",
    jobbers_machines: "જોબર્સ & વર્કશોપ મશીન",
    costing_payments: "પડતર ભાવ & ખાતાવહી ચૂકવણી",
    active_lots: "ઉત્પાદનમાં ચાલુ લોટ",
    pending_alterations: "પેન્ડિંગ ઓલ્ટરેશન",
    godown: "તૈયાર માલ ગોડાઉન",
    reports: "રિપોર્ટ્સ & ડિફેક્ટ ઓડિટ",
    settings: "સેટિંગ્સ",
    logout: "બહાર નીકળો (Log Out)",
    worker_portal: "કારીગર ફ્લોર ટચ સ્ક્રીન",
    owner_login_title: "👑 ફેક્ટરી માલિક લોગિન (Owner Login)",
    owner_login_sub: "મેનેજમેન્ટ ડેશબોર્ડ ખોલવા માટે પાસવર્ડ દાખલ કરો",
    username: "યુઝરનેમ (Username)",
    password: "પાસવર્ડ (Password)",
    login_owner_btn: "માલિક પોર્ટલમાં લોગિન કરો",
    
    // Dashboard KPIs & Stage Funnel
    fabric_in_stock: "ફેક્ટરીમાં કાપડ સ્ટોક (મીટર)",
    fabric_meters_unit: "મીટર",
    remnant_fabric: "વધેલું બાકી કાપડ",
    total_fabric_received: "કુલ આવેલ કાપડ",
    cutting_pending: "1. કટીંગ ચાલુ / પેન્ડિંગ",
    stitching_pending: "2. સિલાઈ પેન્ડિંગ",
    washing_pending: "3. વોશિંગ કતાર",
    gaaj_button_pending: "4. ગાજ-બટન પેન્ડિંગ",
    press_packing_pending: "5. પ્રેસ & પેકિંગ",
    finished_stock: "6. તૈયાર ગોડાઉન સ્ટોક",
    pieces_unit: "પીસ",
    lots_unit: "લોટ",
    
    // Washer Decision Workflow
    assign_washer_title: "🧼 સિલાઈ પૂર્ણ થયેલ લોટ માટે વોશર પસંદ કરો",
    assign_washer_sub: "આ લોટની સિલાઈ પૂરી થઈ ગઈ છે. કયા વોશર કે લોન્ડ્રી પાસે મોકલવો છે?",
    choose_washer_placeholder: "-- વોશર પસંદ કરો --",
    assign_and_send_btn: "વોશિંગ માટે મોકલો & નોટિફાય કરો",
    
    // Worker Portal & Roles
    worker_login_title: "AXIL કારીગર પોર્ટલ",
    worker_login_sub: "ફેક્ટરી ફ્લોર ઉત્પાદન & ટર્નઅરાઉન્ડ ટ્રેકિંગ",
    new_registration_tab: "✨ નવું રજીસ્ટ્રેશન",
    phone_login_tab: "🔑 મોબાઇલ લોગિન",
    select_role_label: "તમારો હોદ્દો / કાર્ય પસંદ કરો:",
    role_cutting: "✂️ કટીંગ માસ્ટર",
    role_stitcher: "🪡 સિલાઈ કારીગર",
    role_jobber: "🏢 જોબર / ફ્લોર મેનેજર",
    role_washer: "🧼 વોશિંગ કારીગર",
    role_gaaj: "🔘 ગાજ-બટન કારીગર",
    role_packing: "📦 પ્રેસ & પેકિંગ",
    full_name_label: "તમારું પૂરું નામ:",
    full_name_placeholder: "દા.ત. રમેશભાઈ મકવાણા",
    mobile_label: "મોબાઇલ નંબર (10 અંક):",
    mobile_placeholder: "10 અંકનો મોબાઇલ નંબર",
    set_password_label: "પાસવર્ડ / પિન:",
    set_password_placeholder: "તમારો પાસવર્ડ દાખલ કરો",
    register_and_start_btn: "🚀 ખાતું બનાવો & શરૂ કરો",
    login_btn: "🔑 લોગિન કરો",
    logout_btn: "બહાર નીકળો",
    enable_notifications_title: "મોબાઇલ નોટિફિકેશન ચાલુ કરો",
    enable_notifications_sub: "નવા અને અર્જન્ટ કામના મેસેજ લોકસ્ક્રીન પર આવશે (વોટ્સએપ જેવું)",
    enable_notifications_btn: "ચાલુ કરો",
    
    // Cutting Master Form
    cutting_master_title: "✂️ કાપડ આવક & કટીંગ લોટ એન્ટ્રી",
    cutting_master_sub: "કાપડ અને કટીંગની વિગત ભરો. આ લોટ આગળના સ્ટેજ અને માલિકને આપોઆપ મોકલાશે.",
    new_lot_tab: "✂️ નવો લોટ કટીંગ",
    lot_history_tab: "📋 કરેલા લોટ લિસ્ટ",
    dealer_name_label: "ડીલર / વેપારીનું નામ: *",
    dealer_name_placeholder: "દા.ત. અરવિંદ મિલ્સ / રેમન્ડ",
    fabric_type_label: "કાપડનો પ્રકાર: *",
    fabric_type_placeholder: "દા.ત. Pure Cotton / Linen / Twill",
    meters_received_label: "આવેલ કાપડ મીટર: *",
    design_select_label: "ડિઝાઇન નંબર: *",
    lot_number_label: "લોટ નંબર: *",
    cut_pieces_label: "કુલ કટીંગ પીસ: *",
    remnant_meters_label: "ફેક્ટરીમાં વધેલું બાકી કાપડ: *",
    colors_swatches_label: "રંગો / સેમ્પલ શેડ્સ:",
    colors_swatches_placeholder: "દા.ત. Sky Blue, Navy, White",
    is_urgent_label: "🚨 અર્જન્ટ લોટ છે?",
    due_date_label: "તૈયાર કરવાની તારીખ:",
    stages_checklist_label: "આ લોટ કયા કયા સ્ટેજમાંથી જશે?",
    submit_lot_btn: "🚀 લોટ કટીંગ પૂર્ણ & આગળ મોકલો",
    
    // Karigar Queue & Actions
    stitching_queue_title: "🪡 સિલાઈ માટે સોંપેલ લોટ (Stitching Queue)",
    refresh_btn: "🔄 રીફ્રેશ",
    accept_start_lot_btn: "✅ લોટ સ્વીકારો & શરૂ કરો (Accept & Start)",
    take_photo_btn: "📸 સેમ્પલ શર્ટ ફોટો લો",
    change_photo_btn: "📸 નવો ફોટો બદલો",
    complete_turnaround_btn: "🏁 લોટ પૂર્ણ કરો (Complete Turnaround)",
    photo_modal_title: "📸 સેમ્પલ શર્ટનો ફોટો લો",
    camera_trigger_btn: "📸 કેમેરો ખોલો (Take Photo)",
    save_photo_btn: "💾 ફોટો સેવ કરો (Save Photo)",
    complete_modal_title: "🏁 લોટ પૂર્ણ કરો (Complete)",
    pieces_completed_label: "તૈયાર થયેલા કુલ પીસ:",
    notes_label: "નોંધ (Optional Notes):",
    confirm_complete_btn: "✅ પૂર્ણ તરીકે માર્ક કરો & આગળ મોકલો",
    
    // Workers Table & Payroll
    worker_code: "કોડ",
    worker_name: "કારીગરનું નામ",
    worker_role: "વિભાગ / હોદ્દો",
    worker_phone: "મોબાઇલ નંબર",
    rate_per_piece: "ભાવ / પીસ",
    pieces_completed_col: "કરેલા પીસ",
    total_salary_earned: "કુલ કમાણી / પગાર",
    paid_so_far: "ચૂકવેલ રકમ",
    pending_salary: "બાકી આપવાની રકમ",
    pay_action_btn: "જમા-ઉધાર / પેમેન્ટ",
    dept_washing_title: "🧼 વોશિંગ કામની કતાર (Washing Queue)",
    dept_gaaj_title: "🔘 ગાજ-બટન કામની કતાર (Gaaj-Button Queue)",
    dept_press_title: "📦 પ્રેસ & પેકિંગ કતાર (Press & Packing Queue)",
    start_date_label: "શરૂ તારીખ",
    turnaround_time_label: "ચાલુ સમય",
    days_unit: "દિવસ ચાલુ",
    photo_saved_title: "સેમ્પલ શર્ટ ફોટો સેવ થયો",
    photo_saved_sub: "માલિકના પોર્ટલ પર ફોટો મોકલાઈ ગયો છે.",
    normal_priority: "સામાન્ય (NORMAL)",
    dealer_label: "ડીલર",
    jobber_command_center: "જોબર કમાન્ડ સેન્ટર",
    assign_pieces_to_karigar_btn: "કારીગરને પીસ & ભાવ સોંપો",
    send_lot_to_washing_btn: "વોશિંગ માટે આગળ મોકલો",
    pieces_assigned_label: "સોંપેલા પીસ",
    rate_paid_by_jobber_label: "જોબર દ્વારા અપાતો ભાવ (₹/પીસ)",
    select_karigar_label: "કારીગર પસંદ કરો",
    select_machine_label: "મશીન પસંદ કરો",
    karigar_speed_col: "સ્પીડ (પીસ/કલાક)",
    jobber_karigars_tab: "કારીગરો & ભાવ",
    jobber_lots_tab: "ચાલુ લોટ",
    jobber_log_tab: "કામ હિસાબ"
  },

  hi: {
    app_title: "AXIL फैक्ट्री मैनेजमेंट",
    welcome: "स्वागत है",
    dashboard: "डैशबोर्ड (Dashboard)",
    manufacturing: "उत्पादन पाइपलाइन",
    lot_tracking: "लॉट ट्रैकिंग",
    department_handover: "हैंडओवर अलर्ट्स",
    workers: "कारीगर और वेतन खाता",
    jobbers_machines: "जॉबर्स एवं मशीनें",
    costing_payments: "कॉस्टिंग एवं भुगतान (खाता)",
    active_lots: "उत्पादन में सक्रिय लॉट",
    pending_alterations: "पेंडिंग अल्टरेशन",
    godown: "गोदाम इन्वेंटरी",
    reports: "रिपोर्ट्स और डिफेक्ट ऑडिट",
    settings: "सेटिंग्स",
    logout: "लॉग आउट",
    worker_portal: "कारीगर फ्लोर टच स्क्रीन",
    owner_login_title: "👑 फैक्ट्री मालिक लॉगिन (Owner Login)",
    owner_login_sub: "प्रबंधन डैशबोर्ड खोलने के लिए पासवर्ड दर्ज करें",
    username: "उपयोगकर्ता नाम (Username)",
    password: "पासवर्ड (Password)",
    login_owner_btn: "मालिक पोर्टल में लॉगिन करें",
    
    // Dashboard KPIs & Stage Funnel
    fabric_in_stock: "फैक्ट्री में कपड़ा स्टॉक (मीटर)",
    fabric_meters_unit: "मीटर",
    remnant_fabric: "बचा हुआ कपड़ा",
    total_fabric_received: "कुल आया कपड़ा",
    cutting_pending: "1. कटिंग चालू / पेंडिंग",
    stitching_pending: "2. सिलाई पेंडिंग",
    washing_pending: "3. वाशिंग कतार",
    gaaj_button_pending: "4. गाज-बटन पेंडिंग",
    press_packing_pending: "5. प्रेस और पैकिंग",
    finished_stock: "6. तैयार गोदाम स्टॉक",
    pieces_unit: "पीस",
    lots_unit: "लॉट",
    
    // Washer Decision Workflow
    assign_washer_title: "🧼 सिलाई पूर्ण लॉट के लिए वाशर चुनें",
    assign_washer_sub: "इस लॉट की सिलाई पूरी हो चुकी है। किस वाशर या लॉन्ड्री के पास भेजना है?",
    choose_washer_placeholder: "-- वाशर चुनें --",
    assign_and_send_btn: "वाशिंग के लिए भेजें और सूचित करें",
    
    // Worker Portal & Roles
    worker_login_title: "AXIL कारीगर पोर्टल",
    worker_login_sub: "फैक्ट्री फ्लोर उत्पादन और टर्नअराउंड ट्रैकिंग",
    new_registration_tab: "✨ नया पंजीकरण",
    phone_login_tab: "🔑 मोबाइल लॉगिन",
    select_role_label: "अपना पद / कार्य चुनें:",
    role_cutting: "✂️ कटिंग मास्टर",
    role_stitcher: "🪡 सिलाई कारीगर",
    role_jobber: "🏢 जॉबर / फ्लोर मैनेजर",
    role_washer: "🧼 वाशिंग कारीगर",
    role_gaaj: "🔘 गाज-बटन कारीगर",
    role_packing: "📦 प्रेस और पैकिंग",
    full_name_label: "आपका पूरा नाम:",
    full_name_placeholder: "उदा. रमेश भाई मकवाणा",
    mobile_label: "मोबाइल नंबर (10 अंक):",
    mobile_placeholder: "10 अंकों का मोबाइल नंबर",
    set_password_label: "पासवर्ड / पिन:",
    set_password_placeholder: "अपना पासवर्ड दर्ज करें",
    register_and_start_btn: "🚀 खाता बनाएं और शुरू करें",
    login_btn: "🔑 लॉगिन करें",
    logout_btn: "बाहर निकलें",
    enable_notifications_title: "मोबाइल नोटिफिकेशन चालू करें",
    enable_notifications_sub: "नए और अर्जेंट काम के मैसेज लॉकस्क्रीन पर आएंगे (व्हाट्सएप जैसे)",
    enable_notifications_btn: "चालू करें",
    
    // Cutting Master Form
    cutting_master_title: "✂️ कपड़ा आवक और कटिंग लॉट एंट्री",
    cutting_master_sub: "कपड़े और कटिंग का विवरण भरें। यह लॉट आगे के स्टेज और मालिक को अपने आप भेजा जाएगा।",
    new_lot_tab: "✂️ नया लॉट कटिंग",
    lot_history_tab: "📋 कटे हुए लॉट लिस्ट",
    dealer_name_label: "डीलर / व्यापारी का नाम: *",
    dealer_name_placeholder: "उदा. अरविंद मिल्स / रेमंड",
    fabric_type_label: "कपड़े का प्रकार: *",
    fabric_type_placeholder: "उदा. Pure Cotton / Linen / Twill",
    meters_received_label: "आया हुआ कपड़ा मीटर: *",
    design_select_label: "डिजाइन नंबर: *",
    lot_number_label: "लॉट नंबर: *",
    cut_pieces_label: "कुल कटिंग पीस: *",
    remnant_meters_label: "फैक्ट्री में बचा कपड़ा: *",
    colors_swatches_label: "रंग / सैंपल शेड्स:",
    colors_swatches_placeholder: "उदा. Sky Blue, Navy, White",
    is_urgent_label: "🚨 अर्जेंट लॉट है?",
    due_date_label: "तैयार करने की तारीख:",
    stages_checklist_label: "यह लॉट किस-किस स्टेज से गुजरेगा?",
    submit_lot_btn: "🚀 कटिंग पूर्ण और आगे भेजें",
    
    // Karigar Queue & Actions
    stitching_queue_title: "🪡 सिलाई के लिए सौंपा गया लॉट (Stitching Queue)",
    refresh_btn: "🔄 रिफ्रेश",
    accept_start_lot_btn: "✅ लॉट स्वीकारें और शुरू करें",
    take_photo_btn: "📸 सैंपल शर्ट फोटो लें",
    change_photo_btn: "📸 नया फोटो बदलें",
    complete_turnaround_btn: "🏁 लॉट पूरा करें (Complete Turnaround)",
    photo_modal_title: "📸 सैंपल शर्ट का फोटो लें",
    camera_trigger_btn: "📸 कैमरा खोलें (Take Photo)",
    save_photo_btn: "💾 फोटो सेव करें",
    complete_modal_title: "🏁 लॉट पूरा करें",
    pieces_completed_label: "तैयार कुल पीस:",
    notes_label: "टिप्पणी (Optional):",
    confirm_complete_btn: "✅ पूर्ण मार्क करें और आगे भेजें",
    
    // Workers Table & Payroll
    worker_code: "कोड",
    worker_name: "कारीगर का नाम",
    worker_role: "विभाग / पद",
    worker_phone: "मोबाइल नंबर",
    rate_per_piece: "रेट / पीस",
    pieces_completed_col: "किए गए पीस",
    total_salary_earned: "कुल कमाई / वेतन",
    paid_so_far: "भुगतान की गई राशि",
    pending_salary: "बकाया राशि",
    pay_action_btn: "खाता / पेमेंट एंट्री",
    dept_washing_title: "🧼 वाशिंग कार्य कतार (Washing Queue)",
    dept_gaaj_title: "🔘 गाज-बटन कार्य कतार (Gaaj-Button Queue)",
    dept_press_title: "📦 प्रेस और पैकिंग कतार (Press & Packing Queue)",
    start_date_label: "शुरू तारीख",
    turnaround_time_label: "कार्य समय",
    days_unit: "दिन से प्रगति पर",
    photo_saved_title: "सैंपल शर्ट का फोटो सेव हो गया",
    photo_saved_sub: "फैक्ट्री मालिक के डैशबोर्ड पर फोटो भेज दिया गया है।",
    normal_priority: "सामान्य (NORMAL)",
    dealer_label: "डीलर",
    jobber_command_center: "जोबर कमांड सेंटर",
    assign_pieces_to_karigar_btn: "कारीगर को काम और रेट सौंपें",
    send_lot_to_washing_btn: "वाशिंग के लिए आगे भेजें",
    pieces_assigned_label: "सौंपे गए कुल पीस",
    rate_paid_by_jobber_label: "जोबर द्वारा दिया जाने वाला रेट (₹/पीस)",
    select_karigar_label: "कारीगर चुनें",
    select_machine_label: "मशीन चुनें",
    karigar_speed_col: "गति (पीस/घंटा)",
    jobber_karigars_tab: "कारीगर और रेट",
    jobber_lots_tab: "सक्रिय लॉट",
    jobber_log_tab: "काम हिसाब"
  }
};

let currentLanguage = localStorage.getItem('axil_lang') || 'gu';

function setLanguage(lang) {
  if (TRANSLATIONS[lang]) {
    currentLanguage = lang;
    localStorage.setItem('axil_lang', lang);
    applyTranslations();
    updateLanguageButtons(lang);
    window.dispatchEvent(new CustomEvent('languageChanged', { detail: { lang } }));
  }
}

function updateLanguageButtons(lang) {
  ['gu', 'hi', 'en'].forEach((l) => {
    const btn = document.getElementById(`lang-${l}`);
    if (btn) {
      const parentDark = btn.closest(".bg-neutral-800, .bg-neutral-900, header.bg-neutral-900");
      if (l === lang) {
        btn.className = "px-2 py-1 rounded lang-btn bg-white text-neutral-900 font-bold shadow-xs";
      } else {
        btn.className = parentDark
          ? "px-2 py-1 rounded lang-btn text-neutral-400 hover:text-white transition-colors"
          : "px-2 py-1 rounded lang-btn text-neutral-500 hover:text-neutral-900 transition-colors";
      }
    }
  });
}

function t(key) {
  return (TRANSLATIONS[currentLanguage] && TRANSLATIONS[currentLanguage][key]) ||
         (TRANSLATIONS['gu'] && TRANSLATIONS['gu'][key]) ||
         (TRANSLATIONS['en'] && TRANSLATIONS['en'][key]) || key;
}

function applyTranslations() {
  document.querySelectorAll('[data-i18n]').forEach((el) => {
    const key = el.getAttribute('data-i18n');
    el.textContent = t(key);
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach((el) => {
    const key = el.getAttribute('data-i18n-placeholder');
    el.placeholder = t(key);
  });
}

document.addEventListener('DOMContentLoaded', () => {
  updateLanguageButtons(currentLanguage);
  applyTranslations();
});

window.setLanguage = setLanguage;
window.updateLanguageButtons = updateLanguageButtons;
window.t = t;
window.applyTranslations = applyTranslations;
