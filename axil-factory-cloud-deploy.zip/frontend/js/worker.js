/**
 * AXIL Garment Manufacturing PWA — Worker Floor Script
 * Tailored for real factory operations:
 * - Instant Worker Registration & Mobile Login (No OTP hassle)
 * - Push / Lockscreen Notifications (WhatsApp-style)
 * - Tailored views by Role:
 *   - Cutting Master: Inwards fabric from dealer, cut pieces, remnant fabric, color swatches, stage route
 *   - Stitcher / Sewer: Urgent work queue, sample shirt camera photo proof, turnaround days
 *   - Washer / Gaaj-Button / Press & Packing: Department turnaround days tracking
 *   - Jobber: Floor contractor hub
 */

let currentWorker = null;
let activeLotIdForPhoto = null;
let selectedPhotoBase64 = null;
let activeLotIdForComplete = null;

document.addEventListener("DOMContentLoaded", () => {
  initWorkerApp();
  updateRoleOptions();
});

window.addEventListener("languageChanged", () => {
  updateRoleOptions();
  if (currentWorker) {
    showDashboardView();
  }
});

function updateRoleOptions() {
  const select = document.getElementById("reg-role");
  if (!select) return;
  const currentVal = select.value || "Stitcher / Sewer (Karigar)";
  select.innerHTML = `
    <option value="Cutting Master">${t("role_cutting") || "✂️ Cutting Master"}</option>
    <option value="Stitcher / Sewer (Karigar)">${t("role_stitcher") || "🪡 Stitcher / Karigar"}</option>
    <option value="Jobber">${t("role_jobber") || "🏢 Jobber / Manager"}</option>
    <option value="Washer">${t("role_washer") || "🧼 Washer"}</option>
    <option value="Gaaj-Button Operator">${t("role_gaaj") || "🔘 Gaaj-Button"}</option>
    <option value="Press & Packing Master">${t("role_packing") || "📦 Press & Packing"}</option>
  `;
  select.value = currentVal;
}

function initWorkerApp() {
  const sessionData = localStorage.getItem("axil_worker_session");
  if (sessionData) {
    try {
      currentWorker = JSON.parse(sessionData);
      if (currentWorker && currentWorker.worker_id) {
        showDashboardView();
        return;
      }
    } catch (e) {
      localStorage.removeItem("axil_worker_session");
    }
  }

  showLoginView();
}

// --- AUTH TABS & HANDLERS ---
function switchAuthTab(tab) {
  const regForm = document.getElementById("worker-register-form");
  const loginForm = document.getElementById("worker-login-form");
  const tabReg = document.getElementById("auth-tab-register");
  const tabLogin = document.getElementById("auth-tab-login");

  if (tab === "register") {
    regForm.classList.remove("hidden");
    loginForm.classList.add("hidden");
    tabReg.className = "py-2.5 rounded-lg bg-white text-neutral-900 shadow-xs transition-all";
    tabLogin.className = "py-2.5 rounded-lg text-neutral-500 hover:text-neutral-900 transition-all";
  } else {
    regForm.classList.add("hidden");
    loginForm.classList.remove("hidden");
    tabLogin.className = "py-2.5 rounded-lg bg-white text-neutral-900 shadow-xs transition-all";
    tabReg.className = "py-2.5 rounded-lg text-neutral-500 hover:text-neutral-900 transition-all";
  }
}

async function handleWorkerRegister(e) {
  e.preventDefault();
  const role = document.getElementById("reg-role").value;
  const fullName = document.getElementById("reg-fullname").value.trim();
  const phone = document.getElementById("reg-phone").value.trim();
  const password = document.getElementById("reg-password").value.trim();
  const btn = document.getElementById("reg-submit-btn");

  if (!role) {
    showToast("Please select your role from the list", "warning");
    return;
  }

  if (!fullName || !phone || !password) {
    showToast("Please fill all required fields", "warning");
    return;
  }

  btn.disabled = true;
  btn.innerHTML = `<span>⏳ Registering account...</span>`;

  try {
    const res = await api.registerWorkerSelf(fullName, role, phone, password);
    api.setWorkerSession(res.token, res);
    currentWorker = res;
    showToast(`Welcome, ${fullName}! Registration successful.`, "success");
    
    // Auto-prompt lockscreen push notifications
    requestNotificationAccess();

    showDashboardView();
  } catch (err) {
    showToast(err.message || "Registration failed. Please try again.", "error");
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<span>${t("register_and_start_btn")}</span>`;
  }
}

async function handleWorkerLogin(e) {
  e.preventDefault();
  const phone = document.getElementById("login-phone").value.trim();
  const password = document.getElementById("login-password").value.trim();
  const btn = document.getElementById("login-submit-btn");

  if (!phone || !password) {
    showToast("Please enter mobile number and password", "warning");
    return;
  }

  btn.disabled = true;
  btn.innerHTML = `<span>⏳ Logging in...</span>`;

  try {
    const res = await api.loginWorkerPhone(phone, password);
    api.setWorkerSession(res.token, res);
    currentWorker = res;
    showToast(`Welcome, ${res.full_name}!`, "success");
    showDashboardView();
  } catch (err) {
    showToast(err.message || "Invalid mobile number or password.", "error");
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<span>${t("login_btn")}</span>`;
  }
}

async function quickLoginRole(roleKey) {
  const roleConfigs = {
    cutting: { phone: "9876500001", pin: "1234", name: "Kanti Bhai Master", role: "Cutting Master", dept: 2 },
    stitcher: { phone: "9876500101", pin: "1234", name: "Dinesh Kumar", role: "Stitcher / Sewer (Karigar)", dept: 3 },
    jobber: { phone: "9876500601", pin: "1234", name: "Babu Bhai Contractor", role: "Jobber", dept: 3 },
    washer: { phone: "9876500301", pin: "1234", name: "Mukesh Bhai Washer", role: "Washer", dept: 6 },
  };

  const config = roleConfigs[roleKey] || roleConfigs.stitcher;

  try {
    const res = await api.loginWorkerPhone(config.phone, config.pin);
    api.setWorkerSession(res.token, res);
    currentWorker = res;
    showToast(`Welcome, ${res.full_name}!`, "success");
    showDashboardView();
  } catch (err) {
    try {
      const reg = await api.registerWorkerSelf(config.name, config.role, config.phone, config.pin);
      api.setWorkerSession(reg.token, reg);
      currentWorker = reg;
      showToast(`Welcome, ${reg.full_name}!`, "success");
      showDashboardView();
    } catch (regErr) {
      const fallback = {
        worker_id: config.dept === 2 ? 1 : (config.role === "Jobber" ? 99 : 2),
        full_name: config.name,
        role_designation: config.role,
        department_id: config.dept,
        language_preference: currentLanguage || "gu",
        token: "demo_token_" + roleKey
      };
      api.setWorkerSession(fallback.token, fallback);
      currentWorker = fallback;
      showToast(`Demo Mode: ${config.name}`, "info");
      showDashboardView();
    }
  }
}

function logoutWorker() {
  if (confirm("Are you sure you want to log out?")) {
    api.clearWorkerSession();
    currentWorker = null;
    showLoginView();
  }
}

function showLoginView() {
  document.getElementById("worker-login-view").classList.remove("hidden");
  document.getElementById("worker-dashboard-view").classList.add("hidden");
  document.getElementById("push-notify-btn").classList.add("hidden");
}

function showDashboardView() {
  document.getElementById("worker-login-view").classList.add("hidden");
  document.getElementById("worker-dashboard-view").classList.remove("hidden");
  document.getElementById("push-notify-btn").classList.remove("hidden");

  // Render header profile
  const nameEl = document.getElementById("current-worker-name");
  const roleBadge = document.getElementById("current-worker-role-badge");
  const avatarEl = document.getElementById("worker-avatar-initials");
  const headerRoleSub = document.getElementById("header-role-sub");

  const name = currentWorker.full_name || "Karigar";
  const role = currentWorker.role_designation || "Karigar";

  nameEl.textContent = name;
  roleBadge.textContent = role;
  headerRoleSub.textContent = role;

  const initials = name.split(" ").map(n => n[0]).join("").toUpperCase().substring(0, 2);
  avatarEl.textContent = initials || "KA";

  // Check notification permission
  if ("Notification" in window && Notification.permission === "granted") {
    const pCard = document.getElementById("push-permission-card");
    if (pCard) pCard.classList.add("hidden");
    const pBtn = document.getElementById("push-notify-btn");
    if (pBtn) pBtn.innerHTML = `<span>🔔 Alerts On</span>`;
  }

  // Hide all role views first
  document.getElementById("role-view-cutting").classList.add("hidden");
  document.getElementById("role-view-stitcher").classList.add("hidden");
  document.getElementById("role-view-department").classList.add("hidden");
  document.getElementById("role-view-jobber").classList.add("hidden");

  // Mount specific Role Dashboard
  if (role === "Cutting Master") {
    document.getElementById("role-view-cutting").classList.remove("hidden");
    loadCuttingMasterDesigns();
    loadCuttingMasterHistory();
  } else if (role.includes("Stitcher") || role.includes("Sewer")) {
    document.getElementById("role-view-stitcher").classList.remove("hidden");
    loadWorkerQueue();
  } else if (role === "Jobber") {
    document.getElementById("role-view-jobber").classList.remove("hidden");
    loadJobberHubData();
  } else {
    // Washer, Gaaj-Button, Press & Packing
    document.getElementById("role-view-department").classList.remove("hidden");
    setupDepartmentView(role);
    loadWorkerQueue();
  }
}

// --- CUTTING MASTER ACTIONS ---
function switchCuttingTab(tab) {
  const panelCreate = document.getElementById("cut-panel-create");
  const panelHist = document.getElementById("cut-panel-history");
  const btnCreate = document.getElementById("cut-subtab-create");
  const btnHist = document.getElementById("cut-subtab-history");

  if (tab === "create") {
    panelCreate.classList.remove("hidden");
    panelHist.classList.add("hidden");
    btnCreate.className = "py-2.5 rounded-lg bg-white text-neutral-900 shadow-xs flex items-center justify-center gap-1.5";
    btnHist.className = "py-2.5 rounded-lg text-neutral-600 hover:text-neutral-900 flex items-center justify-center gap-1.5";
  } else {
    panelCreate.classList.add("hidden");
    panelHist.classList.remove("hidden");
    btnHist.className = "py-2.5 rounded-lg bg-white text-neutral-900 shadow-xs flex items-center justify-center gap-1.5";
    btnCreate.className = "py-2.5 rounded-lg text-neutral-600 hover:text-neutral-900 flex items-center justify-center gap-1.5";
    loadCuttingMasterHistory();
  }
}

async function loadCuttingMasterDesigns() {
  const select = document.getElementById("cut-design-select");
  try {
    const res = await api.request("/api/masters/designs");
    if (res && res.length > 0) {
      select.innerHTML = '<option value="">-- ' + (t("design_select_label") || "Select Design") + ' --</option>' + 
        res.map(d => `<option value="${d.id}">${d.design_number} - ${d.name} (${d.fabric_type || 'Cotton'})</option>`).join("");
    } else {
      select.innerHTML = '<option value="1">AX-101 - Regular Fit Shirt</option>';
    }
  } catch (e) {
    select.innerHTML = '<option value="1">AX-101 - Regular Fit Shirt</option>';
  }
}

function calculateCutBundles() {
  const total = parseInt(document.getElementById("cut-total-pieces").value) || 0;
  const bSize = parseInt(document.getElementById("cut-bundle-size").value) || 20;
  const helper = document.getElementById("cut-bundle-calc-helper");
  if (!helper) return;
  if (total <= 0 || bSize <= 0) {
    helper.textContent = `0 ${t("bundles_count_label")} (${bSize} ${t("shirts_per_bundle_label")})`;
    return;
  }
  const count = Math.ceil(total / bSize);
  const loose = total % bSize;
  if (loose === 0) {
    helper.textContent = `✅ ${count} ${t("bundles_count_label")} (${bSize} ${t("shirts_per_bundle_label")})`;
  } else {
    helper.textContent = `✅ ${count - 1} ${t("bundles_count_label")} (${bSize}) + 1 (${loose}) = ${count} ${t("bundles_count_label")}`;
  }
}

async function handleCuttingMasterSubmit(e) {
  e.preventDefault();
  const dealerName = document.getElementById("cut-dealer-name").value.trim();
  const fabricType = document.getElementById("cut-fabric-type").value.trim();
  const metersReceived = parseFloat(document.getElementById("cut-meters-received").value) || 0;
  const designId = parseInt(document.getElementById("cut-design-select").value) || 1;
  const lotNumber = document.getElementById("cut-lot-number").value.trim();
  const totalPieces = parseInt(document.getElementById("cut-total-pieces").value) || 0;
  const bundleSize = parseInt(document.getElementById("cut-bundle-size").value) || 20;
  const remnantMeters = parseFloat(document.getElementById("cut-remnant-meters").value) || 0;
  const swatches = document.getElementById("cut-color-swatches").value.trim();
  const colorBreakdown = document.getElementById("cut-color-breakdown") ? document.getElementById("cut-color-breakdown").value.trim() : "";
  const isUrgent = document.getElementById("cut-is-urgent").checked;
  const dueDate = document.getElementById("cut-due-date").value || null;

  // Stages checklist (9-Stage factory journey)
  const stages = [2]; // 2 is Cutting (always first)
  if (document.getElementById("stage-stitch").checked) stages.push(3);
  if (document.getElementById("stage-embroidery") && document.getElementById("stage-embroidery").checked) stages.push(4);
  if (document.getElementById("stage-screen-print") && document.getElementById("stage-screen-print").checked) stages.push(5);
  if (document.getElementById("stage-wash").checked) stages.push(6);
  if (document.getElementById("stage-gaaj").checked) stages.push(7);
  if (document.getElementById("stage-pack").checked) stages.push(8);

  const btn = document.getElementById("cut-submit-btn");
  btn.disabled = true;
  btn.innerHTML = `<span>⏳ Creating lot...</span>`;

  try {
    const res = await api.cuttingMasterCreateLot({
      dealer_name: dealerName,
      fabric_type: fabricType,
      meters_received: metersReceived,
      design_id: designId,
      lot_number: lotNumber,
      total_cut_pieces: totalPieces,
      bundle_size: bundleSize,
      remnant_fabric_meters: remnantMeters,
      color_swatches: swatches,
      color_breakdown: colorBreakdown,
      is_urgent: isUrgent,
      due_date: dueDate,
      target_stages: stages
    });

    showToast(`Lot ${lotNumber} created successfully! (${Math.ceil(totalPieces / bundleSize)} bundles). Routed to next stage.`, "success");
    document.getElementById("cutting-master-lot-form").reset();
    calculateCutBundles();
    switchCuttingTab("history");
  } catch (err) {
    showToast(err.message || "Failed to create cutting lot.", "error");
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<span>${t("submit_lot_btn")}</span>`;
  }
}

async function loadCuttingMasterHistory() {
  const container = document.getElementById("cut-history-container");
  container.innerHTML = `<div class="text-center py-6 text-neutral-400 text-xs font-semibold">Loading cut lots...</div>`;

  try {
    const lots = await api.getLots().catch(() => api.request("/api/lots"));
    if (!lots || lots.length === 0) {
      container.innerHTML = `
        <div class="bg-white p-6 rounded-2xl border border-neutral-200 text-center text-neutral-400 space-y-2">
          <span class="text-3xl block">✂️</span>
          <p class="text-xs font-semibold">No cut lots logged yet.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = lots.map(l => `
      <div class="bg-white p-4 rounded-xl border border-neutral-200 shadow-xs space-y-2">
        <div class="flex justify-between items-start">
          <div>
            <div class="flex items-center gap-2">
              <span class="font-black text-sm text-neutral-900">${l.lot_number}</span>
              ${l.is_urgent ? '<span class="bg-red-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full animate-pulse">🚨 URGENT</span>' : ''}
            </div>
            <div class="text-xs text-neutral-500 font-medium">${t("dealer_label")}: <span class="font-bold text-neutral-800">${l.dealer_name || 'Direct'}</span></div>
          </div>
          <span class="text-xs font-black bg-blue-50 text-blue-800 border border-blue-200 px-2.5 py-1 rounded-lg">
            ${l.total_cut_pieces} Pieces
          </span>
        </div>

        <div class="grid grid-cols-2 gap-2 text-xs text-neutral-600 pt-1 border-t border-neutral-100">
          <div>${t("remnant_fabric")}: <span class="font-bold text-neutral-900">${l.remnant_fabric_meters || 0}m</span></div>
          <div>${t("current_stage_label")}: <span class="font-bold text-emerald-700">${l.current_department_name || 'Production'}</span></div>
        </div>

        ${l.color_swatches ? `<div class="text-[11px] text-neutral-500">${t("colors_swatches_label")}: <span class="font-semibold text-neutral-800">${l.color_swatches}</span></div>` : ''}
      </div>
    `).join("");
  } catch (err) {
    container.innerHTML = `<div class="text-center py-4 text-red-500 text-xs">Failed to load lots.</div>`;
  }
}

// --- WORKER QUEUE & TURNAROUND DAYS TRACKING ---
async function loadWorkerQueue() {
  const isStitcher = currentWorker && (currentWorker.role_designation.includes("Stitcher") || currentWorker.role_designation.includes("Sewer"));
  const container = document.getElementById(isStitcher ? "stitcher-queue-container" : "dept-queue-container");

  if (!container) return;
  container.innerHTML = `<div class="text-center py-8 text-neutral-400 text-xs font-semibold">Loading work queue...</div>`;

  try {
    const queue = await api.getWorkerQueue();

    if (!queue || queue.length === 0) {
      container.innerHTML = `
        <div class="bg-white p-8 rounded-2xl border border-neutral-200 text-center text-neutral-400 space-y-2">
          <span class="text-4xl block">🎉</span>
          <p class="text-sm font-bold text-neutral-700">No pending work!</p>
          <p class="text-xs text-neutral-400">New work order alerts will appear here automatically.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = queue.map(item => renderQueueCard(item, isStitcher)).join("");
  } catch (err) {
    container.innerHTML = `<div class="text-center py-6 text-red-500 text-xs font-bold">Failed to load queue. Please refresh.</div>`;
  }
}

function renderQueueCard(item, isStitcher) {
  const isStarted = item.route_status === "IN_PROGRESS" || !!item.route_started_at;
  const isCompleted = item.route_status === "COMPLETED";

  // Calculate elapsed turnaround days
  let turnaroundBadge = "";
  if (isStarted && item.route_started_at) {
    try {
      const startDt = new Date(item.route_started_at);
      const nowDt = new Date();
      const diffDays = Math.max(1, Math.ceil((nowDt - startDt) / (1000 * 60 * 60 * 24)));
      const dateLocale = currentLanguage === 'hi' ? 'hi-IN' : (currentLanguage === 'gu' ? 'gu-IN' : 'en-IN');
      const startStr = startDt.toLocaleDateString(dateLocale);
      const daysText = `${diffDays} ${t('days_unit') || 'days in progress'}`;
      turnaroundBadge = `
        <div class="bg-amber-50 border border-amber-200 text-amber-900 px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5">
          <span>🗓️</span>
          <span>${t('start_date_label') || 'Start Date'}: ${startStr} • ${t('turnaround_time_label') || 'Time'}: ${daysText}</span>
        </div>
      `;
    } catch(e) {}
  }

  const samplePhoto = item.sample_photo_url || item.sample_shirt_photo_url;
  const bSize = item.bundle_size || 20;
  const bCount = item.bundles_count || Math.ceil(item.total_cut_pieces / bSize);

  return `
    <div class="bg-white p-4 sm:p-5 rounded-2xl border ${item.is_urgent ? 'border-red-300 ring-2 ring-red-100' : 'border-neutral-200'} shadow-sm space-y-3">
      
      <!-- Card Header -->
      <div class="flex justify-between items-start gap-2">
        <div>
          <div class="flex items-center gap-2 flex-wrap">
            <span class="font-black text-base text-neutral-900">${item.lot_number}</span>
            ${item.is_urgent ? '<span class="bg-red-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full animate-pulse flex items-center gap-1"><span>🚨</span> <span>URGENT</span></span>' : `<span class="bg-neutral-100 text-neutral-600 text-[10px] font-bold px-2 py-0.5 rounded-md">${t('normal_priority') || 'NORMAL'}</span>`}
            <span class="bg-amber-100 text-amber-900 text-[10px] font-black px-2 py-0.5 rounded-md">
              📦 ${bCount} ${t("bundles_count_label")} (${bSize} ${t("shirts_per_bundle_label")})
            </span>
          </div>
          <div class="text-xs font-bold text-neutral-800 mt-0.5">${item.design_name || 'Design'} (${item.design_number || 'AX'})</div>
          <div class="text-[11px] text-neutral-500 font-medium">${t('dealer_label') || 'Dealer'}: <span class="font-bold text-neutral-800">${item.dealer_name || 'Direct Factory'}</span></div>
        </div>

        <div class="text-right">
          <span class="text-base font-black text-blue-900 bg-blue-50 border border-blue-200 px-3 py-1 rounded-xl block">
            ${item.total_cut_pieces} ${t('pieces_unit') || 'Pieces'}
          </span>
          ${item.due_date ? `<span class="text-[10px] text-red-600 font-bold block mt-1">${t('due_date_label') || 'Due'}: ${item.due_date}</span>` : ''}
        </div>
      </div>

      <!-- Turnaround Time Display -->
      ${turnaroundBadge}

      <!-- Colors / Swatches & Breakdown -->
      ${item.color_breakdown ? `
        <div class="text-xs text-neutral-700 bg-amber-50/60 p-2 rounded-lg border border-amber-200">
          <span class="text-[10px] font-bold text-amber-900 block">${t("color_breakdown_label")}</span>
          <span class="font-bold text-neutral-800">${item.color_breakdown}</span>
        </div>
      ` : (item.color_swatches ? `
        <div class="text-xs text-neutral-600 bg-neutral-50 p-2 rounded-lg border border-neutral-100">
          <span class="text-neutral-400 font-medium">${t('colors_swatches_label') || 'Colors'}:</span> <span class="font-bold text-neutral-800">${item.color_swatches}</span>
        </div>
      ` : '')}

      <!-- Sample Photo Proof (If uploaded) -->
      ${samplePhoto ? `
        <div class="flex items-center gap-3 p-2 bg-emerald-50 rounded-xl border border-emerald-200">
          <img src="${samplePhoto}" alt="Sample Shirt" class="w-14 h-14 object-cover rounded-lg border border-emerald-300">
          <div class="text-xs">
            <span class="font-bold text-emerald-900 block">✅ ${t('photo_saved_title') || 'Sample Shirt Photo Saved'}</span>
            <span class="text-[11px] text-emerald-700">${t('photo_saved_sub') || 'Photo sent to Factory Owner portal.'}</span>
          </div>
        </div>
      ` : ''}

      <!-- Turnaround Action Buttons -->
      <div class="pt-2 border-t border-neutral-100 flex flex-col gap-2">
        ${!isStarted ? `
          <button onclick="startLotTurnaround(${item.lot_id})" class="w-full py-3.5 bg-neutral-900 text-white font-black text-sm rounded-xl shadow-md hover:bg-neutral-800 flex items-center justify-center gap-2">
            <span>✅</span>
            <span>${t('accept_start_lot_btn')}</span>
          </button>
        ` : `
          <div class="grid grid-cols-1 ${isStitcher ? 'sm:grid-cols-2' : ''} gap-2">
            ${isStitcher ? `
              <button onclick="openPhotoModal(${item.lot_id})" class="py-3 bg-blue-600 text-white font-bold text-xs rounded-xl shadow-sm hover:bg-blue-700 flex items-center justify-center gap-1.5">
                <span>📸</span>
                <span>${samplePhoto ? t('change_photo_btn') : t('take_photo_btn')}</span>
              </button>
            ` : ''}

            <button onclick="openCompleteModal(${item.lot_id}, ${item.total_cut_pieces})" class="py-3 bg-emerald-600 text-white font-black text-xs rounded-xl shadow-sm hover:bg-emerald-700 flex items-center justify-center gap-1.5">
              <span>🏁</span>
              <span>${t('complete_turnaround_btn')}</span>
            </button>
          </div>
        `}
      </div>

    </div>
  `;
}

async function startLotTurnaround(lotId) {
  try {
    const res = await api.workerStartLot(lotId);
    showToast("Lot started! Turnaround tracking activated.", "success");
    loadWorkerQueue();
  } catch (err) {
    showToast(err.message || "Failed to start lot.", "error");
  }
}

// --- PHOTO CAPTURE WORKFLOW ---
function openPhotoModal(lotId) {
  activeLotIdForPhoto = lotId;
  selectedPhotoBase64 = null;
  document.getElementById("photo-preview-img").classList.add("hidden");
  document.getElementById("photo-preview-placeholder").classList.remove("hidden");
  document.getElementById("photo-save-btn").disabled = true;
  document.getElementById("photo-modal").classList.remove("hidden");
}

function closePhotoModal() {
  document.getElementById("photo-modal").classList.add("hidden");
  activeLotIdForPhoto = null;
}

function handlePhotoSelected(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(event) {
    const img = new Image();
    img.onload = function() {
      // Compress and scale photo to max 1000px width/height for fast mobile upload
      const canvas = document.createElement("canvas");
      const MAX_DIM = 1000;
      let width = img.width;
      let height = img.height;

      if (width > height && width > MAX_DIM) {
        height *= MAX_DIM / width;
        width = MAX_DIM;
      } else if (height > MAX_DIM) {
        width *= MAX_DIM / height;
        height = MAX_DIM;
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0, width, height);

      selectedPhotoBase64 = canvas.toDataURL("image/jpeg", 0.75);

      const previewImg = document.getElementById("photo-preview-img");
      previewImg.src = selectedPhotoBase64;
      previewImg.classList.remove("hidden");
      document.getElementById("photo-preview-placeholder").classList.add("hidden");
      document.getElementById("photo-save-btn").disabled = false;
    };
    img.src = event.target.result;
  };
  reader.readAsDataURL(file);
}

async function submitSampleShirtPhoto() {
  if (!activeLotIdForPhoto || !selectedPhotoBase64) return;
  const btn = document.getElementById("photo-save-btn");
  btn.disabled = true;
  btn.textContent = "Saving...";

  try {
    const res = await api.workerUploadPhoto(activeLotIdForPhoto, selectedPhotoBase64);
    showToast("Sample shirt photo saved!", "success");
    closePhotoModal();
    loadWorkerQueue();
  } catch (err) {
    showToast(err.message || "Failed to upload photo.", "error");
  } finally {
    btn.disabled = false;
    btn.textContent = "💾 " + (t("save_photo_btn") || "Save Photo");
  }
}

// --- COMPLETE TURNAROUND WORKFLOW ---
function openCompleteModal(lotId, defaultPieces) {
  activeLotIdForComplete = lotId;
  document.getElementById("complete-pieces").value = defaultPieces || "";
  document.getElementById("complete-notes").value = "";
  document.getElementById("complete-modal").classList.remove("hidden");
}

function closeCompleteModal() {
  document.getElementById("complete-modal").classList.add("hidden");
  activeLotIdForComplete = null;
}

async function submitCompleteTurnaround() {
  if (!activeLotIdForComplete) return;
  const pieces = parseInt(document.getElementById("complete-pieces").value) || null;
  const notes = document.getElementById("complete-notes").value.trim() || null;

  try {
    const res = await api.workerCompleteTurnaround(activeLotIdForComplete, pieces, notes);
    showToast(`Lot completed in ${res.turnaround_days} days. Sent to next stage!`, "success");
    closeCompleteModal();
    loadWorkerQueue();
  } catch (err) {
    showToast(err.message || "Failed to mark lot complete.", "error");
  }
}

// --- DEPARTMENT SPECIFIC CONFIG ---
function setupDepartmentView(role) {
  const iconEl = document.getElementById("dept-view-icon");
  const titleEl = document.getElementById("dept-view-title");

  if (role === "Washer") {
    iconEl.textContent = "🧼";
    titleEl.textContent = t("dept_washing_title") || "Washing Work Queue";
  } else if (role.includes("Gaaj")) {
    iconEl.textContent = "🔘";
    titleEl.textContent = t("dept_gaaj_title") || "Gaaj-Button Work Queue";
  } else if (role.includes("Press") || role.includes("Packing")) {
    iconEl.textContent = "📦";
    titleEl.textContent = t("dept_press_title") || "Press & Packing Queue";
  } else if (role.includes("Print") || role.includes("Screen")) {
    iconEl.textContent = "🎨";
    titleEl.textContent = t("dept_printing_title") || "Screen Printing Work Queue";
  } else if (role.includes("Embroidery")) {
    iconEl.textContent = "🧵";
    titleEl.textContent = t("dept_embroidery_title") || "Embroidery Work Queue";
  } else {
    iconEl.textContent = "⚙️";
    titleEl.textContent = `${role} Work Queue`;
  }
}

// --- ADVANCED JOBBER FLOOR MANAGEMENT HUB ---
let jobberHubCache = null;
let activeJobberSendLotId = null;
let activeJobberSendLotNumber = null;
let activeJobberProgId = null;

async function loadJobberHubData() {
  const lotsContainer = document.getElementById("jobber-lots-container");
  const karigarsContainer = document.getElementById("jobber-karigars-container");
  const allocContainer = document.getElementById("jobber-allocations-container");

  if (lotsContainer) lotsContainer.innerHTML = `<div class="text-center py-6 text-neutral-400 text-xs font-semibold">Loading jobber data...</div>`;

  try {
    const data = await api.getJobberHubData();
    jobberHubCache = data;

    // Update Top Stat Counters
    const activeLots = data.active_lots || [];
    const karigars = data.karigars || [];
    const allocations = data.allocations || [];

    const statLots = document.getElementById("jobber-stat-lots");
    const statKarigars = document.getElementById("jobber-stat-karigars");
    const statCompleted = document.getElementById("jobber-stat-completed");

    const totalCompleted = allocations.reduce((sum, a) => sum + (a.pieces_completed || 0), 0);

    if (statLots) statLots.textContent = activeLots.length;
    if (statKarigars) statKarigars.textContent = karigars.length;
    if (statCompleted) statCompleted.textContent = totalCompleted.toLocaleString();

    renderJobberLots(activeLots);
    renderJobberKarigars(karigars);
    renderJobberAllocations(allocations);
  } catch (err) {
    if (lotsContainer) lotsContainer.innerHTML = `<div class="text-center py-4 text-red-500 text-xs font-bold">Failed to load jobber data: ${err.message || 'Error'}</div>`;
  }
}

function switchJobberSubtab(subtab) {
  const panelLots = document.getElementById("jobber-panel-lots");
  const panelKarigars = document.getElementById("jobber-panel-karigars");
  const panelAlloc = document.getElementById("jobber-panel-allocations");

  const tabLots = document.getElementById("jobber-tab-lots");
  const tabKarigars = document.getElementById("jobber-tab-karigars");
  const tabAlloc = document.getElementById("jobber-tab-allocations");

  [panelLots, panelKarigars, panelAlloc].forEach(p => p?.classList.add("hidden"));
  [tabLots, tabKarigars, tabAlloc].forEach(t => {
    if (t) t.className = "py-2 rounded-lg text-neutral-600 hover:text-neutral-900";
  });

  if (subtab === "lots") {
    panelLots?.classList.remove("hidden");
    tabLots.className = "py-2 rounded-lg bg-white text-neutral-900 shadow-xs font-bold";
  } else if (subtab === "karigars") {
    panelKarigars?.classList.remove("hidden");
    tabKarigars.className = "py-2 rounded-lg bg-white text-neutral-900 shadow-xs font-bold";
  } else {
    panelAlloc?.classList.remove("hidden");
    tabAlloc.className = "py-2 rounded-lg bg-white text-neutral-900 shadow-xs font-bold";
  }
}

async function uploadLotSamplePhoto(lotId, event) {
  const file = event.target.files && event.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = async (e) => {
    const base64 = e.target.result;
    try {
      showToast("Uploading shirt photo...", "info");
      await api.uploadLotPhoto(lotId, base64);
      showToast("✅ Sample shirt photo uploaded successfully!", "success");
      if (typeof loadJobberHubData === "function") loadJobberHubData();
      if (typeof loadWorkerQueue === "function") loadWorkerQueue();
    } catch (err) {
      showToast(err.message || "Failed to upload photo.", "error");
    }
  };
  reader.readAsDataURL(file);
}

function renderJobberLots(lots) {
  const container = document.getElementById("jobber-lots-container");
  if (!container) return;

  if (lots.length === 0) {
    container.innerHTML = `
      <div class="bg-white p-6 rounded-2xl border border-neutral-200 text-center text-neutral-400 space-y-1">
        <span class="text-3xl block">🎉</span>
        <p class="text-xs font-bold text-neutral-700">No active stitching lots pending!</p>
        <p class="text-[11px] text-neutral-400">New lots from cutting will appear here automatically.</p>
      </div>
    `;
    return;
  }

  container.innerHTML = lots.map(l => {
    const assigned = l.pieces_assigned_total || 0;
    const completed = l.pieces_completed_total || 0;
    const total = l.total_cut_pieces || 1;
    const bSize = l.bundle_size || 20;
    const bCount = l.bundles_count || Math.ceil(total / bSize);
    const pctAssigned = Math.min(100, Math.round((assigned / total) * 100));
    const pctCompleted = Math.min(100, Math.round((completed / total) * 100));

    return `
      <div class="bg-white p-4 rounded-2xl border ${l.is_urgent ? 'border-red-300 ring-2 ring-red-100' : 'border-neutral-200'} shadow-xs space-y-3">
        <div class="flex justify-between items-start gap-2">
          <div>
            <div class="flex items-center gap-2 flex-wrap">
              <span class="font-black text-base text-neutral-900">${l.lot_number}</span>
              ${l.is_urgent ? '<span class="bg-red-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full animate-pulse">🚨 URGENT</span>' : ''}
              <span class="bg-amber-100 text-amber-900 text-[10px] font-black px-2 py-0.5 rounded-md">
                📦 ${bCount} ${t("bundles_count_label")} (${bSize} ${t("shirts_per_bundle_label")})
              </span>
            </div>
            <div class="text-xs font-bold text-neutral-800 mt-0.5">${l.design_name || 'Design'} (${l.design_number || 'AX'})</div>
            <div class="text-[11px] text-neutral-500 font-medium">${t("dealer_label")}: <span class="font-bold text-neutral-800">${l.dealer_name || 'Direct Factory'}</span> • Fabric: <strong>${l.fabric_type || 'Cotton'}</strong></div>
          </div>
          <div class="text-right">
            <span class="text-base font-black text-blue-900 bg-blue-50 border border-blue-200 px-3 py-1 rounded-xl block">
              ${l.total_cut_pieces} Pieces
            </span>
            ${l.due_date ? `<span class="text-[10px] text-red-600 font-bold block mt-1">Due: ${l.due_date}</span>` : ''}
          </div>
        </div>

        ${l.color_breakdown ? `
          <div class="text-xs text-neutral-700 bg-amber-50/60 p-2.5 rounded-xl border border-amber-200 space-y-1">
            <div class="text-[10px] font-bold text-amber-900 uppercase">${t("color_breakdown_label")}</div>
            <div class="font-semibold text-neutral-900">${l.color_breakdown}</div>
          </div>
        ` : (l.color_swatches ? `
          <div class="text-xs text-neutral-600 bg-neutral-50 p-2 rounded-lg border border-neutral-100">
            <span class="text-neutral-400 font-medium">${t("colors_swatches_label")}:</span> <span class="font-bold text-neutral-800">${l.color_swatches}</span>
          </div>
        ` : '')}

        <!-- Sample Shirt Photo Showcase & Update -->
        <div class="flex items-center justify-between gap-3 p-2.5 bg-neutral-50 rounded-xl border border-neutral-200">
          <div class="flex items-center gap-2.5">
            ${l.sample_shirt_photo_url ? `
              <img src="${l.sample_shirt_photo_url}" class="w-12 h-12 object-cover rounded-lg border border-emerald-300 shadow-xs">
              <div class="text-xs">
                <span class="font-bold text-emerald-800 block">${t("photo_live_badge")}</span>
                <span class="text-[10px] text-neutral-500">${t("photo_saved_sub")}</span>
              </div>
            ` : `
              <div class="w-12 h-12 rounded-lg bg-neutral-200 flex items-center justify-center text-xl text-neutral-400 font-bold">👕</div>
              <div class="text-xs">
                <span class="font-bold text-neutral-700 block">${t("photo_pending_badge")}</span>
                <span class="text-[10px] text-neutral-400">${t("take_photo_btn")}</span>
              </div>
            `}
          </div>
          <label class="cursor-pointer px-3 py-1.5 bg-neutral-900 hover:bg-neutral-800 text-white rounded-lg text-xs font-bold flex items-center gap-1 shadow-xs whitespace-nowrap">
            <input type="file" accept="image/*" capture="environment" class="hidden" onchange="uploadLotSamplePhoto(${l.lot_id}, event)">
            <span>📸 ${l.sample_shirt_photo_url ? (t("change_photo_label") || "Change") : (t("take_photo_btn") || "Take Photo")}</span>
          </label>
        </div>

        <!-- Progress Tracking -->
        <div class="space-y-1.5 bg-neutral-50 p-3 rounded-xl border border-neutral-100 text-xs">
          <div class="flex justify-between text-neutral-600 font-semibold text-[11px]">
            <span>${t("pieces_assigned_label_static") || "Assigned"}: <strong>${assigned} / ${l.total_cut_pieces} pcs</strong> (${pctAssigned}%)</span>
            <span>${t("completed_label_static") || "Completed"}: <strong class="text-emerald-700">${completed} pcs</strong></span>
          </div>
          <div class="w-full bg-neutral-200 rounded-full h-2 overflow-hidden">
            <div class="bg-emerald-600 h-2 rounded-full transition-all" style="width: ${pctCompleted}%"></div>
          </div>
        </div>

        <!-- Jobber Actions -->
        <div class="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1 border-t border-neutral-100">
          <button onclick="openJobberAssignModal(${l.lot_id})" class="py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5">
            <span>➕</span>
            <span>${t("assign_pieces_to_karigar_btn")}</span>
          </button>

          <button onclick="openJobberSendLotModal(${l.lot_id}, '${l.lot_number}', ${l.total_cut_pieces})" class="py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs rounded-xl shadow-xs flex items-center justify-center gap-1.5">
            <span>🚀</span>
            <span>${t("send_lot_to_washing_btn")}</span>
          </button>
        </div>
      </div>
    `;
  }).join("");
}

function renderJobberKarigars(karigars) {
  const container = document.getElementById("jobber-karigars-container");
  if (!container) return;

  if (karigars.length === 0) {
    container.innerHTML = `
      <div class="bg-white p-6 rounded-2xl border border-neutral-200 text-center text-neutral-400 text-xs">
        No stitching karigars registered yet.
      </div>
    `;
    return;
  }

  container.innerHTML = karigars.map(k => `
    <div class="bg-white p-4 rounded-xl border border-neutral-200 shadow-xs space-y-2.5">
      <div class="flex items-start justify-between">
        <div>
          <div class="flex items-center gap-2">
            <span class="font-black text-sm text-neutral-900">${k.full_name}</span>
            <span class="font-mono text-[10px] bg-neutral-100 text-neutral-700 px-2 py-0.5 rounded font-bold">${k.worker_code}</span>
          </div>
          <div class="text-xs text-neutral-500 mt-0.5">
            <span>Machine: <strong class="text-blue-800">${k.machine_code || 'M-??'}</strong></span> • 
            <span>Mobile: ${k.phone || '-'}</span>
          </div>
        </div>

        <div class="text-right">
          <span class="text-xs font-black bg-emerald-50 text-emerald-800 border border-emerald-200 px-2.5 py-1 rounded-lg block">
            Rate: ₹${k.rate_per_piece || 30}/pc
          </span>
        </div>
      </div>

      <div class="grid grid-cols-3 gap-2 bg-neutral-50 p-2.5 rounded-lg border border-neutral-100 text-center text-xs">
        <div>
          <div class="text-[10px] text-neutral-400 font-bold uppercase">${t("pieces_completed_col")}</div>
          <div class="font-black text-neutral-900 text-sm mt-0.5">${k.pieces_completed || 0} pcs</div>
        </div>
        <div>
          <div class="text-[10px] text-neutral-400 font-bold uppercase">${t("speed_col")}</div>
          <div class="font-black text-blue-700 text-sm mt-0.5">${k.avg_speed_pcs_hr ? k.avg_speed_pcs_hr.toFixed(1) : '0.0'}</div>
        </div>
        <div>
          <div class="text-[10px] text-neutral-400 font-bold uppercase">${t("total_salary_earned")}</div>
          <div class="font-black text-emerald-700 text-sm mt-0.5">₹${(k.total_earned || 0).toLocaleString()}</div>
        </div>
      </div>

      <button onclick="openJobberAssignModal(null, ${k.id})" class="w-full py-2 bg-neutral-100 hover:bg-neutral-200 text-neutral-800 font-bold text-xs rounded-lg transition-colors flex items-center justify-center gap-1.5">
        <span>➕</span> <span>Assign New Lot to this Karigar</span>
      </button>
    </div>
  `).join("");
}

function renderJobberAllocations(allocations) {
  const container = document.getElementById("jobber-allocations-container");
  if (!container) return;

  if (allocations.length === 0) {
    container.innerHTML = `
      <div class="bg-white p-6 rounded-2xl border border-neutral-200 text-center text-neutral-400 text-xs">
        No work allocations logged yet.
      </div>
    `;
    return;
  }

  container.innerHTML = allocations.map(a => {
    const isComplete = a.status === 'COMPLETED' || (a.pieces_completed >= a.pieces_assigned);
    return `
      <div class="bg-white p-3.5 rounded-xl border border-neutral-200 shadow-xs space-y-2">
        <div class="flex items-start justify-between">
          <div>
            <div class="flex items-center gap-2">
              <span class="font-black text-sm text-neutral-900">${a.lot_number}</span>
              <span class="text-xs text-neutral-600 font-bold">(${a.design_number || 'AX'})</span>
              <span class="text-[10px] font-bold px-2 py-0.5 rounded ${isComplete ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}">
                ${isComplete ? 'COMPLETED' : 'IN_PROGRESS'}
              </span>
            </div>
            <div class="text-xs text-neutral-700 font-medium mt-0.5">
              Karigar: <strong class="text-neutral-900">${a.worker_name}</strong> (${a.machine_code || 'M-??'})
            </div>
          </div>

          <div class="text-right">
            <span class="text-xs font-black text-neutral-900">₹${a.rate_per_piece}/pc</span>
            <div class="text-[10px] text-neutral-400">Total: ₹${(a.total_earned || 0).toLocaleString()}</div>
          </div>
        </div>

        <div class="flex items-center justify-between text-xs bg-neutral-50 px-3 py-1.5 rounded-lg border border-neutral-100">
          <div>Assigned: <strong>${a.pieces_assigned} pcs</strong></div>
          <div class="text-neutral-300">|</div>
          <div>Ready: <strong class="text-emerald-700">${a.pieces_completed || 0} pcs</strong></div>
          <div class="text-neutral-300">|</div>
          <div>Speed: <strong class="text-blue-700">${a.production_speed_pcs_per_hr ? a.production_speed_pcs_per_hr.toFixed(1) : '0.0'} pcs/hr</strong></div>
        </div>

        <button onclick="openJobberProgressModal(${a.production_id}, '${a.worker_name.replace(/'/g, "\\'")}', '${a.lot_number}', ${a.pieces_assigned}, ${a.rate_per_piece}, ${a.pieces_completed || 0}, ${a.pieces_altered || 0})" class="w-full py-1.5 bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-xs rounded-lg shadow-xs flex items-center justify-center gap-1.5">
          <span>📝</span> <span>Update Pieces Done</span>
        </button>
      </div>
    `;
  }).join("");
}

// --- JOBBER MODALS & ACTIONS ---
function openJobberAssignModal(lotId = null, workerId = null) {
  if (!jobberHubCache) {
    loadJobberHubData().then(() => openJobberAssignModal(lotId, workerId));
    return;
  }

  const lotSelect = document.getElementById("jobber-assign-lot-select");
  const workerSelect = document.getElementById("jobber-assign-worker-select");
  const machineSelect = document.getElementById("jobber-assign-machine-select");

  const lots = jobberHubCache.active_lots || [];
  const karigars = jobberHubCache.karigars || [];
  const machines = jobberHubCache.machines || [];

  if (lotSelect) {
    lotSelect.innerHTML = lots.map(l => `
      <option value="${l.lot_id}" ${lotId && l.lot_id === lotId ? 'selected' : ''}>
        ${l.lot_number} - ${l.design_name || 'Design'} (${l.total_cut_pieces} Cut Pieces)
      </option>
    `).join("");
  }

  if (workerSelect) {
    workerSelect.innerHTML = '<option value="">-- ' + t("select_karigar_label") + ' --</option>' + karigars.map(k => `
      <option value="${k.id}" ${workerId && k.id === workerId ? 'selected' : ''} data-rate="${k.rate_per_piece || 30}" data-machine="${k.machine_id || ''}">
        ${k.full_name} (${k.worker_code} - ${k.machine_code || 'Machine'}) - Default: ₹${k.rate_per_piece || 30}/pc
      </option>
    `).join("");
  }

  if (machineSelect) {
    machineSelect.innerHTML = '<option value="">-- ' + t("select_machine_label") + ' --</option>' + machines.map(m => `
      <option value="${m.id}">${m.machine_code} (${m.machine_type})</option>
    `).join("");
  }

  if (workerId) {
    handleJobberWorkerSelectChange();
  }

  document.getElementById("jobber-assign-modal")?.classList.remove("hidden");
}

function closeJobberAssignModal() {
  document.getElementById("jobber-assign-modal")?.classList.add("hidden");
}

function handleJobberWorkerSelectChange() {
  const select = document.getElementById("jobber-assign-worker-select");
  const rateInput = document.getElementById("jobber-assign-rate");
  const machineSelect = document.getElementById("jobber-assign-machine-select");

  if (!select) return;
  const opt = select.options[select.selectedIndex];
  if (opt) {
    const rate = opt.getAttribute("data-rate");
    const machine = opt.getAttribute("data-machine");
    if (rateInput && rate) rateInput.value = rate;
    if (machineSelect && machine) machineSelect.value = machine;
  }
}

async function handleJobberAssignSubmit(e) {
  e.preventDefault();
  const lotId = parseInt(document.getElementById("jobber-assign-lot-select").value);
  const workerId = parseInt(document.getElementById("jobber-assign-worker-select").value);
  const machineId = parseInt(document.getElementById("jobber-assign-machine-select").value) || null;
  const pieces = parseInt(document.getElementById("jobber-assign-pieces").value);
  const rate = parseFloat(document.getElementById("jobber-assign-rate").value);
  const notes = document.getElementById("jobber-assign-notes").value.trim() || null;

  if (!lotId || !workerId || !pieces || !rate) {
    alert("Please fill all required fields.");
    return;
  }

  const btn = document.getElementById("jobber-assign-submit-btn");
  btn.disabled = true;
  btn.innerHTML = `<span>⏳ Assigning work order...</span>`;

  try {
    const res = await api.jobberAssignWork({
      lot_id: lotId,
      worker_id: workerId,
      machine_id: machineId,
      pieces_assigned: pieces,
      rate_per_piece: rate,
      notes: notes
    });
    showToast(res.message || "Work order assigned successfully!", "success");
    closeJobberAssignModal();
    loadJobberHubData();
  } catch (err) {
    showToast(err.message || "Failed to assign work order.", "error");
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<span>🚀 ${t("assign_work_order_btn")}</span>`;
  }
}

function openJobberSendLotModal(lotId, lotNumber, cutPieces) {
  activeJobberSendLotId = lotId;
  activeJobberSendLotNumber = lotNumber;

  const titleEl = document.getElementById("jobber-send-lot-title");
  const subEl = document.getElementById("jobber-send-lot-sub");
  const pcsInput = document.getElementById("jobber-send-pieces-input");

  if (titleEl) titleEl.textContent = `Lot: ${lotNumber}`;
  if (subEl) subEl.textContent = `Total Cut Pieces: ${cutPieces} Pieces`;
  if (pcsInput) pcsInput.value = cutPieces;

  document.getElementById("jobber-send-lot-modal")?.classList.remove("hidden");
}

function closeJobberSendLotModal() {
  document.getElementById("jobber-send-lot-modal")?.classList.add("hidden");
  activeJobberSendLotId = null;
  activeJobberSendLotNumber = null;
}

async function submitJobberSendLotAhead() {
  if (!activeJobberSendLotId) return;
  const pieces = parseInt(document.getElementById("jobber-send-pieces-input").value);
  const notes = document.getElementById("jobber-send-notes-input").value.trim() || null;

  if (!pieces || pieces <= 0) {
    alert("Please enter completed pieces count.");
    return;
  }

  const btn = document.getElementById("jobber-send-submit-btn");
  btn.disabled = true;
  btn.innerHTML = `<span>⏳ Sending lot to washing...</span>`;

  try {
    const res = await api.jobberSendLotAhead(activeJobberSendLotId, pieces, notes);
    showToast(res.message || `Lot ${activeJobberSendLotNumber} sent to washing!`, "success");
    closeJobberSendLotModal();
    loadJobberHubData();
  } catch (err) {
    showToast(err.message || "Failed to route lot ahead.", "error");
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<span>🚀 ${t("send_washing_notify_btn")}</span>`;
  }
}

function openJobberProgressModal(prodId, workerName, lotNumber, assigned, rate, completed, altered) {
  activeJobberProgId = prodId;

  const wNameEl = document.getElementById("jobber-prog-worker-name");
  const lotInfoEl = document.getElementById("jobber-prog-lot-info");
  const assignedInfoEl = document.getElementById("jobber-prog-assigned-info");
  const compInput = document.getElementById("jobber-prog-completed-input");
  const altInput = document.getElementById("jobber-prog-altered-input");

  if (wNameEl) wNameEl.textContent = `Karigar: ${workerName}`;
  if (lotInfoEl) lotInfoEl.textContent = `Lot: ${lotNumber}`;
  if (assignedInfoEl) assignedInfoEl.textContent = `Assigned: ${assigned} pcs • Rate: ₹${rate}/pc`;
  if (compInput) compInput.value = completed || "";
  if (altInput) altInput.value = altered || 0;

  document.getElementById("jobber-progress-modal")?.classList.remove("hidden");
}

function closeJobberProgressModal() {
  document.getElementById("jobber-progress-modal")?.classList.add("hidden");
  activeJobberProgId = null;
}

async function submitJobberProgressUpdate() {
  if (!activeJobberProgId) return;
  const completed = parseInt(document.getElementById("jobber-prog-completed-input").value) || 0;
  const altered = parseInt(document.getElementById("jobber-prog-altered-input").value) || 0;

  const btn = document.getElementById("jobber-prog-submit-btn");
  btn.disabled = true;
  btn.innerHTML = `<span>⏳ Saving progress...</span>`;

  try {
    const res = await api.jobberUpdateProgress({
      production_id: activeJobberProgId,
      pieces_completed: completed,
      pieces_altered: altered
    });
    showToast(`Progress saved! Earned: ₹${res.total_earned} (Speed: ${res.speed_pcs_hr} pcs/hr)`, "success");
    closeJobberProgressModal();
    loadJobberHubData();
  } catch (err) {
    showToast(err.message || "Failed to save progress.", "error");
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<span>💾 ${t("save_progress_btn")}</span>`;
  }
}

// --- PUSH / LOCKSCREEN NOTIFICATION PERMISSION (WHATSAPP-STYLE) ---
async function requestNotificationAccess() {
  if (!("Notification" in window)) {
    showToast("This browser does not support web notifications", "warning");
    return;
  }

  try {
    const permission = await Notification.requestPermission();
    if (permission === "granted") {
      const pCard = document.getElementById("push-permission-card");
      if (pCard) pCard.classList.add("hidden");
      const pBtn = document.getElementById("push-notify-btn");
      if (pBtn) pBtn.innerHTML = `<span>🔔 Alerts On</span>`;

      showToast("✅ Notifications enabled! New work order alerts active.", "success");

      // Register with Service Worker Push Manager if available
      if ("serviceWorker" in navigator) {
        const reg = await navigator.serviceWorker.ready;
        if (reg.pushManager) {
          const sub = await reg.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: null // auto-managed
          }).catch(() => null);

          if (sub) {
            await api.subscribePush({
              endpoint: sub.endpoint,
              p256dh: sub.toJSON().keys ? sub.toJSON().keys.p256dh : null,
              auth: sub.toJSON().keys ? sub.toJSON().keys.auth : null
            });
          }
        }
      }
    } else {
      showToast("Notification permission was denied", "warning");
    }
  } catch (e) {
    console.log("Push permission error:", e);
  }
}
