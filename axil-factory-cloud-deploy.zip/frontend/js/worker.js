/**
 * AXIL Garment Manufacturing PWA — Worker Floor Script
 * Tailored for real factory operations:
 * - Instant Worker Registration & Mobile Login (No OTP hassle)
 * - Push / Lockscreen Notifications (WhatsApp-style)
 * - Tailored views by Role:
 *   - Cutting Master: Inwards fabric from dealer, cut pieces, remnant fabric, color swatches, stage route
 *   - Stitcher / Sewer: Urgent work queue, sample shirt camera photo proof, turnaround days
 *   - Washer / Gaaj-Button / Press & Packing: Department turnaround days tracking
 *   - Jobber: Floor contractor hub
 */

let currentWorker = null;
let activeLotIdForPhoto = null;
let selectedPhotoBase64 = null;
let activeLotIdForComplete = null;

document.addEventListener("DOMContentLoaded", () => {
  initWorkerApp();
});

function initWorkerApp() {
  const sessionData = localStorage.getItem("axil_worker_session");
  if (sessionData) {
    try {
      currentWorker = JSON.parse(sessionData);
      if (currentWorker && currentWorker.worker_id) {
        showDashboardView();
        return;
      }
    } catch (e) {
      localStorage.removeItem("axil_worker_session");
    }
  }

  showLoginView();
}

// --- AUTH TABS & HANDLERS ---
function switchAuthTab(tab) {
  const regForm = document.getElementById("worker-register-form");
  const loginForm = document.getElementById("worker-login-form");
  const tabReg = document.getElementById("auth-tab-register");
  const tabLogin = document.getElementById("auth-tab-login");

  if (tab === "register") {
    regForm.classList.remove("hidden");
    loginForm.classList.add("hidden");
    tabReg.className = "py-2.5 rounded-lg bg-white text-neutral-900 shadow-xs transition-all";
    tabLogin.className = "py-2.5 rounded-lg text-neutral-500 hover:text-neutral-900 transition-all";
  } else {
    regForm.classList.add("hidden");
    loginForm.classList.remove("hidden");
    tabLogin.className = "py-2.5 rounded-lg bg-white text-neutral-900 shadow-xs transition-all";
    tabReg.className = "py-2.5 rounded-lg text-neutral-500 hover:text-neutral-900 transition-all";
  }
}

async function handleWorkerRegister(e) {
  e.preventDefault();
  const role = document.getElementById("reg-role").value;
  const fullName = document.getElementById("reg-fullname").value.trim();
  const phone = document.getElementById("reg-phone").value.trim();
  const password = document.getElementById("reg-password").value.trim();
  const btn = document.getElementById("reg-submit-btn");

  if (!fullName || !phone || !password) {
    showToast("કૃપા કરીને બધી વિગતો ભરો (Please fill all fields)", "warning");
    return;
  }

  btn.disabled = true;
  btn.innerHTML = `<span>⏳ નોંધણી થઈ રહી છે...</span>`;

  try {
    const res = await api.registerWorkerSelf(fullName, role, phone, password);
    api.setWorkerSession(res.token, res);
    currentWorker = res;
    showToast(`સ્વાગત છે, ${fullName}! રજીસ્ટ્રેશન સફળ થયું.`, "success");
    
    // Auto-prompt lockscreen push notifications
    requestNotificationAccess();

    showDashboardView();
  } catch (err) {
    showToast(err.message || "નોંધણી નિષ્ફળ. ફરી પ્રયાસ કરો.", "error");
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<span>🚀 ખાતું બનાવો & શરૂ કરો</span>`;
  }
}

async function handleWorkerLogin(e) {
  e.preventDefault();
  const phone = document.getElementById("login-phone").value.trim();
  const password = document.getElementById("login-password").value.trim();
  const btn = document.getElementById("login-submit-btn");

  if (!phone || !password) {
    showToast("કૃપા કરીને મોબાઇલ અને પાસવર્ડ દાખલ કરો", "warning");
    return;
  }

  btn.disabled = true;
  btn.innerHTML = `<span>⏳ લોગિન થઈ રહ્યું છે...</span>`;

  try {
    const res = await api.loginWorkerPhone(phone, password);
    api.setWorkerSession(res.token, res);
    currentWorker = res;
    showToast(`સ્વાગત છે, ${res.full_name}!`, "success");
    showDashboardView();
  } catch (err) {
    showToast(err.message || "ખોટો મોબાઇલ અથવા પાસવર્ડ.", "error");
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<span>🔑 લોગિન કરો (Log In)</span>`;
  }
}

function logoutWorker() {
  if (confirm("શું તમે આ એકાઉન્ટમાંથી બહાર નીકળવા માંગો છો?")) {
    api.clearWorkerSession();
    currentWorker = null;
    showLoginView();
  }
}

function showLoginView() {
  document.getElementById("worker-login-view").classList.remove("hidden");
  document.getElementById("worker-dashboard-view").classList.add("hidden");
  document.getElementById("push-notify-btn").classList.add("hidden");
}

function showDashboardView() {
  document.getElementById("worker-login-view").classList.add("hidden");
  document.getElementById("worker-dashboard-view").classList.remove("hidden");
  document.getElementById("push-notify-btn").classList.remove("hidden");

  // Render header profile
  const nameEl = document.getElementById("current-worker-name");
  const roleBadge = document.getElementById("current-worker-role-badge");
  const avatarEl = document.getElementById("worker-avatar-initials");
  const headerRoleSub = document.getElementById("header-role-sub");

  const name = currentWorker.full_name || "કારીગર";
  const role = currentWorker.role_designation || "Karigar";

  nameEl.textContent = name;
  roleBadge.textContent = role;
  headerRoleSub.textContent = role;

  const initials = name.split(" ").map(n => n[0]).join("").toUpperCase().substring(0, 2);
  avatarEl.textContent = initials || "KA";

  // Check notification permission
  if ("Notification" in window && Notification.permission === "granted") {
    const pCard = document.getElementById("push-permission-card");
    if (pCard) pCard.classList.add("hidden");
    const pBtn = document.getElementById("push-notify-btn");
    if (pBtn) pBtn.innerHTML = `<span>🔔 Alerts On</span>`;
  }

  // Hide all role views first
  document.getElementById("role-view-cutting").classList.add("hidden");
  document.getElementById("role-view-stitcher").classList.add("hidden");
  document.getElementById("role-view-department").classList.add("hidden");
  document.getElementById("role-view-jobber").classList.add("hidden");

  // Mount specific Role Dashboard
  if (role === "Cutting Master") {
    document.getElementById("role-view-cutting").classList.remove("hidden");
    loadCuttingMasterDesigns();
    loadCuttingMasterHistory();
  } else if (role.includes("Stitcher") || role.includes("Sewer")) {
    document.getElementById("role-view-stitcher").classList.remove("hidden");
    loadWorkerQueue();
  } else if (role === "Jobber") {
    document.getElementById("role-view-jobber").classList.remove("hidden");
    loadJobberQueue();
  } else {
    // Washer, Gaaj-Button, Press & Packing
    document.getElementById("role-view-department").classList.remove("hidden");
    setupDepartmentView(role);
    loadWorkerQueue();
  }
}

// --- CUTTING MASTER ACTIONS ---
function switchCuttingTab(tab) {
  const panelCreate = document.getElementById("cut-panel-create");
  const panelHist = document.getElementById("cut-panel-history");
  const btnCreate = document.getElementById("cut-subtab-create");
  const btnHist = document.getElementById("cut-subtab-history");

  if (tab === "create") {
    panelCreate.classList.remove("hidden");
    panelHist.classList.add("hidden");
    btnCreate.className = "py-2.5 rounded-lg bg-white text-neutral-900 shadow-xs flex items-center justify-center gap-1.5";
    btnHist.className = "py-2.5 rounded-lg text-neutral-600 hover:text-neutral-900 flex items-center justify-center gap-1.5";
  } else {
    panelCreate.classList.add("hidden");
    panelHist.classList.remove("hidden");
    btnHist.className = "py-2.5 rounded-lg bg-white text-neutral-900 shadow-xs flex items-center justify-center gap-1.5";
    btnCreate.className = "py-2.5 rounded-lg text-neutral-600 hover:text-neutral-900 flex items-center justify-center gap-1.5";
    loadCuttingMasterHistory();
  }
}

async function loadCuttingMasterDesigns() {
  const select = document.getElementById("cut-design-select");
  try {
    const res = await api.request("/api/masters/designs");
    if (res && res.length > 0) {
      select.innerHTML = '<option value="">-- ડિઝાઇન પસંદ કરો --</option>' + 
        res.map(d => `<option value="${d.id}">${d.design_number} - ${d.name} (${d.fabric_type || 'Cotton'})</option>`).join("");
    } else {
      select.innerHTML = '<option value="1">AX-101 - Regular Fit Shirt</option>';
    }
  } catch (e) {
    select.innerHTML = '<option value="1">AX-101 - Regular Fit Shirt</option>';
  }
}

async function handleCuttingMasterSubmit(e) {
  e.preventDefault();
  const dealerName = document.getElementById("cut-dealer-name").value.trim();
  const fabricType = document.getElementById("cut-fabric-type").value.trim();
  const metersReceived = parseFloat(document.getElementById("cut-meters-received").value) || 0;
  const designId = parseInt(document.getElementById("cut-design-select").value) || 1;
  const lotNumber = document.getElementById("cut-lot-number").value.trim();
  const totalPieces = parseInt(document.getElementById("cut-total-pieces").value) || 0;
  const remnantMeters = parseFloat(document.getElementById("cut-remnant-meters").value) || 0;
  const swatches = document.getElementById("cut-color-swatches").value.trim();
  const isUrgent = document.getElementById("cut-is-urgent").checked;
  const dueDate = document.getElementById("cut-due-date").value || null;

  // Stages checklist
  const stages = [2]; // 2 is Cutting (always first)
  if (document.getElementById("stage-stitch").checked) stages.push(3);
  if (document.getElementById("stage-wash").checked) stages.push(6);
  if (document.getElementById("stage-gaaj").checked) stages.push(7);
  if (document.getElementById("stage-pack").checked) stages.push(8);

  const btn = document.getElementById("cut-submit-btn");
  btn.disabled = true;
  btn.innerHTML = `<span>⏳ લોટ બની રહ્યો છે...</span>`;

  try {
    const res = await api.cuttingMasterCreateLot({
      dealer_name: dealerName,
      fabric_type: fabricType,
      meters_received: metersReceived,
      design_id: designId,
      lot_number: lotNumber,
      total_cut_pieces: totalPieces,
      remnant_fabric_meters: remnantMeters,
      color_swatches: swatches,
      is_urgent: isUrgent,
      due_date: dueDate,
      target_stages: stages
    });

    showToast(`લોટ ${lotNumber} સફળતાપૂર્વક બન્યો! સિલાઈ વિભાગ અને માલિકને મોકલાયો.`, "success");
    document.getElementById("cutting-master-lot-form").reset();
    switchCuttingTab("history");
  } catch (err) {
    showToast(err.message || "લોટ બનાવવામાં ભૂલ આવી.", "error");
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<span>🚀 લોટ કટીંગ પૂર્ણ & આગળ મોકલો</span>`;
  }
}

async function loadCuttingMasterHistory() {
  const container = document.getElementById("cut-history-container");
  container.innerHTML = `<div class="text-center py-6 text-neutral-400 text-xs font-semibold">લોડ થઈ રહ્યું છે...</div>`;

  try {
    const lots = await api.request("/api/production/lots");
    if (!lots || lots.length === 0) {
      container.innerHTML = `
        <div class="bg-white p-6 rounded-2xl border border-neutral-200 text-center text-neutral-400 space-y-2">
          <span class="text-3xl block">✂️</span>
          <p class="text-xs font-semibold">હજુ સુધી કોઈ લોટ કટીંગ કર્યો નથી.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = lots.map(l => `
      <div class="bg-white p-4 rounded-xl border border-neutral-200 shadow-xs space-y-2">
        <div class="flex justify-between items-start">
          <div>
            <div class="flex items-center gap-2">
              <span class="font-black text-sm text-neutral-900">${l.lot_number}</span>
              ${l.is_urgent ? '<span class="bg-red-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full animate-pulse">🚨 URGENT</span>' : ''}
            </div>
            <div class="text-xs text-neutral-500 font-medium">ડીલર: <span class="font-bold text-neutral-800">${l.dealer_name || 'Direct'}</span></div>
          </div>
          <span class="text-xs font-black bg-blue-50 text-blue-800 border border-blue-200 px-2.5 py-1 rounded-lg">
            ${l.total_cut_pieces} Pieces
          </span>
        </div>

        <div class="grid grid-cols-2 gap-2 text-xs text-neutral-600 pt-1 border-t border-neutral-100">
          <div>વધેલું કાપડ: <span class="font-bold text-neutral-900">${l.remnant_fabric_meters || 0}m</span></div>
          <div>હાલનો સ્ટેજ: <span class="font-bold text-emerald-700">${l.current_department_name || 'Production'}</span></div>
        </div>

        ${l.color_swatches ? `<div class="text-[11px] text-neutral-500">રંગો: <span class="font-semibold text-neutral-800">${l.color_swatches}</span></div>` : ''}
      </div>
    `).join("");
  } catch (err) {
    container.innerHTML = `<div class="text-center py-4 text-red-500 text-xs">લોટ લોડ કરવામાં ભૂલ આવી.</div>`;
  }
}

// --- WORKER QUEUE & TURNAROUND DAYS TRACKING ---
async function loadWorkerQueue() {
  const isStitcher = currentWorker && (currentWorker.role_designation.includes("Stitcher") || currentWorker.role_designation.includes("Sewer"));
  const container = document.getElementById(isStitcher ? "stitcher-queue-container" : "dept-queue-container");

  if (!container) return;
  container.innerHTML = `<div class="text-center py-8 text-neutral-400 text-xs font-semibold">કામની કતાર લોડ થઈ રહી છે...</div>`;

  try {
    const queue = await api.getWorkerQueue();

    if (!queue || queue.length === 0) {
      container.innerHTML = `
        <div class="bg-white p-8 rounded-2xl border border-neutral-200 text-center text-neutral-400 space-y-2">
          <span class="text-4xl block">🎉</span>
          <p class="text-sm font-bold text-neutral-700">કોઈ પેન્ડિંગ કામ નથી!</p>
          <p class="text-xs text-neutral-400">નવો લોટ સોંપાતા જ તમારા ફોન પર એલર્ટ આવશે.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = queue.map(item => renderQueueCard(item, isStitcher)).join("");
  } catch (err) {
    container.innerHTML = `<div class="text-center py-6 text-red-500 text-xs font-bold">કતાર લોડ થઈ શકી નથી. કૃપા કરીને રીફ્રેશ કરો.</div>`;
  }
}

function renderQueueCard(item, isStitcher) {
  const isStarted = item.route_status === "IN_PROGRESS" || !!item.route_started_at;
  const isCompleted = item.route_status === "COMPLETED";

  // Calculate elapsed turnaround days
  let turnaroundBadge = "";
  if (isStarted && item.route_started_at) {
    try {
      const startDt = new Date(item.route_started_at);
      const nowDt = new Date();
      const diffDays = Math.max(1, Math.ceil((nowDt - startDt) / (1000 * 60 * 60 * 24)));
      turnaroundBadge = `
        <div class="bg-amber-50 border border-amber-200 text-amber-900 px-2.5 py-1 rounded-lg text-xs font-bold flex items-center gap-1.5">
          <span>🗓️</span>
          <span>શરૂ તારીખ: ${startDt.toLocaleDateString('gu-IN')} • સમય: ${diffDays} દિવસ ચાલુ</span>
        </div>
      `;
    } catch(e) {}
  }

  const samplePhoto = item.sample_photo_url || item.sample_shirt_photo_url;

  return `
    <div class="bg-white p-4 sm:p-5 rounded-2xl border ${item.is_urgent ? 'border-red-300 ring-2 ring-red-100' : 'border-neutral-200'} shadow-sm space-y-3">
      
      <!-- Card Header -->
      <div class="flex justify-between items-start gap-2">
        <div>
          <div class="flex items-center gap-2 flex-wrap">
            <span class="font-black text-base text-neutral-900">${item.lot_number}</span>
            ${item.is_urgent ? '<span class="bg-red-600 text-white text-[10px] font-black px-2 py-0.5 rounded-full animate-pulse flex items-center gap-1"><span>🚨</span> <span>URGENT</span></span>' : '<span class="bg-neutral-100 text-neutral-600 text-[10px] font-bold px-2 py-0.5 rounded-md">NORMAL</span>'}
          </div>
          <div class="text-xs font-bold text-neutral-800 mt-0.5">${item.design_name || 'Design'} (${item.design_number || 'AX'})</div>
          <div class="text-[11px] text-neutral-500 font-medium">ડીલર: <span class="font-bold text-neutral-800">${item.dealer_name || 'Direct Factory'}</span></div>
        </div>

        <div class="text-right">
          <span class="text-base font-black text-blue-900 bg-blue-50 border border-blue-200 px-3 py-1 rounded-xl block">
            ${item.total_cut_pieces} Pieces
          </span>
          ${item.due_date ? `<span class="text-[10px] text-red-600 font-bold block mt-1">Due: ${item.due_date}</span>` : ''}
        </div>
      </div>

      <!-- Turnaround Time Display -->
      ${turnaroundBadge}

      <!-- Colors / Swatches -->
      ${item.color_swatches ? `
        <div class="text-xs text-neutral-600 bg-neutral-50 p-2 rounded-lg border border-neutral-100">
          <span class="text-neutral-400 font-medium">રંગો:</span> <span class="font-bold text-neutral-800">${item.color_swatches}</span>
        </div>
      ` : ''}

      <!-- Sample Photo Proof (If uploaded) -->
      ${samplePhoto ? `
        <div class="flex items-center gap-3 p-2 bg-emerald-50 rounded-xl border border-emerald-200">
          <img src="${samplePhoto}" alt="Sample Shirt" class="w-14 h-14 object-cover rounded-lg border border-emerald-300">
          <div class="text-xs">
            <span class="font-bold text-emerald-900 block">✅ સેમ્પલ શર્ટ ફોટો સેવ થયો</span>
            <span class="text-[11px] text-emerald-700">માલિકના પોર્ટલ પર ફોટો મોકલાઈ ગયો છે.</span>
          </div>
        </div>
      ` : ''}

      <!-- Turnaround Action Buttons -->
      <div class="pt-2 border-t border-neutral-100 flex flex-col gap-2">
        ${!isStarted ? `
          <button onclick="startLotTurnaround(${item.lot_id})" class="w-full py-3.5 bg-neutral-900 text-white font-black text-sm rounded-xl shadow-md hover:bg-neutral-800 flex items-center justify-center gap-2">
            <span>✅</span>
            <span>લોટ સ્વીકારો & કામ શરૂ કરો (Accept & Start)</span>
          </button>
        ` : `
          <div class="grid grid-cols-1 ${isStitcher ? 'sm:grid-cols-2' : ''} gap-2">
            ${isStitcher ? `
              <button onclick="openPhotoModal(${item.lot_id})" class="py-3 bg-blue-600 text-white font-bold text-xs rounded-xl shadow-sm hover:bg-blue-700 flex items-center justify-center gap-1.5">
                <span>📸</span>
                <span>${samplePhoto ? 'નવો ફોટો બદલો' : 'સેમ્પલ શર્ટ ફોટો લો'}</span>
              </button>
            ` : ''}

            <button onclick="openCompleteModal(${item.lot_id}, ${item.total_cut_pieces})" class="py-3 bg-emerald-600 text-white font-black text-xs rounded-xl shadow-sm hover:bg-emerald-700 flex items-center justify-center gap-1.5">
              <span>🏁</span>
              <span>લોટ પૂર્ણ કરો (Complete Turnaround)</span>
            </button>
          </div>
        `}
      </div>

    </div>
  `;
}

async function startLotTurnaround(lotId) {
  try {
    const res = await api.workerStartLot(lotId);
    showToast("લોટ શરૂ થઈ ગયો! સમય નોંધવાનું શરૂ થયું.", "success");
    loadWorkerQueue();
  } catch (err) {
    showToast(err.message || "લોટ શરૂ કરવામાં ભૂલ આવી.", "error");
  }
}

// --- PHOTO CAPTURE WORKFLOW ---
function openPhotoModal(lotId) {
  activeLotIdForPhoto = lotId;
  selectedPhotoBase64 = null;
  document.getElementById("photo-preview-img").classList.add("hidden");
  document.getElementById("photo-preview-placeholder").classList.remove("hidden");
  document.getElementById("photo-save-btn").disabled = true;
  document.getElementById("photo-modal").classList.remove("hidden");
}

function closePhotoModal() {
  document.getElementById("photo-modal").classList.add("hidden");
  activeLotIdForPhoto = null;
}

function handlePhotoSelected(e) {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = function(event) {
    const img = new Image();
    img.onload = function() {
      // Compress and scale photo to max 1000px width/height for fast mobile upload
      const canvas = document.createElement("canvas");
      const MAX_DIM = 1000;
      let width = img.width;
      let height = img.height;

      if (width > height && width > MAX_DIM) {
        height *= MAX_DIM / width;
        width = MAX_DIM;
      } else if (height > MAX_DIM) {
        width *= MAX_DIM / height;
        height = MAX_DIM;
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext("2d");
      ctx.drawImage(img, 0, 0, width, height);

      selectedPhotoBase64 = canvas.toDataURL("image/jpeg", 0.75);

      const previewImg = document.getElementById("photo-preview-img");
      previewImg.src = selectedPhotoBase64;
      previewImg.classList.remove("hidden");
      document.getElementById("photo-preview-placeholder").classList.add("hidden");
      document.getElementById("photo-save-btn").disabled = false;
    };
    img.src = event.target.result;
  };
  reader.readAsDataURL(file);
}

async function submitSampleShirtPhoto() {
  if (!activeLotIdForPhoto || !selectedPhotoBase64) return;
  const btn = document.getElementById("photo-save-btn");
  btn.disabled = true;
  btn.textContent = "સેવ થઈ રહ્યો છે...";

  try {
    const res = await api.workerUploadPhoto(activeLotIdForPhoto, selectedPhotoBase64);
    showToast("સેમ્પલ શર્ટનો ફોટો સેવ થયો!", "success");
    closePhotoModal();
    loadWorkerQueue();
  } catch (err) {
    showToast(err.message || "ફોટો અપલોડ કરવામાં ભૂલ આવી.", "error");
  } finally {
    btn.disabled = false;
    btn.textContent = "💾 ફોટો સેવ કરો (Save Photo)";
  }
}

// --- COMPLETE TURNAROUND WORKFLOW ---
function openCompleteModal(lotId, defaultPieces) {
  activeLotIdForComplete = lotId;
  document.getElementById("complete-pieces").value = defaultPieces || "";
  document.getElementById("complete-notes").value = "";
  document.getElementById("complete-modal").classList.remove("hidden");
}

function closeCompleteModal() {
  document.getElementById("complete-modal").classList.add("hidden");
  activeLotIdForComplete = null;
}

async function submitCompleteTurnaround() {
  if (!activeLotIdForComplete) return;
  const pieces = parseInt(document.getElementById("complete-pieces").value) || null;
  const notes = document.getElementById("complete-notes").value.trim() || null;

  try {
    const res = await api.workerCompleteTurnaround(activeLotIdForComplete, pieces, notes);
    showToast(`લોટ પૂર્ણ થયો! સમય: ${res.turnaround_days} દિવસ. આગળ મોકલાયો.`, "success");
    closeCompleteModal();
    loadWorkerQueue();
  } catch (err) {
    showToast(err.message || "લોટ પૂર્ણ કરવામાં ભૂલ આવી.", "error");
  }
}

// --- DEPARTMENT SPECIFIC CONFIG ---
function setupDepartmentView(role) {
  const iconEl = document.getElementById("dept-view-icon");
  const titleEl = document.getElementById("dept-view-title");

  if (role === "Washer") {
    iconEl.textContent = "🧼";
    titleEl.textContent = "વોશિંગ કામની કતાર (Washing Queue)";
  } else if (role.includes("Gaaj")) {
    iconEl.textContent = "🔘";
    titleEl.textContent = "ગાજ-બટન કામની કતાર (Gaaj-Button Queue)";
  } else if (role.includes("Press") || role.includes("Packing")) {
    iconEl.textContent = "📦";
    titleEl.textContent = "પ્રેસ & પેકિંગ કતાર (Press & Packing Queue)";
  }
}

async function loadJobberQueue() {
  const container = document.getElementById("jobber-queue-container");
  container.innerHTML = `<div class="text-center py-6 text-neutral-400 text-xs">જોબર ડેટા લોડ થઈ રહ્યો છે...</div>`;

  try {
    const queue = await api.getWorkerQueue();
    if (!queue || queue.length === 0) {
      container.innerHTML = `
        <div class="bg-white p-6 rounded-2xl border border-neutral-200 text-center text-neutral-400">
          <span class="text-3xl block">🏢</span>
          <p class="text-xs font-semibold mt-1">કોઈ સિલાઈ લોટ પેન્ડિંગ નથી.</p>
        </div>
      `;
      return;
    }

    container.innerHTML = queue.map(item => `
      <div class="bg-white p-4 rounded-xl border border-neutral-200 shadow-xs space-y-2">
        <div class="flex justify-between items-start">
          <div>
            <div class="font-black text-sm text-neutral-900">${item.lot_number}</div>
            <div class="text-xs text-neutral-500">ડીલર: ${item.dealer_name || 'Direct'}</div>
          </div>
          <span class="text-xs font-black bg-blue-100 text-blue-900 px-2.5 py-1 rounded-lg">${item.total_cut_pieces} Pcs</span>
        </div>
        <div class="text-xs text-neutral-600">ડિઝાઇન: <span class="font-bold text-neutral-800">${item.design_name || 'Shirt'}</span></div>
      </div>
    `).join("");
  } catch (err) {
    container.innerHTML = `<div class="text-center py-4 text-red-500 text-xs">ડેટા લોડ થઈ શક્યો નહીં.</div>`;
  }
}

// --- PUSH / LOCKSCREEN NOTIFICATION PERMISSION (WHATSAPP-STYLE) ---
async function requestNotificationAccess() {
  if (!("Notification" in window)) {
    showToast("આ બ્રાઉઝર નોટિફિકેશન સપોર્ટ કરતું નથી", "warning");
    return;
  }

  try {
    const permission = await Notification.requestPermission();
    if (permission === "granted") {
      const pCard = document.getElementById("push-permission-card");
      if (pCard) pCard.classList.add("hidden");
      const pBtn = document.getElementById("push-notify-btn");
      if (pBtn) pBtn.innerHTML = `<span>🔔 Alerts On</span>`;

      showToast("✅ નોટિફિકેશન ચાલુ થઈ ગયું! નવા કામના મેસેજ લોકસ્ક્રીન પર આવશે.", "success");

      // Register with Service Worker Push Manager if available
      if ("serviceWorker" in navigator) {
        const reg = await navigator.serviceWorker.ready;
        if (reg.pushManager) {
          const sub = await reg.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: null // auto-managed
          }).catch(() => null);

          if (sub) {
            await api.subscribePush({
              endpoint: sub.endpoint,
              p256dh: sub.toJSON().keys ? sub.toJSON().keys.p256dh : null,
              auth: sub.toJSON().keys ? sub.toJSON().keys.auth : null
            });
          }
        }
      }
    } else {
      showToast("નોટિફિકેશન પરવાનગી નકારવામાં આવી", "warning");
    }
  } catch (e) {
    console.log("Push permission error:", e);
  }
}
