import subprocess
import re
import sys
import os
import time

PROJECT_DIR = r"C:\Users\stkab\.gemini\antigravity\scratch\axil-pwa"
CLOUDFLARED_EXE = os.path.join(PROJECT_DIR, "cloudflared.exe")
URL_FILE = os.path.join(PROJECT_DIR, "cloudflare_url.txt")

if not os.path.exists(CLOUDFLARED_EXE):
    print(f"Error: {CLOUDFLARED_EXE} not found.")
    sys.exit(1)

cmd = [CLOUDFLARED_EXE, "tunnel", "--url", "http://127.0.0.1:8000"]
print(f"Starting Cloudflare Quick Tunnel: {' '.join(cmd)}")

proc = subprocess.Popen(
    cmd,
    stdout=subprocess.PIPE,
    stderr=subprocess.STDOUT,
    text=True,
    bufsize=1,
    encoding="utf-8",
    errors="replace"
)

url_found = None
url_regex = re.compile(r"https://[a-zA-Z0-9-]+\.trycloudflare\.com")

while True:
    line = proc.stdout.readline()
    if not line:
        if proc.poll() is not None:
            print(f"Cloudflare process exited with code {proc.returncode}")
            break
        time.sleep(0.1)
        continue

    print(line.rstrip(), flush=True)

    if not url_found:
        match = url_regex.search(line)
        if match:
            url_found = match.group(0)
            print("\n" + "="*60, flush=True)
            print(f"CLOUDFLARE PUBLIC HTTPS URL DETECTED:\n{url_found}", flush=True)
            print("="*60 + "\n", flush=True)
            try:
                with open(URL_FILE, "w", encoding="utf-8") as f:
                    f.write(url_found)
                print(f"Saved URL to {URL_FILE}", flush=True)
                print(f"Owner Portal   : {url_found}/index.html", flush=True)
                print(f"Karigar Portal : {url_found}/worker.html", flush=True)
                print(f"Scan QR code   : {url_found}/assets/qr_owner.png", flush=True)
                print("="*60 + "\n", flush=True)
            except Exception as e:
                print(f"Failed to write URL to file: {e}", flush=True)
